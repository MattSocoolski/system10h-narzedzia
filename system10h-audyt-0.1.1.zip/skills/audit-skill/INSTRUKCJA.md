# Audit Skill System 10H — Instrukcja dla klienta

## Co to jest

`audit-skill` to skill Claude Code który **u Ciebie lokalnie** przeprowadza 15-25 minutowy wywiad o Twoim biznesie, skanuje środowisko Twojego komputera (nazwy aplikacji, crony, launch agents — **nie** zawartość plików), i generuje 4 pliki outputu. Te pliki wysyłasz mailem do Mateusza, on wrzuca do analyzera i odsyła Ci raport Owner Mode + Partner Mode z konkretnymi rekomendacjami asystentów AI i luk integracji.

**Kluczowe:**
- Skan działa **lokalnie**, a pliki wyniku zostają u Ciebie; treść czytana w trakcie skanu trafia do dostawcy modelu na Twoim koncie
- **Ty wysyłasz** pliki mailem, nie skill
- **Widzisz wszystko przed wysłaniem** — pełna kontrola

## Czego potrzebujesz

- **Claude Code** zainstalowany i zalogowany — https://claude.com/claude-code
- macOS, Linux lub Windows (skanowanie działa natywnie na każdym systemie)
- 15-25 minut skupienia
- Podstawowa wiedza o swoim stacku narzędzi (nazwy, nie cennik)

## Jak uruchomić (3 kroki)

### Krok 1 — Otwórz terminal w folderze, w którym ma powstać wynik

- **Masz już swojego asystenta** (folder z `CLAUDE.md`) → otwórz terminal **w tym folderze**. Audyt zaczyna od mapy Twojego asystenta i czyta pliki z folderu, w którym go uruchomisz.
- **Nie masz asystenta** → utwórz pusty folder roboczy i wejdź do niego:

```bash
mkdir ~/audit-10h
cd ~/audit-10h
```

Na Windowsie pracujesz w Git Bashu albo w PowerShellu — komendy poniżej są te same.

### Krok 2 — Zainstaluj wtyczkę z audytem (jedna linia, Windows i Mac tak samo)

W terminalu — **jeszcze przed uruchomieniem `claude`** — wklej jedną linię i naciśnij Enter:

```
claude plugin marketplace add MattSocoolski/system10h-narzedzia; claude plugin install system10h-audyt@system10h
```

Pierwsza część dodaje katalog wtyczek System 10H, druga instaluje z niego wtyczkę z audytem. Poprawny wynik to dwie linie z ptaszkiem: `Successfully added marketplace: system10h` i `Successfully installed plugin: system10h-audyt@system10h`. Powtórzenie linii niczego nie psuje — zobaczysz wtedy `already on disk` / `already installed`.

Sprawdzenie (opcjonalne): `claude plugin list` pokazuje `system10h-audyt@system10h` ze statusem `enabled`.

> **W środku Claude zamiast w terminalu:** te same dwie rzeczy robią komendy `/plugin marketplace add MattSocoolski/system10h-narzedzia` i `/plugin install system10h-audyt@system10h`, wklejane po jednej; potem `/exit` i ponowne `claude`.

> **Droga zapasowa (bez internetu do GitHuba albo bez programu Git na Windowsie):** plik `system10h-audyt-0.1.1.zip` od Mateusza. Wrzuć go do folderu z Kroku 1 i uruchom Claude tak: `claude --plugin-dir system10h-audyt-0.1.1.zip`. Wtyczka działa wtedy tylko w tej jednej sesji — przy następnym audycie powtarzasz tę komendę. Stary zip `audit-skill-v1.zip` (v1.0, kwiecień) NIE jest aktualny — nie używaj go.

### Krok 3 — Uruchom Claude i odpal audyt

W tym samym folderze:

```
claude
```

a w Claude napisz dokładnie to:

```
uruchom audit-skill
```

Jeśli Claude nie podejmie audytu, wpisz pełną nazwę komendy:

```
/system10h-audyt:audit-skill
```

Claude odpowie powitaniem, poprosi o zgodę, i przeprowadzi Cię przez 7 kroków wywiadu. W trakcie skanu Claude może pytać o zgodę na odczytanie listy programów (np. `brew list`, `npm list`, `crontab -l`, na Windowsie polecenia `Get-…`) — to odczyt, wybierz „Tak".

## Co dostaniesz (output)

W folderze `./audit-output/` znajdą się 4 pliki:

| Plik | Co zawiera | Dla kogo |
|---|---|---|
| `tech_stack.json` | Machine-readable dane o narzędziach, workflow, AI usage | Główny input dla Mateusza |
| `tech_stack_human.md` | Human-readable raport z Twoich odpowiedzi | Twoja kopia do przejrzenia |
| `profile.md` | Profil biznesowy Twoimi słowami (branża, zespół, cele, bolączki) | Input dla Mateusza |
| `workflow.md` | Workflow dnia + AI usage — cytaty | Input dla Mateusza |

**Przed wysłaniem** — otwórz `tech_stack_human.md` w ulubionym edytorze i przejrzyj. Jeśli coś jest nie tak — wróć do Claude Code i powiedz "popraw X na Y" — Claude zaktualizuje pliki.

## Jak wysłać

Wejdź do folderu `audit-output` (powstał w folderze, w którym uruchomiłeś audyt), spakuj, wyślij:

```bash
cd audit-output
zip audyt-moja-firma.zip tech_stack.json tech_stack_human.md profile.md workflow.md
```

Na Windowsie bez polecenia `zip` możesz po prostu załączyć do maila cztery pliki osobno.

Wyślij załącznik mailem na **hello@system10h.com** z tematem:

```
Audyt: [Nazwa Twojej firmy]
```

W treści maila nic nie musisz pisać, ale jeśli chcesz dodać kontekst — śmiało.

## Bezpieczeństwo — co skill robi i czego NIE robi

### ✅ Co skill robi
- Skanuje listy aplikacji (macOS: `ls /Applications`, Linux: `/usr/share/applications`, Windows: Registry + Store)
- Listuje narzędzia CLI zainstalowane przez Homebrew / npm / pip / winget / choco / scoop
- Sprawdza zaplanowane zadania (macOS: LaunchAgents, Linux: systemd/cron, Windows: Task Scheduler)
- Pyta Cię o subskrypcje SaaS (te których nie widać lokalnie — CRM, email marketing, itp.)
- Pyta Cię o workflow, bolączki, AI usage
- Generuje 4 pliki tekstowe w `./audit-output/`

### ❌ Czego skill NIE robi
- NIE czyta zawartości plików konfiguracyjnych (`cat ~/.ssh/config`, `cat ~/.env` — **zakazane**)
- NIE skanuje folderów `~/.ssh`, `~/.aws`, `~/.gnupg`, `~/.netrc`
- NIE zapisuje haseł, kluczy API, tokenów, sekretów
- NIE wysyła nikomu Twoich plików ani raportu (**Ty** wysyłasz je mailem)
- NIE dotyka Twoich plików projektowych ani dokumentów
- NIE modyfikuje żadnych systemowych ustawień

### Double-check przed wysłaniem

Skill na końcu sam wykonuje grep sprawdzający czy żaden plik outputu nie zawiera słów `password`, `api_key`, `secret`, `token`. Jeśli coś wyskoczy — skill natychmiast pokaże Ci to i usunie przed zapisem finalnym.

Dodatkowo możesz zrobić własny grep:

```bash
grep -iE "password|api[_-]?key|secret|token|bearer" audit-output/*.json audit-output/*.md
```

Jeśli cokolwiek wyskoczy — **nie wysyłaj**, skontaktuj się z Mateuszem.

## Co się dzieje po wysłaniu

1. Mateusz dostaje Twoje pliki mailem
2. Wkleja je do swojego analyzera (`analyzer-prompt v2`)
3. Analyzer generuje dwa raporty:
   - **Owner Mode** (dla Ciebie) — plain language, 60% o brakujących asystentach AI, 40% o lukach operacyjnych, z konkretnym "co zrobić w poniedziałek"
   - **Partner Mode** (wewnętrzny) — dla Mateusza jako wsad do rozmowy handlowej
4. Owner Mode dostajesz mailem zwrotnym — Mateusz odsyła go po przejrzeniu Twoich plików
5. Jeśli któryś wniosek Cię zainteresuje — rozmawiacie z Mateuszem o konkretnym wdrożeniu

## Problemy / wsparcie

**Instalacja wtyczki nie przeszła:**
- Komunikat `Failed to clone` albo brak programu `git` (Windows) → sprawdź `git --version`. Nie ma Gita → droga zapasowa z plikiem zip (Krok 2).
- Komunikat `Plugin "system10h-audyt" not found in marketplace` → to zwykle skutek, nie przyczyna: przewiń wyżej, pierwsza część linii (dodanie katalogu) nie przeszła. Gdy katalog jest dodany, a wtyczki nadal nie widać: `claude plugin marketplace update system10h` i jeszcze raz instalacja.
- Terminal nie zna `claude plugin` → zaktualizuj Claude Code komendą `claude update` i spróbuj ponownie.

**Audyt nie startuje po `uruchom audit-skill`:**
- Sprawdź `claude plugin list` — powinno być `system10h-audyt@system10h` i `enabled`
- Wpisz pełną nazwę: `/system10h-audyt:audit-skill`
- Instalowałeś wtyczkę w trakcie otwartej rozmowy → zamknij Claude (`/exit`) i uruchom `claude` jeszcze raz

**Skill przerwał w połowie:**
- Napisz Claude'owi "kontynuuj audit-skill od kroku X"
- Jeśli nie pamięta — uruchom od nowa, to nie kasuje wcześniej wygenerowanych plików

**Skan lokalny zwrócił pustą listę aplikacji:**
- OK, to nie problem — skill zapyta Cię o narzędzia manualnie
- `metadata.scan_coverage` ustawi się na `partial`

**Jestem na Windows i skan się wyłożył:**
- Skill automatycznie wykrywa Windows i używa PowerShell. Jeśli PowerShell zwraca błędy — skill przejdzie do pytań manualnych
- Upewnij się że uruchamiasz Claude Code z terminala z dostępem do PowerShell (cmd, PowerShell, Windows Terminal)

**Nie wiem którego narzędzia używam ile razy:**
- Podaj szacunek ("codziennie" / "kilka razy w tygodniu" / "raz na miesiąc")
- Skill tłumaczy to na `usage_level` automatycznie

**Mam wątpliwości czy wysłać plik:**
- Otwórz `tech_stack_human.md` i przejrzyj — jeśli coś Cię niepokoi, powiedz Claude'owi "usuń X z outputu"
- Skill usunie i zregeneruje

**Coś innego:**
Napisz do Mateusza: **hello@system10h.com** z tematem "Audit Skill — pytanie".

---

*System 10H Audit Skill v1.5 · wtyczka `system10h-audyt` 0.1.1 · instrukcja zaktualizowana 23.09.2026 (instalacja wtyczką z terminala, zip jako droga zapasowa).*
