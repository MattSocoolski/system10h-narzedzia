<!--
Template: tech_stack_human.md
Używany przez: audit-skill KROK 7b
Odbiorca: klient (przed wysłaniem do Mateusza)
Ton: neutralny, faktograficzny, PARTNERSKI (nie oskarżycielski — patrz SKILL.md KROK 7b "Reguła Języka Partnerskiego")
ZERO rekomendacji (rekomendacje generuje analyzer Mateusza)
-->

# Audyt Integracji Technologicznej — {client_id}

**Data wygenerowania:** {generated_at}
**Wygenerowane przez:** System 10H Audit Skill v1.2
**Co to jest:** human-readable kopia Twoich danych audytu. Ten plik jest **dla Ciebie do przejrzenia przed wysłaniem**. Mateusz analizuje głównie `tech_stack.json`, ale ten plik też może dołączyć do maila.

---

## 1. Środowisko Bliźniaka — co masz skonfigurowane

**CLAUDE.md:** {claude_md_found — znaleziony / nie znaleziony}
**DNA Bliźniaka:** gotowe w {bliznak_completeness_pct}% ({N} sekcji wypełnionych z {M} oczekiwanych — pozostałe czekają na uzupełnienie)

### Pliki konfiguracyjne

| Plik | Status | Sekcje | Obserwacje |
|---|---|---|---|
{dla każdego pliku z dane_files[]: `| {file} | {status} | {sections_filled}/{sections_total} | {key_observations — neutralnie, np. "Sekcja Ekosystem wolna do uzupełnienia, pozostałe 9/10 wypełnione" zamiast "Brak sekcji Ekosystem"} |`}

### Asystenci AI skonfigurowane
{assistants_configured — lista lub "Miejsce na pierwsze role asystenckie wolne — zespół AI do zbudowania"}

### Integracje MCP
{mcp_integrations — lista nazw serwerów lub "Brak .mcp.json — miejsce na pierwsze integracje zewnętrzne gotowe"}

### Miejsca do uzupełnienia
{gaps_detected — numerowana lista; REFRAMOWAĆ każdą pozycję z języka technicznego (dla analyzera) na partnerski (dla klienta): zamiast "Brak sekcji X" → "Sekcja X czeka na dopisanie". Zamiast "Plik Y placeholder" → "Plik Y ma szablon — do wypełnienia własnymi treściami".}

---

## 2. Profil biznesowy (Twoimi słowami)

**Branża:** {industry}

**Zespół:** {team_size} osób (sprzedaż: {sales}, marketing: {marketing}, delivery: {delivery}, admin: {admin})

**Cel 12 miesięcy:**
> {main_goal_12m}

**Bolączki które sam wskazałeś:**
1. {pain_point_1}
2. {pain_point_2}
3. {pain_point_3}

**Co już próbowaliście z AI/automatyzacją:**
{previous_ai_attempts}

---

## 3. Co masz dzisiaj (narzędzia)

### Używane intensywnie (heavy)
{lista narzędzi z `usage_level: "heavy"` — format: `- **Nazwa** (kategoria) — [notes od klienta]`}

### Używane średnio (medium)
{lista narzędzi z `usage_level: "medium"`}

### Używane okazjonalnie (light)
{lista narzędzi z `usage_level: "light"`}

### Zombie tools — masz, nie używasz
{lista narzędzi z `usage_level: "zombie"` — wykryte w skanie ale klient nie wspomniał o nich w dopytkach}

---

## 4. Twój workflow (Twoimi słowami)

**Rano otwierasz jako pierwsze:**
{morning_ritual}

**Typowy dzień sprzedażowy / operacyjny:**
{typical_sales_day — numerowana lista}

**Największe time sinks (rzeczy >5x w tygodniu ręcznie):**
{biggest_time_sinks}

---

## 5. AI — stan obecny

**Używane LLM:** {current_llms}
**Do czego używasz:** {use_cases}
**API keys:** {api_keys_owned}
**Budżet miesięczny na AI:** {monthly_ai_budget_pln} PLN

---

## 5b. Co TY byś najbardziej chciał zautomatyzować (priorytet #1 dla analizy)

> **Dlaczego tu:** Twój ból znasz Ty, nie narzędzia. Niezależnie od tego co pokazuje skan środowiska, ten jeden cytat jest pierwszym filtrem rekomendacji Mateusza.

**Cytat klienta (verbatim):**
> {user_proposed_automation.quote — dokładnie to co klient powiedział, bez parafrazy}

{jeśli user_proposed_automation.client_did_not_specify == true: "**Uwaga:** klient nie potrafił wskazać jednej rzeczy — analyzer musi wyprowadzić priorytet #1 z obserwacji workflow/tech_stack."}

---

## 6. Narzędzia z niewykorzystaną warstwą funkcji

{underutilized — format: `- **Nazwa**: dziś używasz {current_usage}, plan pozwala na {available_capacity}. Niewykorzystana warstwa to {monthly_waste_pln_estimate} PLN/mies. Cytat: "{client_quote}"`}

<!-- Reguła języka: TO NIE JEST OSKARŻENIE ("marnujesz"). TO OBSERWACJA ("masz zapas, który czeka"). -->

{jeśli metadata.personal_tools_excluded_count > 0: "### Narzędzia prywatne wykluczone ze skanu\n\nW trakcie skanu systemu znalazłem {N} narzędzi osobistych (np. komunikatory prywatne, rozrywka, gry) — wykluczyłem je automatycznie z audytu biznesowego. Lista: {personal_tools_excluded}. Jeśli któreś używasz biznesowo i omyłkowo zostało wykluczone — powiedz, dodam z powrotem."}

---

## 7. Surowe obserwacje (dla analizy Mateusza)

> **Uwaga:** Ten skill NIE generuje rekomendacji. Poniższe to SUROWE OBSERWACJE zebrane w trakcie wywiadu — Mateusz użyje ich (plus `tech_stack.json`) żeby wygenerować raport Owner Mode + Partner Mode z konkretnymi rekomendacjami asystentów AI i luk integracji.

**Obserwacje strukturalne:**
- Masz {N} narzędzi w stacku
- Z tego {N} heavy, {N} medium, {N} light, {N} zombie
- Liczba narzędzi zintegrowanych ze sobą: {N}
- Liczba narzędzi standalone: {N}
- Używasz LLM: {tak/nie}
- Masz własne API keys LLM: {tak/nie}
- `scan_coverage`: {full/partial}

---

## 8. Co dalej — jak wysłać ten audyt do Mateusza

1. **Przejrzyj ten plik** oraz `tech_stack.json` — czy wszystko się zgadza?
2. **Sprawdź `profile.md`** i `workflow.md` — czy cytaty są OK?
3. **Jeśli chcesz coś skorygować** — powiedz Claude'owi, poprawi na miejscu
4. **Spakuj wszystkie 4 pliki:**
   ```bash
   cd audit-output
   zip audyt-{nazwa-firmy}.zip tech_stack.json tech_stack_human.md profile.md workflow.md
   ```
5. **Wyślij** mailem do `hello@system10h.com` z tematem: `Audyt: {nazwa firmy}`
6. **Otrzymasz raport** Owner Mode + Partner Mode mailem zwrotnym, po przejrzeniu Twoich plików

**Bezpieczeństwo:** przed wysłaniem zrób szybki grep:
```bash
grep -iE "password|api[_-]?key|secret|token|bearer" audit-output/*.json audit-output/*.md
```
Jeśli cokolwiek wyskoczy — **nie wysyłaj**, popraw najpierw.

---

*Wygenerowane przez System 10H Audit Skill v1.1. W razie problemów pisz do Mateusza: hello@system10h.com*
