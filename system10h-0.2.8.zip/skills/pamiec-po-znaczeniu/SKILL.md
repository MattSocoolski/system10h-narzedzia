---
name: pamiec-po-znaczeniu
description: Prowadzi przez włączenie pamięci semantycznej — wyszukiwania po ZNACZENIU w plikach właściciela, na modelu działającym na jego komputerze. Zaczyna od pytania, czy indeks jest w ogóle potrzebny przy jego skali. Wywoływana wprost (`/pamiec-po-znaczeniu`).
disable-model-invocation: true
allowed-tools: Bash(node automatyzacje/*) Bash(ollama *) Bash(ls *) Bash(wc *) Read
metadata:
  dystrybucja: plugin
---

# Pamięć po znaczeniu — i pytanie, czy jest potrzebna

Prowadzisz **właściciela paczki**. Wychodzisz od rzeczy, którą łatwo sprzedać, a której
w większości przypadków **nie trzeba budować**.

> ⛔ **Ta procedura nie zgłasza się sama.** Warstwa środowiska jedzie w każdej paczce,
> a to jest rozszerzenie, nie część podstawy. Wskazuje ją człowiek, wpisując nazwę.

## Krok 0 — bramka skali. Zacznij od niej, nie pomijaj

```!
ls -1 blizniak/*.md 2>/dev/null | wc -l; wc -c blizniak/*.md 2>/dev/null | tail -1
```

**Asystent czyta pliki właściciela natywnie — bez żadnego indeksu.** Wyszukiwanie po znaczeniu
zaczyna coś dawać dopiero wtedy, gdy materiału jest tyle, że przeczytanie wszystkiego przestaje
się mieścić w jednej rozmowie. Przy kilkunastu plikach Bliźniaka indeks **nie doda nic**,
za to doda: model do pobrania, katalog do odświeżania i jedno miejsce więcej, które może się
rozjechać z rzeczywistością.

Powiedz to właścicielowi wprost i zapytaj, **co konkretnie chce znaleźć, czego dziś nie
znajduje**. Odpowiedź „no, żeby pamiętał" nie jest odpowiedzią — dopytaj o konkretny przypadek
z ostatniego tygodnia.

- **Nie ma takiego przypadku** → zapisz w `stan.md`: „pamięć semantyczna — rozważona, na razie
  niepotrzebna (skala)". To jest **prawidłowe zakończenie tej procedury**, nie porażka.
- **Jest konkretny przypadek** → idź dalej.

## Krok 1 — czy komputer to udźwignie (PYTAJ, nie zakładaj)

Zapytaj o cztery rzeczy i **nie zgaduj żadnej**: system · ile pamięci RAM · ile wolnego miejsca
na dysku · czy właściciel **może** instalować programy na tej maszynie (firmowy laptop bywa
zablokowany, antywirus potrafi protestować).

Orientacyjnie: sam model wyszukiwania to ~2-3 GB na dysku, komfortowo od 8 GB RAM. Jeśli
w grę wchodzą też inne modele lokalne, policz je razem — dzielą tę samą pamięć.

## Krok 2 — fundament: Ollama + model wyszukiwania

Właściciel robi to **sam, u siebie** (human-gate — nie instalujesz za niego):

1. pobierz i zainstaluj **Ollama** z `https://ollama.com`;
2. w terminalu: `ollama pull bge-m3`;
3. sprawdzenie: `ollama list` — model widoczny na liście.

```!
ollama list 2>/dev/null || echo "Ollama nie odpowiada — albo nie jest zainstalowana, albo nie działa w tle. To NIE znaczy, że coś jest zepsute w Systemie."
```

**Wszystko zostaje na jego komputerze.** Model liczy lokalnie, pod adresem `localhost` — żaden
fragment indeksowanej treści nie wychodzi na zewnątrz. To jest cała różnica między tym klockiem
a zwykłym wyszukiwaniem w chmurze i warto to powiedzieć wprost, bo to jest powód, dla którego
ktoś to w ogóle włącza.

⚠️ **Nie rozciągaj tego zdania na resztę Systemu.** Pobrany model dotyczy WYSZUKIWANIA.
Inne funkcje mogą korzystać z modelu w chmurze — jeśli właściciel pyta „czy teraz wszystko jest
lokalne", odpowiedź brzmi **nie**, i wymień mu, co jest czym. Nie pozwól, żeby wyszedł z tej
rozmowy z przekonaniem, którego nie potwierdziłeś.

## Krok 3 — co indeksować

Zasada: **indeksuj to, co właściciel czyta, żeby sobie przypomnieć** — nie wszystko, co ma.

- `blizniak/dna.md` i `blizniak/stan.md` — profil i stan bieżący;
- `blizniak/stan-archiwum.md` — historia, jeśli urosła na tyle, że nikt jej już nie przegląda;
- katalog kart kontaktów, jeśli właściciel go prowadzi.

Czego **nie** indeksować bez osobnej rozmowy: cudzej korespondencji i dokumentów klientów.
To są dane osób trzecich i decyzja o ich przetwarzaniu należy do właściciela, nie do Ciebie —
zapytaj i zapisz odpowiedź, zamiast rozstrzygać za niego.

## Krok 4 — uczciwa granica tego klocka

Fundament (Ollama + model) **to nie jest gotowa funkcja**. Podpięcie wyszukiwania do asystenta —
indeks nad wybranymi plikami i sposób jego odświeżania po każdej zmianie — jest **osobnym
wdrożeniem** i nie jedzie w tej paczce.

Gdy właściciel chce mieć to działające od końca do końca, zapisz w `stan.md`:
„pamięć semantyczna → osobna konsultacja" i **nie improwizuj indeksu na miejscu**. Klocek,
który udaje, że coś zbudował, jest gorszy od klocka, który mówi, gdzie się kończy.

## Czego ta procedura nie robi

- Nie instaluje niczego za właściciela.
- Nie indeksuje cudzych danych bez jego wyraźnej decyzji.
- Nie twierdzi, że po jej przejściu „wszystko działa lokalnie".
- Nie buduje indeksu — doprowadza do progu i mówi, że to próg.
