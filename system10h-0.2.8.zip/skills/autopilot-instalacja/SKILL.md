---
name: autopilot-instalacja
description: Prowadzi przez Etap 2 instalacji Email Autopilota u klienta — 15 kroków z bramkami, zatrzymaniem przy haśle i wznawianiem po przerwie. Użyj w dniu instalacji, przy komputerze klienta.
disable-model-invocation: true
argument-hint: "[id-skrzynki]"
arguments: skrzynka
allowed-tools: Bash(node "${CLAUDE_SKILL_DIR}/scripts/stan-instalacji.mjs" *) Bash(node ${CLAUDE_SKILL_DIR}/scripts/stan-instalacji.mjs *) Bash(node automatyzacje/*) Read
metadata:
  dystrybucja: plugin
  dystrybucja-zwolnienie: "warunek z 18.08 wyczerpany — Etap 2 przeszedł z ŻYWYM klientem 19.08 u Szurmaka; przebieg przerwany na adresie serwera poczty po stronie dostawcy klienta, nie na wadzie procedury (`dane/log.md`). Wystawienie do kanału: decyzja usera 26.08."
---

# Etap 2 — uruchomienie Email Autopilota

Prowadzisz **człowieka z naszej strony**, który siedzi przy komputerze klienta. Nie jesteś
samoobsługą dla klienta i nie wykonujesz za nikogo kroków, które należą do niego.

## Stan przebiegu — odczytany przed chwilą

```!
node "${CLAUDE_SKILL_DIR}/scripts/stan-instalacji.mjs" status --katalog="${CLAUDE_PROJECT_DIR}" --skrzynka="$skrzynka"
```

Powyższy odczyt jest **świeży i pochodzi z dysku**, nie z tej rozmowy. Zaczynasz od kroku,
który on wskazuje jako następny — nigdy od 2.1 „dla porządku".

Identyfikator skrzynki możesz podać przy wywołaniu (`/autopilot-instalacja <id>`). Nie podałeś —
odczyt weźmie go z zapisu przebiegu, jeśli był tam zostawiony przy kroku 2.7.

---

## Zasady, które obowiązują przez CAŁY przebieg

Nie są to kroki do odhaczenia. Obowiązują za każdym razem, gdy coś robisz — także za trzecim
razem, także gdy się śpieszysz, także gdy klient prosi, żeby pominąć.

### 1. Hasło nie przechodzi przez ciebie

Kroki **2.5** i **2.12** to **zatrzymania twarde**. Mówisz, co ma zrobić klient, oddajesz
klawiaturę i **czekasz na potwierdzenie od człowieka**. Nigdy nie prosisz o hasło, nie
przyjmujesz go w rozmowie, nie powtarzasz i nie zapisujesz. Jeśli hasło mimo wszystko padnie
w rozmowie — **powiedz to wprost i doradź natychmiastową zmianę**.

Twoja własna odpowiedź „idź dalej" nie jest potwierdzeniem. Potwierdzenie pochodzi od
człowieka, w osobnej wiadomości.

### 2. `exit 0` to hipoteza sukcesu, nie dowód

Werdykt bierzesz z **treści** wyniku, nie z kodu wyjścia. Gdy nie umiesz odczytać wyniku,
mówisz **„nie umiem odczytać"** — nigdy „w porządku". Komunikat błędu często niesie właśnie
tę informację, której szukasz; przeczytaj go, zanim uznasz, że narzędzie padło.

### 3. „NIE SPRAWDZIŁEM" nie jest zielenią

Trzy stany, nigdy dwa: **OK · PROBLEM · NIE SPRAWDZIŁEM**. Trzeciego nie zaokrąglasz w żadną
stronę. Przy każdym „nie wiem" mówisz, **kto to sprawdzi i co odblokowuje sprawdzenie**.

### 4. Czerwona sonda `\Seen` (krok 2.9) zatrzymuje dzień

`exit 2` (flaga wskakuje) **albo** `exit 3` („nie umiem sprawdzić") → **demon nie startuje
tego dnia**. Koniec dyskusji. To jedyna operacja, która może oznaczyć cudzą pocztę jako
przeczytaną — szkoda niezależna od jakości draftów i nieodwracalna dla klienta.

### 5. Bramka czerwona to PRZERWA, nie porażka

Zapisujesz stan, mówisz, od czego wracamy, i kończysz dzień. Instalacja wznawia się
następnego dnia bez utraty wcześniejszych kroków. To normalny przebieg tej procedury.

### 6. Nie wysyłasz niczego na zewnątrz

Żadnych maili, żadnych zmian w umowie, żadnych obietnic funkcji spoza wariantu, który
klient kupił. Wysyła zawsze człowiek.

---

## Jak prowadzisz jeden krok

1. **Przeczytaj krok** w `references/kroki-etap2.md` — jest tam bramka, czas i to, co masz
   powiedzieć klientowi. Ładujesz ten plik, gdy do niego dochodzisz, nie na zapas.
2. **Wykonaj** to, co należy do ciebie. To, co należy do klienta — powiedz i poczekaj.
3. **Oceń wynik z treści** (zasada 2). Trójstan, nie dwustan (zasada 3).
4. **Zapisz** — natychmiast, zanim przejdziesz dalej:

   ```
   node "${CLAUDE_SKILL_DIR}/scripts/stan-instalacji.mjs" zapisz \
        --katalog="${CLAUDE_PROJECT_DIR}" --krok=<numer> --wynik=OK|PROBLEM|NIE_SPRAWDZILEM \
        --czym="<czym to sprawdziłeś>" [--szczegol="<co dokładnie wyszło>"] [--skrzynka=<id>]
   ```

   Bez zapisu krok zniknie razem z sesją, a wznowienie każe go powtarzać.
5. **Sprawdź u źródła**, jeśli krok ma sondę:

   ```
   node "${CLAUDE_SKILL_DIR}/scripts/stan-instalacji.mjs" sprawdz \
        --katalog="${CLAUDE_PROJECT_DIR}" --krok=<numer> [--skrzynka=<id>]
   ```

   Kody: `0` OK · `2` PROBLEM · `3` NIE SPRAWDZIŁEM.

---

## Wznawianie — instalacja trwa, aż przejdzie czysto

Sesja pada, klient wychodzi, komputer się wyłącza. Wtedy:

- **Wracasz na krok wskazany przez odczyt stanu**, nie na początek.
- **Nie ufasz zapisowi tam, gdzie da się zapytać źródła.** Zapis mówi, co *deklarowaliśmy*;
  konfigurację można było odtworzyć z kopii i wpis zniknął, choć w zapisie stoi „OK".
- **Rozjazd zapis ↔ rzeczywistość to alarm z nazwaniem różnicy.** Nie idziesz dalej i nie
  cofasz kroku po cichu — mówisz człowiekowi, co się nie zgadza, i decydujecie razem.
- **Nie powtarzasz kroków oznaczonych jako niepowtarzalne.** Powtórzenie **2.7** dokłada
  drugi wpis tej samej skrzynki (dwa połączenia IDLE), **2.13** dubluje przypomnienia,
  **2.10** wysyła klientowi kolejny testowy mail, **2.12** każe mu drugi raz zmieniać hasło.
  Macierz „wolno / nie wolno / zapytaj" jest w `references/kroki-etap2.md`.

### Trzy wyjścia z pętli — i tylko trzy

| Wyjście | Kiedy | Co robisz |
|---|---|---|
| **SUKCES** | wszystkie kroki OK, a te weryfikowalne potwierdzone u źródła **w tym przebiegu** | zapisujesz datę Instalacji, składasz raport |
| **PRZERWA** | bramka czerwona albo klient wychodzi | zapisujesz stan, mówisz, od czego wracamy — to nie jest awaria |
| **STOP TWARDY** | ten sam krok **trzeci raz z tym samym wynikiem** | przestajesz próbować: „to nie jest kwestia powtórzenia, to jest problem do rozwiązania" + wypisujesz, co dokładnie wraca |

Odczyt stanu sam zgłasza STOP TWARDY — gdy go zobaczysz, nie próbujesz po raz czwarty.

---

## Krok 2.7 — jedyne miejsce, które psuje się bez hałasu

Wpis skrzynki tworzysz w **pliku danych** `automatyzacje/skrzynki.json` (lista `skrzynki`) —
nie w kodzie. Ten plik **nie przyjeżdża w paczce**: powstaje dopiero tutaj i jest własnością
klienta, więc aktualizacja Systemu nie ma prawa go nadpisać. Do 18.08 wpis siedział wewnątrz
`autopilot-config.mjs`, czyli w pliku kodu — i pierwsza aktualizacja kasowała go po cichu.

**Pominięte pole nie krzyczy — wyłącza funkcję bez słowa.** Prowadzisz przez komplet pól
z `references/pola-skrzynki.md` i przy każdym braku mówisz **skutek**, nie „brakuje pola":
bez `ghostStylePath` system pisze *naszym* stylem zamiast stylem klienta, bez `profilPath`
drafty nie znają jego firmy i nie powstaje `braki.md`, bez `tenantId` nie działa bezpiecznik
pokrycia.

Po wpisie weryfikujesz **przez uruchomienie**, nie przez odczyt pliku — konfiguracja ma się
wczytać, a skrzynka ma być w niej dokładnie raz.

---

## Windows

Cała procedura była ćwiczona na macOS. Na Windowsie krok **2.8 (autostart)** jest
**nieprzećwiczony** — oznaczasz go tak wprost i nie piszesz „gotowe". Zapisujesz wynik jako
`NIE_SPRAWDZILEM` z `--szczegol="Windows, autostart nieprzećwiczony"`, żeby raport to niósł.

---

## Koniec przebiegu

```
node "${CLAUDE_SKILL_DIR}/scripts/stan-instalacji.mjs" raport --katalog="${CLAUDE_PROJECT_DIR}"
```

Raport ma dwie części i **obie są obowiązkowe**: wynik per krok oraz osobna sekcja „czego ten
przebieg NIE sprawdził". Zastrzeżenie idzie w tym samym zapisie co werdykt — inaczej wraca
jako niespodzianka. Raport wklejasz do `dane/log.md` i karty klienta po naszej stronie.

## Odesłania

- `references/kroki-etap2.md` — 15 kroków, bramki, macierz wznawiania. Czytaj przy kroku, nie na zapas.
- `references/pola-skrzynki.md` — komplet pól wpisu skrzynki i skutek każdego pominięcia (krok 2.7).
- Źródło prawdy o krokach: procedura instalacji §4 po naszej stronie. **Przy rozjeździe wygrywa
  procedura** — zgłoś różnicę @coo, a ten skill idzie do poprawki.
