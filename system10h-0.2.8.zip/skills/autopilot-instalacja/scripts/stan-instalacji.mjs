#!/usr/bin/env node
// stan-instalacji.mjs — maszyna stanu Etapu 2. Skill jest jej KONSUMENTEM, nie odwrotnie.
//
// PO CO ISTNIEJE (decyzja usera 18.08: „będzie trzeba wznowić, aż przejdzie do końca
// bezbłędnie"): instalacja rozciąga się na godziny albo dni — sesja pada, klientka wychodzi,
// komputer się wyłącza. Bez zapisu poza sesją skill przy każdym padzie każe zaczynać od 2.1.
//
// TRZY RZECZY, KTÓRE TEN PLIK ROBI INACZEJ, NIŻ PODPOWIADA ODRUCH:
//
//   1. `status` ZAWSZE kończy się zerem. Wstrzyknięcie do skilla (`` !`...` ``) przy niezerowym
//      kodzie ABORTUJE CAŁE WYWOŁANIE — model nie zobaczyłby wtedy ani kroków, ani ostrzeżenia.
//      Werdykt siedzi w TREŚCI, nie w kodzie wyjścia (L-612). `sprawdz` — przeciwnie: to sonda
//      wołana świadomie, więc niesie trójstan w kodzie (0 · 2 · 3).
//
//   2. Wznowienie WERYFIKUJE, nie wierzy zapisowi. Zapis mówi, co DEKLAROWALIŚMY, nie co JEST
//      (L-096 · B-039). Klientka mogła odtworzyć plik z kopii i wpis skrzynki zniknął, choć
//      w zapisie stoi „2.7 = OK". Rozjazd to ALARM z nazwaniem różnicy — nie ciche cofnięcie
//      kroku i nie ciche przejście dalej.
//
//   3. Stan leży POZA katalogiem paczki. `aktualizuj-paczke.mjs` wymienia pliki systemowe
//      i skasowałby historię przebiegu (L-614). Wzorzec przepisany z `autostart-demona.mjs:51`,
//      nie wymyślony od nowa.
//
// CLI:
//   status   --katalog=<paczka> [--skrzynka=<id>]   → gdzie jesteśmy (ZAWSZE exit 0)
//   sprawdz  --krok=2.7 --katalog=<paczka> [...]    → sonda u źródła (0 OK · 2 PROBLEM · 3 nie wiem)
//   wznow    --katalog=<paczka> [--skrzynka=<id>]   → re-weryfikacja wszystkich „OK" + rozjazdy
//   zapisz   --krok=2.5 --wynik=OK --czym="..."     → wpis do zapisu przebiegu
//   raport   --katalog=<paczka>                     → raport per krok do wklejenia do log.md
//   kroki    [--markdown]                           → dane kroków (render `references/`)
//
// Zero zależności poza wbudowanymi — plik jedzie do paczki klienta.
// Testy: automatyzacje/tests/autopilot-instalacja-stan.test.mjs (+ -kroki, -bramki)
// Dotknięte prompty (B-021): @cto (owner). Review: 2026-08-25.

import { existsSync, mkdirSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { homedir } from 'node:os';

import { KROKI, POLA_SKRZYNKI, STAN, WERYFIKACJA, krokPoNumerze, renderKrokiMarkdown, renderPolaMarkdown } from './kroki-etap2.mjs';

export const WERSJA_ZAPISU = 1;

/**
 * Ile razy ten sam krok może wrócić z tym samym wynikiem, zanim przestajemy próbować (§3a.4).
 *
 * ⚠️ SKĄD TA LICZBA: **wybrana, NIE zmierzona. N=0 realnych instalacji.** Spec §7 poz. 1 wymienia
 * ją jako otwartą; właściciel pomiaru: @cto + @coo, droga wyjścia: przy pierwszej instalacji
 * zapisać, ile razy realnie wracaliśmy do tego samego kroku. Do tego czasu traktuj jak
 * oszacowanie, nie jak próg wyprowadzony z danych — i nie kopiuj jej do innych narzędzi
 * jako „nasz standard" (L-638: liczba nośna bez śladu pomiaru zaczyna odrzucać cudzą pracę).
 * Zmiana progu nie wymaga zmiany kodu wołających — `stopTwardy()` bierze go parametrem.
 */
export const PROG_STOP_TWARDY = 3;

const mow = (s = '') => console.log(s);

// ── ścieżki ──────────────────────────────────────────────────────────────────

/** Rozwija `~` i zamienia na ścieżkę bezwzględną — klientka podaje ścieżki „po ludzku". */
export function rozwin(sciezka, home = homedir()) {
  if (!sciezka) return sciezka;
  const s = sciezka.startsWith('~/') ? join(home, sciezka.slice(2)) : sciezka;
  return isAbsolute(s) ? s : resolve(s);
}

/**
 * Stan MUSI leżeć OBOK paczki, nie w niej (L-614). Wzorzec identyczny jak
 * `autostart-demona.mjs` — dwa różne narzędzia trzymające stan tej samej instalacji
 * w dwóch różnych miejscach byłyby gorsze niż jedno miejsce z niewygodną ścieżką.
 */
export const katalogStanu = (katalogPaczki) => join(dirname(rozwin(katalogPaczki)), '.asystent-stan');
export const sciezkaZapisu = (katalogPaczki) => join(katalogStanu(katalogPaczki), 'instalacja-etap2.json');

// ── zapis przebiegu ──────────────────────────────────────────────────────────

export function pustyZapis(katalogPaczki, skrzynka = null) {
  return {
    wersja: WERSJA_ZAPISU,
    katalogPaczki: katalogPaczki ? rozwin(katalogPaczki) : null,
    skrzynka,
    rozpoczeto: new Date().toISOString(),
    kroki: {},
    proby: {},
    uruchomienia: [],
  };
}

export function czytajZapis(katalogPaczki) {
  const p = sciezkaZapisu(katalogPaczki);
  if (!existsSync(p)) return { zapis: pustyZapis(katalogPaczki), istnial: false, blad: null };
  try {
    const z = JSON.parse(readFileSync(p, 'utf-8'));
    return { zapis: { ...pustyZapis(katalogPaczki), ...z }, istnial: true, blad: null };
  } catch (e) {
    // Uszkodzony zapis to NIE jest „zaczynamy od zera" — to jest fakt do powiedzenia człowiekowi.
    // Cichy reset skasowałby historię, której właśnie ten plik ma pilnować.
    return { zapis: pustyZapis(katalogPaczki), istnial: true, blad: String(e.message || e) };
  }
}

export function zapiszZapis(katalogPaczki, zapis) {
  const kat = katalogStanu(katalogPaczki);
  mkdirSync(kat, { recursive: true });
  writeFileSync(sciezkaZapisu(katalogPaczki), JSON.stringify(zapis, null, 2) + '\n', 'utf-8');
  return sciezkaZapisu(katalogPaczki);
}

/** Odcisk wyniku — po nim poznajemy „ten sam krok trzeci raz z TYM SAMYM wynikiem" (§3a.4). */
export const odcisk = (stan, szczegol = '') =>
  `${stan}::${String(szczegol).replace(/\d{4}-\d{2}-\d{2}T[\d:.]+Z?/g, '<czas>').slice(0, 200)}`;

export function zapiszKrok(zapis, { nr, stan, czymZweryfikowano = null, szczegol = '' }) {
  const kiedy = new Date().toISOString();
  zapis.kroki[nr] = { nr, stan, kiedy, czymZweryfikowano, szczegol };
  zapis.proby[nr] = [...(zapis.proby[nr] || []), { kiedy, stan, odcisk: odcisk(stan, szczegol) }];
  return zapis;
}

/**
 * STOP TWARDY: ten sam krok, ten sam wynik, trzeci raz. Bez tego progu „wznawiaj, aż przejdzie"
 * mieliłoby w nieskończoność krok, który wymaga człowieka albo dostawcy hostingu.
 * ⚠️ Próg 3 jest WYBRANY, nie zmierzony — do potwierdzenia przy pierwszej realnej instalacji.
 */
export function stopTwardy(zapis, nr, prog = PROG_STOP_TWARDY) {
  const proby = zapis.proby?.[nr] || [];
  if (proby.length < prog) return null;
  const ostatnie = proby.slice(-prog);
  if (ostatnie.some((p) => p.stan === STAN.OK)) return null;
  const pierwszy = ostatnie[0].odcisk;
  if (!ostatnie.every((p) => p.odcisk === pierwszy)) return null;
  return { nr, ile: proby.length, odcisk: pierwszy, kiedy: ostatnie.map((p) => p.kiedy) };
}

// ── sondy u źródła (§3a.2) ───────────────────────────────────────────────────

const wynik = (stan, komunikat, szczegol = '') => ({ stan, komunikat, szczegol });

/** Wczytuje `autopilot-config.mjs` z katalogu paczki. Błąd wczytania to WYNIK, nie awaria. */
export async function wczytajKonfiguracje(katalogPaczki) {
  const plik = join(rozwin(katalogPaczki), 'automatyzacje', 'autopilot-config.mjs');
  if (!existsSync(plik)) return { ok: false, powod: `nie ma pliku ${plik}`, mailboxes: null };
  try {
    const mod = await import(pathToFileURL(plik).href + `?t=${Date.now()}`);
    const mb = mod.MAILBOXES;
    if (!Array.isArray(mb)) return { ok: false, powod: 'plik wczytany, ale nie eksportuje tablicy MAILBOXES', mailboxes: null };
    return { ok: true, powod: null, mailboxes: mb, plik };
  } catch (e) {
    // L-625: „nie umiem odczytać" ≠ „nie dałem rady" — treść błędu NIESIE wynik
    // (po ręcznej edycji najczęściej: przecinek, nawias, niedomknięty cudzysłów).
    return { ok: false, powod: `konfiguracja się NIE WCZYTUJE: ${String(e.message || e).split('\n')[0]}`, mailboxes: null };
  }
}

export async function sondaWpisSkrzynki(katalogPaczki, idSkrzynki) {
  if (!idSkrzynki) {
    return wynik(STAN.NIE_SPRAWDZILEM, 'Nie wiem, którą skrzynkę sprawdzać.', 'podaj --skrzynka=<id>');
  }
  const k = await wczytajKonfiguracje(katalogPaczki);
  if (!k.ok) return wynik(STAN.PROBLEM, `Wpisu nie da się potwierdzić: ${k.powod}`, k.powod);

  const trafienia = k.mailboxes.filter((m) => m && m.id === idSkrzynki);
  if (trafienia.length === 0) {
    return wynik(
      STAN.PROBLEM,
      `W konfiguracji NIE MA wpisu „${idSkrzynki}" — a zapis mówi, że krok 2.7 był zrobiony.`,
      'brak wpisu',
    );
  }
  if (trafienia.length > 1) {
    return wynik(
      STAN.PROBLEM,
      `Wpis „${idSkrzynki}" występuje ${trafienia.length}× — demon podniesie do tej skrzynki ` +
        `${trafienia.length} połączenia IDLE. Usuń nadmiarowe, zanim pójdziesz dalej.`,
      'zdublowany wpis',
    );
  }

  const wpis = trafienia[0];
  const braki = POLA_SKRZYNKI.filter((p) => p.wymagane).filter(
    (p) => wpis[p.pole] === undefined || wpis[p.pole] === null || wpis[p.pole] === '',
  );
  if (braki.length) {
    const opis = braki.map((p) => `  • \`${p.pole}\` → ${p.gdyBrak}`).join('\n');
    return wynik(
      STAN.PROBLEM,
      `Wpis „${idSkrzynki}" jest niekompletny. Każde brakujące pole wyłącza coś BEZ SŁOWA:\n${opis}`,
      `braki: ${braki.map((p) => p.pole).join(',')}`,
    );
  }
  return wynik(STAN.OK, `Wpis „${idSkrzynki}" jest w konfiguracji, wczytuje się i ma komplet pól.`, 'komplet');
}

export function sondaPlikPoswiadczen(credsPath) {
  if (!credsPath) {
    return wynik(
      STAN.NIE_SPRAWDZILEM,
      'Nie wiem, gdzie mają leżeć poświadczenia.',
      'brak credsPath — podaj --creds=<ścieżka> albo najpierw uzupełnij wpis skrzynki (2.7)',
    );
  }
  const p = rozwin(credsPath);
  return existsSync(p)
    ? wynik(STAN.OK, `Plik poświadczeń istnieje: ${p}`, 'jest')
    : wynik(
        STAN.PROBLEM,
        `Nie ma pliku poświadczeń: ${p}. Hasło nie zostało zapisane albo trafiło gdzie indziej.`,
        'brak pliku',
      );
}

export function sondaAutostart(katalogPaczki, { spawn = spawnSync } = {}) {
  const kat = rozwin(katalogPaczki);
  const skrypt = join(kat, 'automatyzacje', 'autostart-demona.mjs');
  if (!existsSync(skrypt)) {
    return wynik(STAN.NIE_SPRAWDZILEM, `Nie ma czym sprawdzić: brak ${skrypt}.`, 'brak narzędzia');
  }
  const r = spawn(process.execPath, [skrypt, 'status', `--katalog=${kat}`], {
    encoding: 'utf-8',
    cwd: kat,
  });
  const tresc = `${r.stdout || ''}${r.stderr || ''}`.trim();
  if (r.error) return wynik(STAN.NIE_SPRAWDZILEM, `Sonda autostartu nie ruszyła: ${r.error.message}`, 'spawn padł');
  // Trójstan przepisany z `autostart-demona.mjs status`: 0 chodzi · 3 nie chodzi / brak wpisu.
  if (r.status === 0) return wynik(STAN.OK, tresc || 'Autostart chodzi.', 'chodzi');
  if (r.status === 3) return wynik(STAN.PROBLEM, tresc || 'Autostart nie chodzi.', 'nie chodzi');
  return wynik(STAN.NIE_SPRAWDZILEM, `Sonda autostartu zwróciła ${r.status}. ${tresc}`, `exit ${r.status}`);
}

export function sondaSpinacz(katalogPaczki) {
  const kat = rozwin(katalogPaczki);
  const spinacz = join(kat, 'CLAUDE.md');
  const braki = [];
  if (!existsSync(join(kat, 'blizniak'))) braki.push('`blizniak/`');
  if (!existsSync(join(kat, 'automatyzacje'))) braki.push('`automatyzacje/`');
  if (braki.length) {
    return wynik(
      STAN.PROBLEM,
      `To nie wygląda na katalog Systemu — brakuje ${braki.join(' i ')}. Uruchamiasz z właściwego miejsca?`,
      'zły katalog',
    );
  }
  if (!existsSync(spinacz)) {
    return wynik(
      STAN.PROBLEM,
      'Brak `CLAUDE.md` w katalogu Systemu = paczka sprzed 17.08. Zbuduj i zainstaluj ponownie ' +
        'albo zaktualizuj drogą §10.3 — inaczej asystent nie wstanie tam, gdzie działają narzędzia.',
      'brak spinacza',
    );
  }
  const tresc = readFileSync(spinacz, 'utf-8');
  if (!/autopilot/i.test(tresc)) {
    return wynik(
      STAN.PROBLEM,
      'Spinacz `CLAUDE.md` jest, ale NIE MA w nim sekcji Autopilota. Paczka została złożona ' +
        'bez `--wariant=email-autopilot` — to jest cicha dostawa albo funkcja przemilczana, ' +
        'zależnie od tego, co obiecuje umowa. STOP.',
      'wariant nie doszyty',
    );
  }
  return wynik(STAN.OK, 'Katalog Systemu spójny: spinacz na miejscu, sekcja Autopilota doszyta.', 'spójny');
}

/**
 * Rejestr przypomnień jest PO NASZEJ STRONIE. Na komputerze klientki tego pliku nie ma i to jest
 * poprawny stan — więc odpowiedzią jest „NIE SPRAWDZIŁEM" z drogą wyjścia, nie zieleń i nie alarm
 * (B-040 §E: każda niewiedza ma właściciela i drogę wyjścia).
 */
export function sondaPrzypomnienia(katalogPaczki, { dataInstalacji = null, sciezka = null } = {}) {
  const p = sciezka
    ? rozwin(sciezka)
    : join(rozwin(katalogPaczki), 'automatyzacje', 'state', 'reminders.json');
  if (!existsSync(p)) {
    return wynik(
      STAN.NIE_SPRAWDZILEM,
      'Rejestru przypomnień nie ma na tej maszynie — i tak ma być, bo mieszka po NASZEJ stronie. ' +
        'Sprawdź u nas: `node automatyzacje/reminders.js --list` i poszukaj wpisów +14 i +30 od Instalacji.',
      'rejestr po naszej stronie',
    );
  }
  if (!dataInstalacji) {
    return wynik(STAN.NIE_SPRAWDZILEM, 'Nie znam daty Instalacji, więc nie wiem, czego szukać.', 'brak --data');
  }
  let dane;
  try {
    dane = JSON.parse(readFileSync(p, 'utf-8'));
  } catch (e) {
    return wynik(STAN.NIE_SPRAWDZILEM, `Rejestr przypomnień jest, ale nie umiem go odczytać: ${e.message}`, 'zły JSON');
  }
  const lista = Array.isArray(dane.reminders) ? dane.reminders : Object.values(dane.reminders || {});
  const oczekiwane = [14, 30].map((d) => {
    const t = new Date(`${dataInstalacji}T00:00:00Z`);
    t.setUTCDate(t.getUTCDate() + d);
    return { dni: d, data: t.toISOString().slice(0, 10) };
  });
  const brakuje = oczekiwane.filter(
    (o) => !lista.some((r) => r && r.enabled !== false && r.schedule?.date === o.data),
  );
  if (brakuje.length) {
    return wynik(
      STAN.PROBLEM,
      `Brakuje przypomnień na: ${brakuje.map((b) => `${b.data} (+${b.dni} dni)`).join(', ')}. ` +
        'Umowa §2 ust. 1 lit. h każe złożyć zestawienie — bez wpisu nikt go nie złoży.',
      `brakuje: ${brakuje.map((b) => b.dni).join(',')}`,
    );
  }
  return wynik(STAN.OK, `Przypomnienia stoją: ${oczekiwane.map((o) => o.data).join(' i ')}.`, 'stoją');
}


/**
 * 2.12b — czy łańcuch importów `@` REALNIE dochodzi do profilu.
 *
 * Czyta pliki, nie deklaracje: `CLAUDE.md` → jego importy → ich importy. Powód osobnej sondy:
 * brakujący import NIE zgłasza błędu (zmierzone 18.08 — nic na stderr, nic w `--debug`), więc
 * jedynym sposobem odróżnienia „wciąga" od „wspomina" jest przejście łańcucha po dysku.
 * Sonda NIE mówi, co model dostał — to potrafi wyłącznie `/context` w żywej sesji. Dlatego jej
 * OK brzmi „łańcuch trzyma", a nie „boot sprawny": różnica jest w tym, kto to widział.
 */
export function sondaBootImporty(katalogPaczki) {
  const kat = rozwin(katalogPaczki);
  const spinacz = join(kat, 'CLAUDE.md');
  if (!existsSync(spinacz)) {
    return wynik(STAN.PROBLEM, 'Brak `CLAUDE.md` w katalogu Systemu — nie ma czego wczytać przy starcie.', 'brak spinacza');
  }
  const importyZ = (rel) => {
    const p = join(kat, rel);
    if (!existsSync(p)) return [];
    return readFileSync(p, 'utf-8').split('\n')
      .map((l) => l.match(/^@([^\s`]+)\s*$/)).filter(Boolean)
      .map((m) => join(dirname(rel), m[1]));
  };
  const lancuch = [];
  for (const a of importyZ('CLAUDE.md')) {
    lancuch.push(a);
    for (const b of importyZ(a)) lancuch.push(b);
  }
  if (!lancuch.length) {
    return wynik(
      STAN.PROBLEM,
      'Spinacz nikogo nie wciąga importem `@` — to paczka sprzed 19.08. Asystent wstanie bez profilu ' +
        'i będzie wyglądał zdrowo. Zbuduj paczkę ponownie albo zaktualizuj drogą §10.3.',
      'zero importów',
    );
  }
  const brakujace = lancuch.filter((r) => !existsSync(join(kat, r)));
  if (brakujace.length) {
    return wynik(
      STAN.PROBLEM,
      `Import wskazuje na plik, którego nie ma: ${brakujace.join(', ')}. Brakujący import milczy — ` +
        'ten plik po prostu nie wejdzie do kontekstu, bez żadnego ostrzeżenia.',
      `brak: ${brakujace.length}`,
    );
  }
  const doProfilu = lancuch.some((r) => /(^|\/)dna\.md$/i.test(r));
  if (!doProfilu) {
    return wynik(
      STAN.PROBLEM,
      `Łańcuch importów nie dochodzi do \`dna.md\` (widzę: ${lancuch.join(' · ')}). Asystent zna procedury, nie zna klienta.`,
      'łańcuch bez profilu',
    );
  }
  return wynik(
    STAN.OK,
    `Łańcuch trzyma: ${lancuch.join(' · ')}. TERAZ potwierdź w sesji — \`/context\` → **Memory files** ` +
      'ma wymieniać te same pliki. Dysk mówi, co ma wejść; tamta lista mówi, co WESZŁO.',
    'łańcuch trzyma',
  );
}

/**
 * Jedno wejście dla wszystkich sond. Krok bez sondy zwraca NIE SPRAWDZIŁEM z powodem —
 * nigdy zieleni (B-040 §D: cisza jest niejednoznaczna).
 */
export async function sprawdzKrok(nr, opcje = {}) {
  const krok = krokPoNumerze(nr);
  if (!krok) return wynik(STAN.NIE_SPRAWDZILEM, `Nie znam kroku „${nr}".`, 'nieznany krok');
  const { katalog, skrzynka, creds, data, reminders, deps = {} } = opcje;

  switch (krok.weryfikacja) {
    case WERYFIKACJA.WPIS_SKRZYNKI:
      return sondaWpisSkrzynki(katalog, skrzynka);
    case WERYFIKACJA.PLIK_POSWIADCZEN: {
      if (creds) return sondaPlikPoswiadczen(creds);
      const k = await wczytajKonfiguracje(katalog);
      const wpis = k.ok ? k.mailboxes.find((m) => m && m.id === skrzynka) : null;
      return sondaPlikPoswiadczen(wpis?.credsPath || null);
    }
    case WERYFIKACJA.AUTOSTART_STATUS:
      return sondaAutostart(katalog, deps);
    case WERYFIKACJA.SPINACZ_SRODOWISKA:
      return sondaSpinacz(katalog);
    case WERYFIKACJA.BOOT_IMPORTY:
      return sondaBootImporty(katalog);
    case WERYFIKACJA.PRZYPOMNIENIA:
      return sondaPrzypomnienia(katalog, { dataInstalacji: data, sciezka: reminders });
    case WERYFIKACJA.POWTORZ:
      return wynik(
        STAN.NIE_SPRAWDZILEM,
        `Krok ${nr} nie ma osobnej sondy — tańszym i pewniejszym dowodem jest wykonanie go ponownie.`,
        'do powtórzenia',
      );
    default:
      return wynik(
        STAN.NIE_SPRAWDZILEM,
        `Kroku ${nr} nie da się sprawdzić u źródła (${krok.nazwa}). Zapis mówi, co deklarowaliśmy — nie co jest.`,
        'niesprawdzalny z założenia',
      );
  }
}

// ── wznowienie: weryfikuje, nie wierzy ───────────────────────────────────────

/**
 * Dla każdego kroku zapisanego jako OK, który MA sondę, pyta źródło ponownie.
 * Rozjazd zapis ↔ rzeczywistość to ALARM z nazwaniem różnicy — nie ciche cofnięcie kroku
 * i nie ciche przejście dalej.
 */
export async function wznow(katalogPaczki, opcje = {}) {
  const { zapis, istnial, blad } = czytajZapis(katalogPaczki);
  const rozjazdy = [];
  const potwierdzone = [];
  const nieumiem = [];

  for (const krok of KROKI) {
    const z = zapis.kroki[krok.nr];
    if (!z || z.stan !== STAN.OK) continue;
    if (krok.weryfikacja === WERYFIKACJA.BRAK || krok.weryfikacja === WERYFIKACJA.POWTORZ) {
      nieumiem.push({ nr: krok.nr, nazwa: krok.nazwa, powod: krok.przyWznowieniu });
      continue;
    }
    // Kolejność ma znaczenie: identyfikator skrzynki z ZAPISU jest pamięcią poprzednich sesji,
    // a `--skrzynka` z wiersza poleceń bywa pusty przy wznowieniu. Odwrotny spread kasowałby
    // pamięć pustką i zamieniał każde wznowienie w „nie wiem, którą skrzynkę sprawdzać".
    const w = await sprawdzKrok(krok.nr, {
      ...opcje,
      katalog: katalogPaczki,
      skrzynka: opcje.skrzynka || zapis.skrzynka || null,
    });
    if (w.stan === STAN.OK) potwierdzone.push({ nr: krok.nr, nazwa: krok.nazwa, komunikat: w.komunikat });
    else rozjazdy.push({ nr: krok.nr, nazwa: krok.nazwa, stan: w.stan, komunikat: w.komunikat });
  }

  const pierwszyNiezrobiony =
    KROKI.find((k) => (zapis.kroki[k.nr]?.stan ?? null) !== STAN.OK)?.nr ?? null;
  const stopy = KROKI.map((k) => stopTwardy(zapis, k.nr)).filter(Boolean);

  return { zapis, istnial, bladZapisu: blad, rozjazdy, potwierdzone, nieumiem, pierwszyNiezrobiony, stopy };
}

// ── render dla człowieka ─────────────────────────────────────────────────────

const ikona = (s) => (s === STAN.OK ? '✅' : s === STAN.PROBLEM ? '🔴' : '🔇');

export function renderStatus(w, { katalog }) {
  const L = [];
  L.push('═══ INSTALACJA AUTOPILOTA — ETAP 2 ═══');
  L.push(`Katalog Systemu: ${rozwin(katalog)}`);
  L.push(`Zapis przebiegu: ${sciezkaZapisu(katalog)}`);

  if (w.bladZapisu) {
    L.push('');
    L.push(`🔴 ZAPIS PRZEBIEGU JEST USZKODZONY: ${w.bladZapisu}`);
    L.push('   NIE zaczynaj od zera z automatu — to jest decyzja człowieka. Historia może być do odzyskania.');
  } else if (!w.istnial) {
    L.push('');
    L.push('🆕 Pierwsze uruchomienie — zapisu jeszcze nie ma. Zaczynamy od kroku 2.1.');
  }

  const zrobione = KROKI.filter((k) => w.zapis.kroki[k.nr]?.stan === STAN.OK).length;
  L.push('');
  L.push(`Postęp: ${zrobione}/${KROKI.length} kroków zapisanych jako zrobione.`);
  if (w.zapis.skrzynka) L.push(`Skrzynka: ${w.zapis.skrzynka}`);

  if (w.stopy.length) {
    L.push('');
    L.push('🛑 STOP TWARDY — to nie jest kwestia powtórzenia, to problem do rozwiązania:');
    for (const s of w.stopy) {
      L.push(`   • krok ${s.nr}: ${s.ile} prób, ostatnie ${PROG_STOP_TWARDY} z identycznym wynikiem (${s.odcisk})`);
    }
    L.push('   Przestań próbować. Wypisz człowiekowi, co dokładnie wraca, i szukaj przyczyny poza pętlą.');
  }

  if (w.rozjazdy.length) {
    L.push('');
    L.push('⚠️ ROZJAZD ZAPIS ↔ RZECZYWISTOŚĆ — zapis mówi „zrobione", źródło mówi co innego:');
    for (const r of w.rozjazdy) L.push(`   ${ikona(r.stan)} ${r.nr} (${r.nazwa}): ${r.komunikat}`);
    L.push('   NIE idź dalej i NIE cofaj kroku po cichu. Nazwij różnicę człowiekowi i zdecydujcie razem.');
  }

  if (w.potwierdzone.length) {
    L.push('');
    L.push('✅ Potwierdzone u źródła W TYM przebiegu:');
    for (const p of w.potwierdzone) L.push(`   • ${p.nr} ${p.nazwa} — ${p.komunikat}`);
  }

  if (w.nieumiem.length) {
    L.push('');
    L.push('🔇 Zapisane jako zrobione, ale NIE SPRAWDZONE w tym przebiegu (ufamy zapisowi — i mówimy to wprost):');
    for (const n of w.nieumiem) L.push(`   • ${n.nr} ${n.nazwa} — ${n.powod}`);
  }

  L.push('');
  if (w.pierwszyNiezrobiony) {
    const k = krokPoNumerze(w.pierwszyNiezrobiony);
    L.push(`▶ NASTĘPNY KROK: ${k.nr} — ${k.nazwa} (${k.kto}, ${k.czas})`);
    if (k.zatrzymanieTwarde) L.push('  🛑 ZATRZYMANIE TWARDE: oddajesz klawiaturę i czekasz na potwierdzenie człowieka.');
    if (k.komenda) L.push(`  Komenda: ${k.komenda}`);
  } else if (w.rozjazdy.length) {
    L.push('▶ Wszystkie kroki zapisane jako zrobione, ALE są rozjazdy powyżej — to nie jest SUKCES.');
  } else {
    L.push('▶ Wszystkie kroki zrobione i potwierdzone. Zapisz datę Instalacji i złóż raport (`raport`).');
  }
  return L.join('\n');
}

/**
 * Raport czyta ZAPIS, a zapis mówi, co deklarowaliśmy. Gdyby na tym poprzestał, wklejalibyśmy
 * do `log.md` zdanie „2.8 OK" w chwili, w której sonda krzyczy, że autostartu nie ma —
 * czyli kłamstwo dokładnie w miejscu, które najbardziej boli. Dlatego raport dostaje wynik
 * re-weryfikacji i niesie rozjazdy RAZEM z werdyktem, nie w osobnym miejscu (L-628).
 */
export function renderRaport(zapis, { rozjazdy = [], stopy = [] } = {}) {
  const L = [];
  L.push('## Etap 2 — Uruchomienie Autopilota: przebieg');
  L.push('');
  L.push(`- Katalog Systemu: \`${zapis.katalogPaczki || '—'}\``);
  L.push(`- Skrzynka: \`${zapis.skrzynka || '—'}\``);
  L.push(`- Rozpoczęto: ${zapis.rozpoczeto}`);
  L.push('');
  L.push('| # | Krok | Wynik | Kiedy | Czym zweryfikowano |');
  L.push('|---|---|---|---|---|');
  for (const k of KROKI) {
    const z = zapis.kroki[k.nr];
    L.push(
      `| ${k.nr} | ${k.nazwa} | ${z ? `${ikona(z.stan)} ${z.stan}` : '— nie dotknięty'} | ` +
        `${z?.kiedy?.slice(0, 16).replace('T', ' ') || '—'} | ${z?.czymZweryfikowano || '—'} |`,
    );
  }
  if (rozjazdy.length) {
    L.push('');
    L.push('### ⚠️ Rozjazd zapis ↔ rzeczywistość (odczytany przy składaniu tego raportu)');
    L.push('');
    L.push('Zapis powyżej mówi „zrobione". Źródło w tej chwili mówi co innego:');
    L.push('');
    for (const r of rozjazdy) L.push(`- **${r.nr} ${r.nazwa}** — ${r.komunikat.split('\n')[0]}`);
  }

  if (stopy.length) {
    L.push('');
    L.push('### 🛑 Kroki, które wróciły tyle razy, że przestaliśmy próbować');
    L.push('');
    for (const s of stopy) L.push(`- **${s.nr}** — ${s.ile} prób, ostatnie ${PROG_STOP_TWARDY} identyczne`);
  }

  const niesprawdzone = KROKI.filter((k) => {
    const z = zapis.kroki[k.nr];
    return z && z.stan === STAN.NIE_SPRAWDZILEM;
  });
  L.push('');
  L.push('### Czego ten przebieg NIE sprawdził');
  if (!niesprawdzone.length) {
    const bezSondy = KROKI.filter((k) => k.weryfikacja === 'brak').map((k) => `${k.nr} ${k.nazwa}`);
    L.push(
      bezSondy.length
        ? `Kroki bez sondy u źródła (ufamy zapisowi): ${bezSondy.join(' · ')}.`
        : 'Wszystko, co dało się sprawdzić u źródła, zostało sprawdzone.',
    );
  } else {
    for (const k of niesprawdzone) L.push(`- **${k.nr} ${k.nazwa}** — ${zapis.kroki[k.nr].szczegol || 'brak szczegółu'}`);
  }
  return L.join('\n');
}

// ── CLI ──────────────────────────────────────────────────────────────────────

export function parsuj(argv) {
  const f = {};
  for (const a of argv) {
    const m = a.match(/^--([^=]+)(?:=(.*))?$/);
    if (m) f[m[1]] = m[2] === undefined ? true : m[2];
  }
  return f;
}

const POMOC = `
Maszyna stanu Etapu 2 — żeby instalację dało się wznowić, aż przejdzie czysto.

  status   --katalog=<paczka> [--skrzynka=<id>]   gdzie jesteśmy (zawsze kończy się zerem)
  sprawdz  --krok=2.7 --katalog=<paczka>          sonda u źródła (0 OK · 2 problem · 3 nie wiem)
  wznow    --katalog=<paczka>                     to samo co status — nazwa dla czytelności
  zapisz   --krok=2.5 --wynik=OK --czym="..."     wpis do zapisu przebiegu
           [--katalog=<paczka>] [--szczegol="..."] [--skrzynka=<id>]
  raport   --katalog=<paczka>                     raport per krok do wklejenia do log.md
  kroki    [--markdown] [--pola]                  dane kroków / render references/
`.trim();

export async function main(argv = process.argv.slice(2), wypisz = mow) {
  const [komenda, ...reszta] = argv;
  const f = parsuj(reszta);

  if (komenda === 'kroki') {
    if (f.markdown) {
      // Render kończy się znakiem nowej linii, a `console.log` dokłada własny — przy
      // przekierowaniu do pliku dawałoby to pustą linię i wieczny czerwony test parytetu.
      wypisz((f.pola ? renderPolaMarkdown() : renderKrokiMarkdown()).replace(/\n$/, ''));
    } else {
      for (const k of KROKI) wypisz(`${k.nr}\t${k.weryfikowalny}\t${k.powtarzalny}\t${k.nazwa}`);
    }
    return 0;
  }

  if (!komenda || !['status', 'wznow', 'sprawdz', 'zapisz', 'raport'].includes(komenda)) {
    wypisz(POMOC);
    return komenda ? 1 : 0;
  }

  if (!f.katalog) {
    // ZAWSZE zero dla `status`/`wznow`: te dwie komendy są wstrzykiwane do skilla, a niezerowy
    // kod ABORTUJE całe wywołanie — model nie zobaczyłby wtedy nawet tego komunikatu.
    wypisz('🔇 NIE SPRAWDZIŁEM — nie podałeś `--katalog=<katalog Systemu klienta>`, więc nie wiem, gdzie patrzeć.');
    wypisz('   To jest katalog, w którym `blizniak/` i `automatyzacje/` leżą obok siebie.');
    return ['status', 'wznow'].includes(komenda) ? 0 : 3;
  }

  if (komenda === 'sprawdz') {
    if (!f.krok) {
      wypisz('🔇 NIE SPRAWDZIŁEM — podaj `--krok=<numer>`.');
      return 3;
    }
    const w = await sprawdzKrok(f.krok, {
      katalog: f.katalog,
      skrzynka: f.skrzynka || null,
      creds: f.creds || null,
      data: f.data || null,
      reminders: f.reminders || null,
    });
    wypisz(`${ikona(w.stan)} ${w.stan} — krok ${f.krok}`);
    wypisz(w.komunikat);
    return w.stan === STAN.OK ? 0 : w.stan === STAN.PROBLEM ? 2 : 3;
  }

  if (komenda === 'zapisz') {
    if (!f.krok || !f.wynik) {
      wypisz('Podaj `--krok=<numer>` i `--wynik=OK|PROBLEM|NIE_SPRAWDZILEM`.');
      return 1;
    }
    const mapa = { OK: STAN.OK, PROBLEM: STAN.PROBLEM, NIE_SPRAWDZILEM: STAN.NIE_SPRAWDZILEM };
    const stan = mapa[String(f.wynik).toUpperCase()];
    if (!stan) {
      wypisz(`Nie znam wyniku „${f.wynik}". Dozwolone: OK, PROBLEM, NIE_SPRAWDZILEM.`);
      return 1;
    }
    if (!krokPoNumerze(f.krok)) {
      wypisz(`Nie znam kroku „${f.krok}". Lista: node scripts/stan-instalacji.mjs kroki`);
      return 1;
    }
    const { zapis } = czytajZapis(f.katalog);
    if (f.skrzynka) zapis.skrzynka = f.skrzynka;
    zapis.uruchomienia = [...(zapis.uruchomienia || []), { kiedy: new Date().toISOString(), co: `zapisz ${f.krok}=${stan}` }];
    zapiszKrok(zapis, {
      nr: f.krok,
      stan,
      czymZweryfikowano: f.czym || null,
      szczegol: f.szczegol || '',
    });
    const sciezka = zapiszZapis(f.katalog, zapis);
    wypisz(`${ikona(stan)} Zapisane: krok ${f.krok} = ${stan} → ${sciezka}`);
    const s = stopTwardy(zapis, f.krok);
    if (s) {
      wypisz('');
      wypisz(`🛑 STOP TWARDY: krok ${f.krok} wraca ${PROG_STOP_TWARDY}× z tym samym wynikiem.`);
      wypisz('   To nie jest kwestia powtórzenia, to jest problem do rozwiązania.');
    }
    return 0;
  }

  if (komenda === 'raport') {
    const w = await wznow(f.katalog, {
      skrzynka: f.skrzynka || null,
      creds: f.creds || null,
      data: f.data || null,
      reminders: f.reminders || null,
    });
    wypisz(renderRaport(w.zapis, { rozjazdy: w.rozjazdy, stopy: w.stopy }));
    return 0;
  }

  const w = await wznow(f.katalog, {
    skrzynka: f.skrzynka || null,
    creds: f.creds || null,
    data: f.data || null,
    reminders: f.reminders || null,
  });
  if (f.skrzynka && !w.zapis.skrzynka) w.zapis.skrzynka = f.skrzynka;
  wypisz(renderStatus(w, { katalog: f.katalog }));
  return 0;
}

// Punkt wejścia po ścieżkach RZECZYWISTYCH — porównanie napisów milczy z kodem 0, gdy
// w ścieżce jest dowiązanie (`/var` → `/private/var`), a cichy no-op w kroku instalacji
// wygląda u klientki jak „wkleiłam i nic się nie stało" (wzorzec: uruchomiono-bezposrednio.mjs).
function uruchomionoBezposrednio(metaUrl) {
  const arg = process.argv[1];
  if (!arg) return false;
  const wlasny = fileURLToPath(metaUrl);
  try {
    return realpathSync(arg) === realpathSync(wlasny);
  } catch {
    return resolve(arg) === resolve(wlasny);
  }
}

if (uruchomionoBezposrednio(import.meta.url)) {
  main().then((kod) => {
    process.exitCode = kod;
  });
}
