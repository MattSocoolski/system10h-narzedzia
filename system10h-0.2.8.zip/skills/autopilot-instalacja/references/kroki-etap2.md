<!-- PLIK GENEROWANY — nie edytuj ręcznie.
     Źródło: scripts/kroki-etap2.mjs · odśwież: node scripts/stan-instalacji.mjs kroki --markdown
     Parytet pilnuje: automatyzacje/tests/autopilot-instalacja-kroki.test.mjs -->

# Etap 2 — 15 kroków uruchomienia Autopilota

Źródło prawdy o krokach: `materialy/system10h/2026-08-08_procedura-instalacji_etap-1-i-2.md` §4.
Przy rozjeździe wygrywa procedura — ten plik idzie wtedy do poprawki, nie odwrotnie.

## Macierz wznawiania

„Wolno powtórzyć" nie jest wygodą, tylko bezpieczeństwem: bez tej kolumny wznawianie
zdubluje wpis skrzynki i wyśle klientce kolejne testowe maile.

| # | Krok | Kto | Weryfikowalny u źródła | Wolno powtórzyć | Zachowanie przy wznowieniu |
|---|---|---|---|---|---|
| 2.1 | Test serwera bez hasła | @cto | tak | tak | Powtórz — kosztuje sekundy i daje świeży odczyt serwera. |
| 2.2 | Audyt poświadczeń | @cto | tak | tak | Powtórz; pozycje „ręcznie" nadal nie są zielenią. |
| 2.3 | Paczka z HEAD z jawnym wariantem Autopilota | @cto | tak | tak | Sprawdź wersję i sumy w manifeście zamiast budować paczkę od nowa. |
| 2.4 | Rozmowa o haśle | user + klientka | **nie** | tak | Nie da się sprawdzić u źródła, czy rozmowa się odbyła — skill UFA ZAPISOWI i mówi wprost, że ufa. |
| 2.5 | Klientka wpisuje hasło | klientka | tak | tak | Sprawdź, czy plik poświadczeń ISTNIEJE — nie pytaj ponownie o hasło. Sprawdzamy fakt na dysku, nie to, czy o coś pytaliśmy. |
| 2.6 | Test połączenia | klientka | tak | tak | Powtórz — to bramka, ma być świeża. |
| 2.7 | Wpis skrzynki do konfiguracji | @cto | tak | ⛔ **NIE** | NAJPIERW sprawdź, czy wpis JEST. Jest → nie dodawaj drugiego. Nie istnieje narzędzie dopisujące wpis idempotentnie, więc powtórzenie kroku dokłada drugi wpis tej samej skrzynki, a demon podnosi do niej dwa połączenia IDLE. |
| 2.8 | Autostart | @cto | tak | tak | Sprawdź `autostart-demona.mjs status` zamiast instalować od nowa. |
| 2.9 | Sonda \Seen na jej serwerze | @cto | tak | tak | Powtórz — to bramka, ma być świeża. |
| 2.10 | Kontrola pozytywna: testowa wiadomość → szkic w Drafts | user + klientka | częściowo | ❓ pytaj | ZAPYTAJ CZŁOWIEKA, czy powtarzać — powtórzenie znaczy kolejny testowy mail do klientki. |
| 2.11 | Pokazanie `braki.md` i `propozycje-stylu.md` | user | **nie** | tak | Nie da się sprawdzić u źródła — skill UFA ZAPISOWI i mówi wprost, że ufa. |
| 2.12 | Ona zmienia hasło | klientka | **nie** | ❓ pytaj | Nie wiemy, czy zmieniła — ZAPYTAJ. Nigdy nie każ z automatu: powtórzenie tego kroku jest dla niej uciążliwe i wygląda jak nasza pomyłka. |
| 2.12a | Środowisko: jeden katalog | @cto | tak | tak | Powtórz — sprawdzenie jest darmowe. |
| 2.12b | Bramka bootu: czy asystent wstaje Z PROFILEM | @cto | tak | tak | Powtórz — sprawdzenie jest darmowe, a odpowiada na jedyne pytanie, które psuje cały dzień. |
| 2.13 | Data Instalacji + przypomnienia +14/+30 | user | tak | ⛔ **NIE** | Sprawdź, czy przypomnienia JUŻ stoją — powtórzenie kroku dubluje je i zamienia jeden ping w dwa. |

## Kroki

### 2.1 — Test serwera bez hasła

- **Kto:** @cto · **czas:** ~1 min
- **Po co:** Czy serwer umie IDLE i jakie ma metody logowania — zanim padnie hasło.
- **Komenda:** `node automatyzacje/imap-capability-check.mjs <host-jej-serwera>`
- **Bramka:** Czytaj TREŚĆ wyniku, nie kod wyjścia. Brak IDLE → powiedz wprost, że obietnica latencji jest wtedy inna (odpytywanie co kilka minut zamiast reakcji od razu).
- **Przy wznowieniu:** Powtórz — kosztuje sekundy i daje świeży odczyt serwera. _(weryfikacja: `powtorz`)_

### 2.2 — Audyt poświadczeń

- **Kto:** @cto · **czas:** 0,1 s maszyna + ~15 min ręcznie
- **Po co:** Czy jej hasło już do nas nie trafiło odruchowo — PRZED instalacją, nie po.
- **Komenda:** `node automatyzacje/audyt-poswiadczen.mjs`
- **Bramka:** Pozycje oznaczone jako „do przejścia ręcznie" (poczta / komunikatory / kopie zapasowe) NIE SĄ ZIELENIĄ. Wypisz je człowiekowi jako listę do przejścia, nie zwijaj do „czysto".
- **Przy wznowieniu:** Powtórz; pozycje „ręcznie" nadal nie są zielenią. _(weryfikacja: `powtorz`)_

### 2.3 — Paczka z HEAD z jawnym wariantem Autopilota

- **Kto:** @cto · **czas:** 0,4 s
- **Po co:** Wersja i suma kontrolna lądują w manifeście — dowód, co dokładnie pojechało.
- **Komenda:** `node automatyzacje/zbuduj-paczke-klienta.mjs --blizniak=<katalog> --wariant=email-autopilot`
- **Bramka:** Bez `--wariant=email-autopilot` Autopilot NIE jedzie (umowa §8 ust. 3: klientka ma o nim usłyszeć, więc dostawa jest jawna). Dowodem dostawy jest `blizniak/INSTRUKCJA_AUTOPILOT.md` + sekcja Autopilota w spinaczu, nie obecność pliku `.mjs`. Brak warstwy integralności (wersja + sumy w manifeście) → STOP. Klient JUŻ zainstalowany → nie buduj od nowa, idź drogą B z §10.3 procedury (`aktualizuj-paczke.mjs`).
- **Przy wznowieniu:** Sprawdź wersję i sumy w manifeście zamiast budować paczkę od nowa. _(weryfikacja: `powtorz`)_

### 2.4 — Rozmowa o haśle

- **Kto:** user + klientka · **czas:** 👤 10 min
- **Po co:** Ona ma rozumieć klasę ryzyka PRZED wpisaniem hasła, nie po (umowa §8 ust. 4).
- **Powiedz / pokaż:**
  - co hasło daje Systemowi: czytanie jej skrzynki i zapis wersji roboczych — nic nie wychodzi samo,
  - jak to cofnąć: zmiana hasła w panelu hostingu odcina dostęp w tej samej minucie,
  - dlaczego nie ma tu „hasła aplikacji": cyber_Folks nie wystawia osobnych haseł dla programów,
  - gdzie hasło leży: na JEJ dysku, w jej katalogu domowym — u nas go nie ma i nie będzie.
- **Bramka:** Rozmowa prowadzi człowiek. Skill wypisuje, o czym trzeba powiedzieć — i tyle.
- **Przy wznowieniu:** Nie da się sprawdzić u źródła, czy rozmowa się odbyła — skill UFA ZAPISOWI i mówi wprost, że ufa. _(weryfikacja: `brak`)_

### 2.5 — Klientka wpisuje hasło

- **Kto:** klientka · **czas:** 👤 ~10 min (przebieg maszynowy 5,7 s)
- **Po co:** Hasło trafia na jej dysk, z jej klawiatury — ekran nic nie wyświetla.
- **Komenda:** `node automatyzacje/setup-poczta.mjs`
- **Bramka:** ZATRZYMANIE TWARDE. Oddaj klawiaturę i czekaj na potwierdzenie CZŁOWIEKA. Jeśli prosisz o hasło — to pomyłka po Twojej stronie. Hasło nie pada w rozmowie, nie jest zapisywane, nie jest powtarzane. Padło mimo wszystko → powiedz to wprost i doradź zmianę.
- 🛑 **ZATRZYMANIE TWARDE — czekasz na człowieka.**
- **Przy wznowieniu:** Sprawdź, czy plik poświadczeń ISTNIEJE — nie pytaj ponownie o hasło. Sprawdzamy fakt na dysku, nie to, czy o coś pytaliśmy. _(weryfikacja: `plik-poswiadczen`)_

### 2.6 — Test połączenia

- **Kto:** klientka · **czas:** ~1 min
- **Po co:** Wizard sam mówi: „Połączenie OK" / „hasło odrzucone" / „nie znaleziono serwera".
- **Bramka:** Czerwone = STOP DNIA. Nie idziemy dalej, nie próbujemy obejść.
- **Przy wznowieniu:** Powtórz — to bramka, ma być świeża. _(weryfikacja: `powtorz`)_

### 2.7 — Wpis skrzynki do konfiguracji

- **Kto:** @cto · **czas:** <0,1 s
- **Po co:** Komplet pól — bo pominięte pole nie krzyczy, tylko wyłącza funkcję bez słowa.
- **Komenda:** `utworzenie pliku danych: automatyzacje/skrzynki.json → lista `skrzynki``
- **Bramka:** Niekompletny wpis NIE PRZECHODZI. Przy każdym brakującym polu nazwij SKUTEK (patrz `references/pola-skrzynki.md`). Po wpisie weryfikuj PRZEZ URUCHOMIENIE: konfiguracja ma się wczytać, a liczba skrzynek wzrosnąć o jeden. Plik NIE przyjeżdża w paczce — u klienta powstaje dopiero tutaj, a aktualizacja nie ma prawa go nadpisać (kontrakt PLIKI_KLIENTA).
- **Przy wznowieniu:** NAJPIERW sprawdź, czy wpis JEST. Jest → nie dodawaj drugiego. Nie istnieje narzędzie dopisujące wpis idempotentnie, więc powtórzenie kroku dokłada drugi wpis tej samej skrzynki, a demon podnosi do niej dwa połączenia IDLE. _(weryfikacja: `wpis-skrzynki`)_

### 2.8 — Autostart

- **Kto:** @cto · **czas:** <0,1 s
- **Po co:** Asystent wstaje po włączeniu komputera i wraca po padzie.
- **Komenda:** `node automatyzacje/autostart-demona.mjs zainstaluj --katalog=<katalog-paczki>`
- **Bramka:** macOS: dowiedzione na żywym launchd 08.08 (zabity proces wraca po ~30 s). WINDOWS: NIEPRZEĆWICZONE — oznacz tak wprost, nie pisz „gotowe".
- **Przy wznowieniu:** Sprawdź `autostart-demona.mjs status` zamiast instalować od nowa. _(weryfikacja: `autostart-status`)_

### 2.9 — Sonda \Seen na jej serwerze

- **Kto:** @cto · **czas:** 0,1 s
- **Po co:** Czy nasze czytanie NIE oznacza jej poczty jako przeczytanej.
- **Komenda:** `node automatyzacje/sonda-peek-seen.mjs --host=<host> --creds=<credsPath> --identity=<adres>`
- **Bramka:** ZATRZYMANIE BRAMKI: `exit 2` (\Seen wskakuje) ALBO `exit 3` („NIE SPRAWDZIŁEM") → DEMON NIE STARTUJE TEGO DNIA. „Nie sprawdziłem" nie jest zielenią — powiedz to po ludzku i podaj, co odblokowuje sprawdzenie.
- **Przy wznowieniu:** Powtórz — to bramka, ma być świeża. _(weryfikacja: `powtorz`)_

### 2.10 — Kontrola pozytywna: testowa wiadomość → szkic w Drafts

- **Kto:** user + klientka · **czas:** 👤 ~5 min
- **Po co:** Odbiór techniczny to ŻYWY DRAFT w jej Drafts, nie komunikat „proces działa".
- **Bramka:** Brak szkicu → odbiór nieudany, choćby wszystko inne świeciło na zielono.
- **Przy wznowieniu:** ZAPYTAJ CZŁOWIEKA, czy powtarzać — powtórzenie znaczy kolejny testowy mail do klientki. _(weryfikacja: `brak`)_

### 2.11 — Pokazanie `braki.md` i `propozycje-stylu.md`

- **Kto:** user · **czas:** 👤 2 min
- **Po co:** To są dwa pliki, którymi System sam się do niej odzywa.
- **Powiedz / pokaż:**
  - `braki.md` — pytania, na które System nie znalazł odpowiedzi w jej profilu firmy,
  - `propozycje-stylu.md` — poprawki, które powtórzyła trzy razy, więc System proponuje je na stałe,
  - oba leżą obok jej `dna.md`; bez zaglądania tam obie pętle piszą do szuflady.
- **Bramka:** Z checklisty C — pominięcie zostawia dwie pętle bez odbiorcy.
- **Przy wznowieniu:** Nie da się sprawdzić u źródła — skill UFA ZAPISOWI i mówi wprost, że ufa. _(weryfikacja: `brak`)_

### 2.12 — Ona zmienia hasło

- **Kto:** klientka · **czas:** 👤 ~5 min
- **Po co:** Czynność ODBIORU (umowa §8 ust. 6), nie zalecenie na później.
- **Komenda:** `panel hostingu + node automatyzacje/setup-poczta.mjs (nowe hasło)`
- **Bramka:** ZATRZYMANIE TWARDE. Bez naszego udziału i bez naszej obecności przy klawiaturze. Skill czeka na potwierdzenie człowieka.
- 🛑 **ZATRZYMANIE TWARDE — czekasz na człowieka.**
- **Przy wznowieniu:** Nie wiemy, czy zmieniła — ZAPYTAJ. Nigdy nie każ z automatu: powtórzenie tego kroku jest dla niej uciążliwe i wygląda jak nasza pomyłka. _(weryfikacja: `brak`)_

### 2.12a — Środowisko: jeden katalog

- **Kto:** @cto · **czas:** <1 min
- **Po co:** W katalogu Systemu (tym z `blizniak/` i `automatyzacje/` obok siebie) musi leżeć `CLAUDE.md`; `claude` uruchamia się STAMTĄD, nie z `blizniak/`.
- **Bramka:** Brak `CLAUDE.md` w tym katalogu = paczka sprzed 17.08 → zbuduj i zainstaluj ponownie albo zaktualizuj drogą §10.3. Rozjazd wariantu (Autopilot obiecany, sekcji w spinaczu nie ma) → STOP: to klasa „cicha dostawa albo funkcja przemilczana".
- **Przy wznowieniu:** Powtórz — sprawdzenie jest darmowe. _(weryfikacja: `spinacz-srodowiska`)_

### 2.12b — Bramka bootu: czy asystent wstaje Z PROFILEM

- **Kto:** @cto · **czas:** <1 min
- **Po co:** Pliki profilu mają być W KONTEKŚCIE sesji, nie tylko na dysku. 2.12a mówi, że plik LEŻY — to dwie różne rzeczy i awaria z 18.08 przeszła dokładnie przez tę różnicę.
- **Bramka:** Sonda czyta łańcuch importów `@` z dysku. Po niej ZAWSZE potwierdź w sesji: wpisz `/context` i przeczytaj listę **Memory files** — muszą tam być wszystkie pliki z łańcucha. Któregoś nie ma → STOP, nie zaczynaj sesji szkoleniowej: asystent odpowiada płynnie i nie zna klienta, więc po rozmowie tego NIE poznasz. Suma kontrolna paczki zgadza się także wtedy, gdy import nie trafia w nic.
- **Przy wznowieniu:** Powtórz — sprawdzenie jest darmowe, a odpowiada na jedyne pytanie, które psuje cały dzień. _(weryfikacja: `boot-importy`)_

### 2.13 — Data Instalacji + przypomnienia +14/+30

- **Kto:** user · **czas:** <0,1 s
- **Po co:** Data Instalacji = dzień PÓŹNIEJSZEGO z Uruchomień. Umowa §2 ust. 1 lit. h każe złożyć zestawienie po 14 i 30 dniach — bez przypomnień nikt go nie złoży.
- **Komenda:** `node automatyzacje/dziennik-pracy.mjs --start=<data-instalacji> --skrzynka=<id>`
- **Bramka:** Rejestr przypomnień jest PO NASZEJ STRONIE, nie na komputerze klientki. Na jej maszynie ten krok kończy się werdyktem „NIE SPRAWDZIŁEM" z nazwaniem, gdzie sprawdzić.
- **Przy wznowieniu:** Sprawdź, czy przypomnienia JUŻ stoją — powtórzenie kroku dubluje je i zamienia jeden ping w dwa. _(weryfikacja: `przypomnienia`)_
