---
name: autopilot
description: Podłącza i prowadzi Email Autopilota na WŁASNEJ skrzynce właściciela paczki — sprawdza stan na żywo, dokłada skrzynkę (także drugą, np. Gmail obok iCloud), pilnuje, żeby czytanie nie oznaczało poczty jako przeczytanej, i ustawia wstawanie po włączeniu komputera. Wywoływana wyłącznie wprost (`/autopilot`) — patrz uwaga o cichej dostawie niżej.
disable-model-invocation: true
argument-hint: "[id-skrzynki]"
arguments: skrzynka
allowed-tools: Bash(node automatyzacje/*) Read
metadata:
  dystrybucja: plugin
---

> ⛔ **Czemu ta procedura NIE zgłasza się sama** (`disable-model-invocation: true`).
> Warstwa środowiska jedzie w KAŻDEJ paczce, a Email Autopilot jest **dodatkiem**, nie
> częścią podstawowego zakresu. Gdyby ta procedura sama proponowała się na zdanie „podłącz
> mi pocztę", asystent oferowałby funkcję klientowi, który jej nie kupił — cicha dostawa
> poza umową, dokładnie to, przed czym broni jawność wariantu `--wariant=email-autopilot`.
> U klienta, który Autopilota MA, komendę wskazuje blok środowiska doszywany z wariantem;
> u pozostałych ten plik po prostu leży i milczy. Nie zdejmuj tej flagi bez decyzji @prod.

# Autopilot na Twojej skrzynce

Prowadzisz **właściciela skrzynki** — człowieka, który siedzi przy swoim komputerze i chce,
żeby System zostawiał mu gotowe szkice odpowiedzi. Nie ma obok nikogo od nas.

To jest inna procedura niż `/autopilot-instalacja` (tamta prowadzi NASZEGO człowieka przez
dzień instalacji u klienta, ma 15 kroków i twarde bramki). Tutaj prowadzisz właściciela
przez jego własną skrzynkę i **wolno Ci skończyć na tym, że coś jeszcze nie jest gotowe** —
pod warunkiem, że powiesz to wprost.

## Stan — odczytany przed chwilą, z dysku

```!
node automatyzacje/skrzynka-wpis.mjs lista 2>&1 || true
```

```!
node automatyzacje/autostart-demona.mjs status 2>&1 || true
```

```!
test -n "$ANTHROPIC_API_KEY" && echo "klucz API: JEST" || echo "klucz API: BRAK — autopilot napisze zero szkiców"
```

Te trzy odczyty pochodzą **z maszyny, nie z tej rozmowy**. Zaczynasz od tego, co mówią —
nigdy od pierwszego kroku „dla porządku". Jeśli któryś odczyt jest nieczytelny, mówisz
**„nie umiem tego odczytać"** i pytasz. Nigdy „chyba w porządku".

---

## Cztery zasady, które obowiązują przez cały czas

### 1. Hasło nie przechodzi przez Ciebie

Nigdy nie prosisz o hasło, nie przyjmujesz go w rozmowie, nie powtarzasz i nie zapisujesz.
Hasło aplikacji właściciel wpisuje **sam**, w osobnej komendzie:

```
node automatyzacje/setup-poczta.mjs
```

Oddajesz klawiaturę i czekasz na potwierdzenie od człowieka, że skończył. Twoje własne
„idź dalej" nie jest potwierdzeniem. Jeśli hasło mimo wszystko padnie w rozmowie —
**powiedz to wprost i doradź natychmiastową zmianę**.

Do wpisu skrzynki podajesz wyłącznie **ścieżkę** do pliku z hasłem (`--creds=…`). Narzędzie
wpisu odmówi pracy, gdyby ktoś próbował podać hasło w argumencie — i dobrze, bo argumenty
komend widać w historii powłoki.

### 2. Autopilot nigdy nie wysyła

Kończy pracę w chwili, gdy szkic leży w folderze roboczym. Wysyła człowiek, klikając.
Jeśli właściciel prosi „a niech od razu odpowiada" — mówisz, że tego nie robimy, i dlaczego:
odpowiedź w jego imieniu bez jego oczu to nie oszczędność, tylko cudza decyzja podpisana
jego nazwiskiem.

### 3. „Nie sprawdziłem" nie jest zielenią

Trzy odpowiedzi są dozwolone: **działa** · **jest problem** · **nie sprawdziłem**.
Cisza narzędzia nie znaczy „w porządku" — znaczy, że nikt nie patrzył. Gdy sonda nie umie
odpowiedzieć, to jest wynik do zgłoszenia właścicielowi, nie powód do przejścia dalej.

### 4. Werdykt bierzesz z treści, nie z kodu wyjścia

`exit 0` to hipoteza sukcesu. Czytasz, co narzędzie napisało.

---

## Program pocztowy nie ma tu nic do rzeczy — powiedz to od razu

Właściciel prawie zawsze pyta: *„a czy to zadziała, skoro ja mam Apple Mail / Outlooka /
Thunderbirda?"*. Odpowiedź brzmi: **tak, i jego program nie ma z tym nic wspólnego.**

System łączy się **z serwerem poczty**, tak samo jak jego program pocztowy — tylko obok
niego, nie przez niego. Szkic ląduje w folderze roboczym na serwerze, więc pojawia się
w jego programie sam, jak każda inna wersja robocza. Nie trzeba niczego instalować w Apple
Mailu, nie trzeba go mieć otwartego, nie trzeba go zamykać.

Praktyczny skutek, o którym warto powiedzieć od razu: **jeśli w jednym programie ma
podpięte dwie skrzynki — na przykład iCloud i Gmail — to są dla nas dwie osobne skrzynki**,
każda z własnym hasłem aplikacji i własnym wpisem. Nie jedna dlatego, że widać je w jednym
oknie.

---

## Krok 1 — czy w ogóle jest co podłączać

Zanim ktokolwiek dotknie hasła, sprawdź serwer. To kosztuje sekundy i **nie wymaga hasła**:

```
node automatyzacje/imap-capability-check.mjs <host>
```

Host bierzesz z tego, czego właściciel używa: `imap.mail.me.com` (iCloud),
`imap.gmail.com` (Gmail / Google Workspace), `outlook.office365.com` (Microsoft),
albo host od jego administratora poczty.

Co z tym zrobić:
- **jest IDLE** → System reaguje na nową pocztę w sekundach; tak możesz to opisać;
- **IDLE niepotwierdzone** → **nie obiecuj sekund**. Powiedz, że System będzie zaglądał do
  skrzynki cyklicznie, i że po podłączeniu da się to dosprawdzić.

## Krok 2 — hasło aplikacji (robi to właściciel, nie Ty)

Hasło aplikacji to **nie** hasło do konta — to osobny ciąg, który da się w każdej chwili
unieważnić, nie ruszając hasła głównego. Powiedz, gdzie go szukać:

- **iCloud** — account.apple.com → Bezpieczeństwo → Hasła aplikacji (wymaga logowania dwuetapowego).
- **Gmail / Google Workspace** — hasła aplikacji wymagają włączonej weryfikacji dwuetapowej,
  a w koncie firmowym **administrator może je mieć wyłączone**. To trzeba sprawdzić PRZED
  instalacją, nie w jej trakcie — jeśli są wyłączone, ta skrzynka nie wchodzi tą drogą
  i jest to rozmowa z jego administratorem, nie z nami.
- **Skrzynka na własnym hostingu** — część hostingów w ogóle nie ma haseł aplikacji.
  Wtedy podłączenie wymaga **prawdziwego hasła do poczty**, którego nie da się unieważnić
  inaczej niż zmianą hasła. To inna klasa ryzyka — powiedz to wprost i zapytaj, czy właściciel
  się na nią godzi, zanim cokolwiek pójdzie dalej.

Właściciel uruchamia `node automatyzacje/setup-poczta.mjs`, wybiera dostawcę i wpisuje hasło
sam. Ty czekasz. Potem sprawdzasz **fakt na dysku** — czy plik poświadczeń istnieje — a nie
to, czy o coś pytaliście.

## Krok 3 — wpis skrzynki

```
node automatyzacje/skrzynka-wpis.mjs dodaj \
  --id=<krótka-nazwa> --preset=<icloud|gmail|outlook> \
  --identity=<adres@…> --creds=<ścieżka do pliku z hasłem> \
  --profil=blizniak/dna.md --styl=blizniak/dna.md \
  --podpis="<Imię, którym podpisuje odpowiedzi>" \
  --tenant=<krótka-nazwa-właściciela> --leady=blizniak/encje
```

**Powtórzenie tej komendy jest bezpieczne** — identyczny wpis nie zostanie dopisany drugi
raz. Narzędzie odmówi natomiast, gdy ten sam adres miałby trafić pod dwie nazwy (bo wtedy
System łączyłby się do jednej skrzynki dwa razy) albo gdy istniejący wpis miałby zostać po
cichu podmieniony. Odmowa mówi, czym wpis się różni.

Druga skrzynka to **drugie wywołanie tej samej komendy** z innym `--id`, `--preset`
i `--identity`. Nic więcej.

Gdy narzędzie zgłosi funkcje „wyłączone po cichu" — **przeczytaj właścicielowi skutek**,
nie nazwę pola. „Drafty nie będą znały Twojej firmy ani cennika" znaczy dla niego coś;
„brakuje `profilPath`" nie znaczy nic. Jeśli świadomie z czegoś rezygnuje, powtórzcie
komendę z `--swiadomie-bez=<pole>` — wtedy to jest jego decyzja, a nie Wasze przeoczenie.

## Krok 4 — bramka: czy czytanie nie oznacza poczty jako przeczytanej

```
node automatyzacje/sonda-peek-seen.mjs
```

To jest **bramka, nie formalność**. System pobiera treść wiadomości, żeby odpowiadać na
to, co w niej jest — a pobranie treści na źle zachowującym się serwerze potrafi oznaczyć
cudzą wiadomość jako przeczytaną. Dla właściciela to osobna szkoda, niezależna od jakości
szkiców: przestaje widzieć, czego jeszcze nie czytał.

- **sonda mówi, że `\Seen` nie wskakuje** → idziecie dalej;
- **sonda mówi cokolwiek innego, w tym „nie sprawdziłem"** → **zatrzymujesz się**. Nie
  zostawiacie Systemu pracującego na noc. To jest do zgłoszenia nam, nie do obejścia.

⚠️ **Zasięg tego, co zmierzone, uczciwie:** sonda była przepuszczona na iCloud i na Zoho
i tam `\Seen` nie wskakuje. **Na serwerach Gmaila i Microsoftu nikt jej u nas nie przepuszczał** —
więc dla takiej skrzynki jest to prawdziwe „nie sprawdziłem" i sondę trzeba uruchomić,
a nie założyć wynik z tego, że gdzie indziej wyszło dobrze.

## Krok 5 — klucz do modelu

Szkice pisze model, a model wymaga **własnego klucza API** (`ANTHROPIC_API_KEY`). To jest
coś innego niż subskrypcja Claude Code — bez klucza demon wstanie i **nie napisze ani
jednego szkicu**. Odczyt na górze tej procedury mówi, czy klucz jest.

Nie ma klucza → to jest rozmowa o pieniądzach i o tym, na czyim koncie ma być rozliczany.
**Nie rozstrzygaj tego sam** — powiedz właścicielowi, że to trzeba ustalić z Mateuszem,
i na tym poprzestań.

## Krok 6 — pierwszy przebieg i wstawanie po włączeniu komputera

Najpierw jeden przebieg na oczach właściciela:

```
node automatyzacje/autopilot-daemon.mjs
```

Pokaż mu **gotowy szkic w jego programie pocztowym** — to jest moment, w którym funkcja
zaczyna dla niego istnieć. Dopóki nie zobaczył szkicu, „działa" jest Twoim zdaniem, nie jego.

Dopiero potem:

```
node automatyzacje/autostart-demona.mjs zainstaluj
```

⚠️ Na macOS to było **przećwiczone na żywo** (zabity proces wraca sam). Na Windowsie
generowanie zadania jest sprawdzone testem, ale **uruchomienia nikt u nas nie przećwiczył** —
mów o tym uczciwie i poproś o zgłoszenie, gdyby coś nie wstało.

---

## Gdy właściciel mówi „autopilot nie robi szkiców"

Idź po kolei, od najczęstszej przyczyny, i **za każdym razem czytaj treść wyniku**:

1. `node automatyzacje/skrzynka-wpis.mjs sprawdz --id=<nazwa>` — czy wpis w ogóle jest,
   czy nie ma go podwójnie, czy wczytywacz go podnosi.
2. Klucz API — odczyt z góry procedury. Brak = zero szkiców, i to jest cała przyczyna.
3. `node automatyzacje/autostart-demona.mjs status` — czy demon w ogóle chodzi.
4. Czy szkice mają skąd wziąć wiedzę o jego firmie — jeśli wpis nie ma profilu, szkice są
   ogólne i **to nie jest awaria, tylko brakujący wpis**.
5. Czy poczta, o której mówi, w ogóle wpada na **tę** skrzynkę. Przy dwóch kontach w jednym
   programie to jest najczęstsze nieporozumienie: patrzy na jedną, podłączona jest druga.

Nie zgadujesz przyczyny. Jeśli po tych pięciu punktach nie wiesz — mówisz, że nie wiesz,
i zapisujesz, co sprawdziłeś, żeby my nie zaczynali od zera.

## Czego ta procedura nie robi

- Nie wysyła poczty i nie da się jej o to poprosić.
- Nie dotyka hasła.
- Nie zmienia niczego w programie pocztowym właściciela.
- Nie rozstrzyga pieniędzy — ani za klucz API, ani za zakres wdrożenia.
