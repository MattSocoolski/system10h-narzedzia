# System 10H — Audit Skill v1.1

Claude Code skill który przeprowadza klienta przez głęboki audyt środowiska Bliźniaka (konfiguracja AI + tech_stack + workflow + profil biznesowy) i generuje pliki wejściowe dla analyzera System 10H (`analyzer-prompt v2`).

## Co to jest

`audit-skill` to markdown-first Claude Code skill. Klient dostaje ten folder (zip), wrzuca do `~/.claude/skills/audit-skill/`, odpala Claude Code i pisze "uruchom audit-skill". Claude prowadzi 15-25 minutowy wywiad, **głęboko skanuje środowisko Bliźniaka** (CLAUDE.md → dane/*.md → .mcp.json → konfiguracja), skanuje zainstalowane narzędzia systemowe, i generuje 4 pliki outputu w `./audit-output/`:

- `tech_stack.json` — machine-readable, główny input dla analyzera
- `tech_stack_human.md` — human-readable, kopia dla klienta
- `profile.md` — profil biznesowy cytatami klienta
- `workflow.md` — workflow + AI usage cytatami klienta

Klient wysyła te pliki mailem do `hello@system10h.com`, Mateusz wkleja do analyzera, wraca w 48h z raportem Owner Mode + Partner Mode.

## Dla kogo

**Klienci System 10H** — SMB B2B 5-50 osób, którzy mają Claude Code w terminalu i chcą audytu integracji + rekomendacji asystentów AI.

## Struktura folderu

```
audit-skill/
├── SKILL.md                                  ← Główny plik: instrukcje dla Claude Code
├── INSTRUKCJA.md                             ← Instrukcja dla klienta (1-pager)
├── MAIL-HANDSHAKE.md                         ← Template maila Mateusza po otrzymaniu plików
├── README.md                                 ← Ten plik
├── BRIEF-NEXT-SESSION.md                     ← WEWNĘTRZNY — brief build sesji (NIE w zipie klienta)
└── output-schema/
    ├── tech_stack.schema.md                  ← Schemat JSON outputu
    └── tech_stack_human.template.md          ← Template human-readable raportu
```

## Jak użyć (klient)

Patrz `INSTRUKCJA.md` — 3 kroki: rozpakuj, odpal Claude Code, napisz "uruchom audit-skill".

## Jak edytować (Mateusz)

Ten folder jest **source of truth** dla skilla. Po edycji:

1. Test lokalnie — kopiuj `audit-skill/` do `~/.claude/skills/audit-skill/` i przejdź pełen flow
2. Jeśli OK — spakuj: `cd system10h && zip -r audit-skill-v1.1.zip audit-skill/ -x '*README-SCAFFOLD*' '*BRIEF-NEXT-SESSION*'`
3. Wyślij nowej wersji klientom (mailem lub przez GDrive)

## Architektura — dlaczego Claude Code Skill a nie custom runner

Design doc `materialy/system10h/2026-04-14_cto_radar_audyt_integracji_design.md` zakładał custom Node.js runner (9.5h build + dystrybucja binariów). **Odrzucony 15.04.2026** bo:

1. Klient ma Claude Code terminal + subskrypcję (decyzja 15.04)
2. Markdown-first = 2.5-4h build zamiast 9.5h
3. Zero maintenance binariów — edit markdown, commit, re-send
4. Klient widzi co skill robi (czyta SKILL.md) = transparentność + bezpieczeństwo
5. Leverage Claude Code capabilities (Bash, Read, Write, Grep) zamiast pisania własnego runtime

**Kompromis:** wymaga od klienta Claude Code (akceptowalne — klient 10H = ICP z terminalem + AI).

## Bezpieczeństwo

- Skill CZYTA treść plików .md w środowisku klienta (dane/*.md, CLAUDE.md) — to jest kluczowy input audytu
- Skill CZYTA .mcp.json ale wyciąga TYLKO nazwy serwerów (NIGDY klucze/tokeny)
- Skill NIGDY nie skanuje `~/.ssh`, `~/.aws`, `~/.gnupg`, `~/.netrc`
- Skill NIGDY nie zapisuje haseł, kluczy API, tokenów, sekretów
- Pliki wyniku zostają u Ciebie i wysyłasz je Ty — treść skanu trafia do dostawcy modelu na Twoim koncie, tak samo jak przy każdej innej pracy z asystentem
- Na końcu skill wykonuje grep security check na wszystkich plikach outputu

Pełne reguły bezpieczeństwa — patrz `SKILL.md` sekcja "REGUŁY BEZPIECZEŃSTWA".

## Status

- **v1.0** — 2026-04-15 — MVP build (wywiad + skan systemowy)
- **v1.1** — 2026-04-16 — Głęboki skan środowiska Bliźniaka (CLAUDE.md → dane/*.md → .mcp.json), persona Harvey+Mike, sekcja `environment_scan` w tech_stack.json
- **Pierwszy smoke test:** klient pilotażowy (04.2026)
- **Hard deadline MVP działający:** sb 25.04.2026 wieczór (przed W17 MVP sprint)

## Cross-references

- Analyzer (port odbiorczy) — `../radar-audyt/analyzer-prompt.md`
- Radar-audyt architektura — `../radar-audyt/README.md`
- Decyzja 60/40 + "klient ma Claude Code" — `../../dane/decyzje.md`
- Brief tej sesji build — `./BRIEF-NEXT-SESSION.md`
- Design doc (obsolete custom runner) — `../../materialy/system10h/2026-04-14_cto_radar_audyt_integracji_design.md`

## Kontakt

- Product owner: Mateusz Sokólski — `hello@system10h.com`
- Problem ze skilla? Zobacz `INSTRUKCJA.md` sekcja "Problemy / wsparcie"
