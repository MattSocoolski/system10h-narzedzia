# Audit-skill v1.3-dev — CHECKLIST P3 schema extension

> **Status:** DEV. NIE deploy do shared skill registry.
> **Sesja:** autonomiczna 2026-04-26 (Quick Win #5 z D-2026-04-26-AM, ZADANIE 5/6).
> **Acceptance gate:** Mateusz akceptuje deploy po Windows PASS Natan (D-2026-04-25-EVENING D-2).
> **Powiązanie:** Partner Report 25.04 sekcja §11 #1 (architectural_constraints) + #2 (flag_reason per tool) + Owner Report 25.04 sekcja 5 Quick Win #5.

---

## 1. ZAKRES P3 (od v1.2 do v1.3-dev)

Trzy nowe pola schemy `tech_stack.json`, wszystkie **opcjonalne** (backwards-compat z analyzer v2.3):

### 1.1 `metadata.architectural_constraints[]`

Tablica obiektów. Eliminuje mylący sygnał "12/20 enforced = 60%" — dodaje machine-readable wskazanie że N z 20 hard-gates jest **architektonicznie niemożliwych do hard-gate w current arch** (wymaga cloud Tier C / multi-tenant / external event).

Każdy obiekt:
- `id` — string. Identyfikator (np. `"B-011"`, `"L-076"`, `"B-016"`)
- `label` — string. Krótka nazwa (np. `"Quality Scorecard cross-tenant"`, `"Pattern-detector pre-W22"`)
- `reason` — string. 1-2 zdania uzasadnienia z referencją do master-plan / decyzji
- `phase_unlock` — string. Kiedy odblokowane (np. `"W19+"`, `"Tier C cloud (W40+)"`, `"post-Windows-PASS"`)

### 1.2 `tools[].hobby_reason`

string|null. Uzasadnienie dlaczego `hobby_flag: true` lub po KROK 5 confirmed personal. Eliminuje false-positives (Ollama-style: flagowanie zombie bez głębszego grep `automatyzacje/`).

### 1.3 `tools[].zombie_reason`

string|null. Uzasadnienie dlaczego `usage_level: "zombie"`. Format: konkretne zdanie z referencją czasową ("X msc temu") lub kontekstową ("self-audit Q2", "decyzja D-XXXX").

---

## 2. WALIDACJA NOWA W v1.3-dev

Dodaje 4 walidacje przed `Write tool` w skillu (po istniejących v1.2):

- [ ] **[v1.3-dev P3]** Każde narzędzie z `hobby_flag: true` MA wypełniony `hobby_reason` (string, nie `null`). Reason brzmi konkretnie (>10 znaków, >2 słowa).
- [ ] **[v1.3-dev P3]** Każde narzędzie z `usage_level: "zombie"` MA wypełniony `zombie_reason`. Reason ma referencję czasową lub kontekstową.
- [ ] **[v1.3-dev P3]** Jeśli `enforcement_pct < 80%` → `metadata.architectural_constraints[]` MA min. 1 element (cztery pola `id/label/reason/phase_unlock` wypełnione).
- [ ] **[v1.3-dev P3]** `metadata.architectural_constraints[]` zachowuje JSON validity nawet gdy puste (`[]` zamiast `null`).

---

## 3. BACKWARDS COMPATIBILITY (analyzer v2.3)

Wszystkie 3 nowe pola są opcjonalne. Analyzer v2.3:
- Brak `architectural_constraints` lub pusta tablica → raport bez sekcji architectural blockers (jak dziś).
- Brak `hobby_reason` / `zombie_reason` → raport bez sekcji uzasadnień flag (jak dziś).
- KONTRAST.md generation **NIE zmienia się** dla audytów v1.0-v1.2 (kluczowy smoke test).

Test backwards-compat: odpalić skill v1.3-dev na repo z `tech_stack.json` v1.2 → analyzer v2.3 zwraca raport identyczny jak na v1.2 audycie.

---

## 4. CEL ANALYZER v2.4+ UPDATE (out of scope v1.3-dev — zaplanowane W19+)

Po deploy v1.3-dev + Windows PASS, analyzer v2.4 może wykorzystać nowe pola:

- **Enforcement scoring update:**
  - `enforcement_pct = enforced / (enforced + soft + architectural) * 100`
  - Bez `architectural_constraints`: pokazuje "60% enforced" (myląco)
  - Z `architectural_constraints`: pokazuje "12/20 hard-gate (60%) + 5/20 architectural blockers (25%) + 3/20 soft (15%). Realny enforcement potencjał: 85% post-Tier-C / 75% post-Quality-Scorecard."

- **`hobby_reason` conditional reframe:**
  - Reason brzmi defensywnie ("nie wiadomo czy używa") → Partner Mode flag "skill nie głęboko zweryfikował, dopytaj klienta"
  - Reason konkretny → Owner Mode bez modyfikacji

- **`zombie_reason` confidence gate:**
  - Reason ma `>X msc` + decyzję referenced → rekomenduj unparking lub deinstall
  - Reason ogólny ("rzadko używane") → Partner Mode flag "ostrożnie, może być rare-but-needed (compliance, backup)"

---

## 5. SMOKE TEST PROCEDURE

Po edycji schemy + SKILL.md, smoke na własnym repo (Mateusz tenant):

### 5.1 Schema validation smoke

```bash
# Sprawdź że schema parsuje (markdown)
wc -l system10h/audit-skill/output-schema/tech_stack.schema.md
# Powinno: ~360 linii (wzrost z ~330 v1.2 +~30 dla 3 nowych pól)

# Sprawdź że JSON template jest valid
grep -A100 '```json' system10h/audit-skill/output-schema/tech_stack.schema.md | grep -B1 -A1 'architectural_constraints'

# Sprawdź version bump
grep "v1.3-dev" system10h/audit-skill/output-schema/tech_stack.schema.md
grep "v1.3-dev" system10h/audit-skill/SKILL.md
```

### 5.2 Backwards-compat smoke

Odpalić audit-skill na repo Mateusza (cwd `/Users/mateuszsokolski/asystent`) — output `tech_stack.json` powinien:
- ✅ Mieć nowe pola `architectural_constraints`, `hobby_reason`, `zombie_reason` (jako pusta tablica/null jeśli skill nie wypełnia)
- ✅ NIE łamać KONTRAST.md generation (backwards compat zachowane)
- ✅ Validate per pełna lista checklist (v1.2 + v1.3 P3)

**UWAGA:** odpalenie pełnego skilla = 15-25 min interaktywnego wywiadu. NIE w ramach tej sesji autonomicznej. Smoke test = walidacja schemy + spec, nie pełen run skilla.

### 5.3 Smoke wymagany przed deploy v1.3-stable

1. Audit-skill v1.3-dev odpalany na 3 audytach realnych klientów (W19+) → walidacja ze świata realnego
2. KONTRAST.md per audyt = spójny vs v1.2 (zerowy regression)
3. Mateusz manualny review 3 raportów Owner Mode + Partner Mode → zero false-positives architectural

---

## 6. ROADMAP DO DEPLOY v1.3-stable

| # | Akcja | Owner | Deadline |
|---|-------|-------|----------|
| 1 | v1.3-dev schema + SKILL.md commit | @cto | ✅ DONE 2026-04-26 (sesja autonomiczna Z5) |
| 2 | v1.2 Windows real-smoke PASS (Natan Zmitrowicz) | @cto + Natan | W18 (28.04-04.05) |
| 3 | v1.3-dev → v1.3-rc1 (audit-skill v1.3 release candidate) | @cto | post-Windows PASS, W19 |
| 4 | 3 realne audyty klientów na v1.3-rc1 | @cso + klienci | W19-W20 |
| 5 | KONTRAST.md regression check + manual review | @ceo | post-3-audytów |
| 6 | Deploy v1.3-stable do shared skill registry | @cto | po PASS akcja 5 |
| 7 | Update analyzer-prompt v2.4 z nowymi conditional reframe | @cto + @cmo | post-v1.3-stable |

**Przewidywane W19-W21** (3-5 tyg od dziś).

---

## 7. POWIĄZANIE Z MASTER-PLAN AUTONOMII

P3 schema extension nie jest częścią Ścieżki B autonomii (D-2026-04-26-AM #1, 42h W19-W24 sprintu @cto). To jest **osobny backlog** — 22h roadmap audit-skill v1.3 (W18-W24).

**Wąskie gardło wykryte (Partner Report 25.04 sekcja 11):** 42h Ścieżka B + 22h v1.3 = 64h sprintu produkcyjnego do W24. Kolizja W22 wymaga decyzji A/B (Faza D Light vs pattern-detector). Rekomendacja @ceo: **pattern-detector pierwsze** (revenue +1500-3500 PLN/mies > Faza D Light 995 PLN/kw przy 5 klientach).

P3 schema extension (ten dokument, v1.3-dev) = **2h** z 22h v1.3 roadmap. Pozostałe:
- Windows real-smoke W18: 3h
- Cross-tenant security regex sweep W19: 3h
- DNA benchmark sekcja w tech_stack_human.md W19: 3h
- Faza D Light (storage S3/R2 + diff render) W22: 6h
- references/ dir ≥3 referencje per archetyp W24: 4h

---

## 8. ROLLBACK / REVERT

Jeśli smoke regression wykryta lub Mateusz wetuje kierunek:

```bash
# Rollback do v1.2 (commit przed Z5)
cp backup/tech_stack.schema_2026-04-26_pre-v1.3.md \
   system10h/audit-skill/output-schema/tech_stack.schema.md
cp backup/SKILL_2026-04-26_pre-v1.3.md \
   system10h/audit-skill/SKILL.md
rm system10h/audit-skill/references/CHECKLIST_v1.3.md
git add -A && git commit -m "[revert] Z5: rollback v1.3-dev schema (Mateusz veto)"
```

Backupy zachowane w `backup/`:
- `tech_stack.schema_2026-04-26_pre-v1.3.md`
- `SKILL_2026-04-26_pre-v1.3.md`

---

*Dokument wygenerowany przez sesję autonomiczną @ceo/@cto 2026-04-26. Veto pending.*
