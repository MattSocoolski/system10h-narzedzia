# Mail handshake po otrzymaniu audytu od klienta

**Użycie:** template który Mateusz wysyła klientowi po otrzymaniu plików audit-skill + po wygenerowaniu raportu Owner Mode przez analyzer.

**Kiedy wysłać:** w ciągu 48h od otrzymania `tech_stack.json` + pozostałych plików.

---

## Template v1.0

**Subject:** Twój audyt System 10H — raport gotowy

**Treść:**

```
Cześć [imię]!

Dzięki za wysłanie plików audytu — zmapowałem Twoje środowisko
i wracam z konkretnymi rekomendacjami.

W załączniku masz raport Owner Mode dla [nazwa firmy]
(radar_owner_[klient]_[data].md) — 60% rekomendacji dotyczy
asystentów AI których Ci dziś brakuje, 40% to audyt operacyjny
(wąskie gardła, zombie tools, luki integracji).

Top 3 najmocniejsze findings z Twojego stacku:

1. [Brakujący asystent #1 — 1 zdanie + oszczędność czasu tygodniowa]
2. [Brakujący asystent #2 lub wąskie gardło — 1 zdanie]
3. [Zombie tool lub luka integracji — 1 zdanie + szacowany waste PLN]

Dwa Quick Winy które możesz zrobić w poniedziałek bez mojego udziału:
- [Quick Win #1]
- [Quick Win #2]

Jeśli któraś z rekomendacji Cię szczególnie interesuje — mogę
dopracować plan wdrożenia (effort + koszt + timeline). Zwykle
pierwszy asystent powstaje w 2-3 tygodnie, pierwsza integracja
w 4-8h + 2-3 dni obserwacji.

Chcesz, żebyśmy umówili 30 min call żeby przejść przez raport
razem? Proponuję [dzień + godzina] albo wybierz sam: [calendly/link].

Pozdrawiam serdecznie,
Mateusz Sokólski
System 10H
hello@system10h.com
```

---

## Reguły personalizacji (dla Mateusza)

### Wypełnianie Top 3

- **Cytuj konkretne findings z Owner Mode** — nie parafrazuj, użyj dokładnie tych samych słów
- **Jeden finding na jedno zdanie** — klient skanuje, nie czyta
- **Kwantyfikuj jeśli możesz** — "oszczędność 8h/tydzień", "ROI 3400 PLN/mies"
- **Jeśli brakujący asystent jest TOP #1** — musi być na górze (proporcja 60/40 z analyzera musi być widoczna)

### Quick Winy

- Zawsze 2 (nie 1, nie 3)
- Muszą być wykonalne **bez udziału Mateusza** (to jest element zaufania — pokazuje że nie wszystko jest sprzedażą)
- Nie najsmaczniejsze — najsmaczniejsze zostają jako hak do rozmowy handlowej

### Call to action

- **Zawsze zaproponuj konkretny slot** (nie "daj znać kiedy masz czas")
- **Dodaj link do self-booking** jako fallback
- **30 min** — nie dłużej (minimalizacja friction)

### Personalizacja imienia

- Sprawdź w `profile.md` i `tech_stack.json` (`business_context.company_name`)
- Jeśli klient anonimizował — użyj "Cześć!" bez imienia

---

## Wersje alternatywne

### Wersja A — klient już ma mocny stack AI

Jeśli analyzer wygenerował <3 brakujących asystentów (klient ma zdrowy stack):

```
... wracam z lepszą wiadomością niż się spodziewałem — Twój stack
AI jest zaskakująco zdrowy jak na [branżę]. Nie wymyślam braków
których nie ma.

Zamiast Top 3 "brakujących asystentów" mam dla Ciebie:
- 1 asystent którego faktycznie potrzebujesz ([konkret])
- 2 luki operacyjne które warto spiąć ([konkret, konkret])

To jest dobra pozycja wyjściowa — z mniejszym backlogiem szybciej
zrobimy pilota jednego konkretnego asystenta. Chcesz żebyśmy
omówili to na 20-minutowym callu? ...
```

### Wersja B — klient nie używa żadnego LLM

Jeśli `ai_usage.current_llms` jest puste:

```
... zauważyłem że nie używasz dziś żadnego LLM w pracy. To jest
ważny sygnał — oznacza że każda godzina którą spędzasz na ręcznym
[bolączka 1 z pain_points] może być pierwszą godziną z asystentem
AI.

Zanim zaczniemy rozmowę o asystentach na zamówienie, mam dla Ciebie
30-minutowy fast-track: jak rozpoznać z którym LLM zacząć (ChatGPT
vs Claude vs Gemini) i jaki pierwszy use-case przynosi najszybszy
zwrot w Twojej branży.

To jest gratis, bez zobowiązań — chcesz umówić call? ...
```

### Wersja C — klient ma bardzo dużo zombie tools

Jeśli `tools` ma >5 pozycji z `usage_level: "zombie"`:

```
... widzę że w Twoim stacku jest [N] narzędzi za które płacisz
ale praktycznie nie używasz. Szacowany waste miesięczny z tego
samego faktu: [suma monthly_waste_pln_estimate] PLN.

To jest dla Ciebie pierwsza wygrana ZANIM zaczniemy rozmawiać
o nowych asystentach AI — 30 min audytu subskrypcji + decyzje
co wyłączyć, oszczędzasz [N] PLN miesięcznie od razu.

Potem dopiero rozmawiamy o asystentach na zamówienie — już
z zaoszczędzonymi pieniędzmi. Umówmy? ...
```

---

*Template v1.0 — iteracja po pierwszych 3 smoke testach.*
