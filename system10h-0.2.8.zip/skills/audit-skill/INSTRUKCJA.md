# Audit Skill System 10H — Instrukcja dla klienta

## Co to jest

`audit-skill` to skill Claude Code który **u Ciebie lokalnie** przeprowadza 15-25 minutowy wywiad o Twoim biznesie, skanuje środowisko Twojego komputera (nazwy aplikacji, crony, launch agents — **nie** zawartość plików), i generuje 4 pliki outputu. Te pliki wysyłasz mailem do Mateusza, on wrzuca do analyzera i wraca w 48h z raportem Owner Mode + Partner Mode z konkretnymi rekomendacjami asystentów AI i luk integracji.

**Kluczowe:**
- Skan działa **lokalnie**, a pliki wyniku zostają u Ciebie; treść czytana w trakcie skanu trafia do dostawcy modelu na Twoim koncie
- **Ty wysyłasz** pliki mailem, nie skill
- **Widzisz wszystko przed wysłaniem** — pełna kontrola

## Czego potrzebujesz

- **Claude Code** zainstalowany i zalogowany — https://claude.com/claude-code
- macOS, Linux lub Windows (skanowanie działa natywnie na każdym systemie)
- 15-25 minut skupienia
- Podstawowa wiedza o swoim stacku narzędzi (nazwy, nie cennik)

## Jak uruchomić (3 kroki)

### Krok 1 — Rozpakuj skill

Dostajesz od Mateusza plik `audit-skill.zip`. Rozpakuj go do folderu skilli Claude Code:

```bash
# macOS / Linux
mkdir -p ~/.claude/skills
unzip audit-skill.zip -d ~/.claude/skills/
```

Po rozpakowaniu powinieneś mieć strukturę:

```
~/.claude/skills/audit-skill/
├── SKILL.md
├── INSTRUKCJA.md       ← ten plik
├── MAIL-HANDSHAKE.md
├── README.md
└── output-schema/
    ├── tech_stack.schema.md
    └── tech_stack_human.template.md
```

### Krok 2 — Uruchom Claude Code w folderze roboczym

Utwórz folder roboczy (gdzie wygeneruje się output) i wejdź do niego:

```bash
mkdir ~/audit-10h
cd ~/audit-10h
claude
```

### Krok 3 — Odpal skill

W Claude Code napisz dokładnie to:

```
uruchom audit-skill
```

Lub (jeśli preferujesz explicite):

```
Użyj skilla audit-skill i przeprowadź mnie przez pełny audyt dla System 10H.
```

Claude odpowie powitaniem, poprosi o zgodę, i przeprowadzi Cię przez 7 kroków wywiadu.

## Co dostaniesz (output)

W folderze `./audit-output/` znajdą się 4 pliki:

| Plik | Co zawiera | Dla kogo |
|---|---|---|
| `tech_stack.json` | Machine-readable dane o narzędziach, workflow, AI usage | Główny input dla Mateusza |
| `tech_stack_human.md` | Human-readable raport z Twoich odpowiedzi | Twoja kopia do przejrzenia |
| `profile.md` | Profil biznesowy Twoimi słowami (branża, zespół, cele, bolączki) | Input dla Mateusza |
| `workflow.md` | Workflow dnia + AI usage — cytaty | Input dla Mateusza |

**Przed wysłaniem** — otwórz `tech_stack_human.md` w ulubionym edytorze i przejrzyj. Jeśli coś jest nie tak — wróć do Claude Code i powiedz "popraw X na Y" — Claude zaktualizuje pliki.

## Jak wysłać

Wejdź do folderu outputu, spakuj, wyślij:

```bash
cd ~/audit-10h/audit-output
zip audyt-moja-firma.zip tech_stack.json tech_stack_human.md profile.md workflow.md
```

Wyślij załącznik mailem na **hello@system10h.com** z tematem:

```
Audyt: [Nazwa Twojej firmy]
```

W treści maila nic nie musisz pisać, ale jeśli chcesz dodać kontekst — śmiało.

## Bezpieczeństwo — co skill robi i czego NIE robi

### ✅ Co skill robi
- Skanuje listy aplikacji (macOS: `ls /Applications`, Linux: `/usr/share/applications`, Windows: Registry + Store)
- Listuje narzędzia CLI zainstalowane przez Homebrew / npm / pip / winget / choco / scoop
- Sprawdza zaplanowane zadania (macOS: LaunchAgents, Linux: systemd/cron, Windows: Task Scheduler)
- Pyta Cię o subskrypcje SaaS (te których nie widać lokalnie — CRM, email marketing, itp.)
- Pyta Cię o workflow, bolączki, AI usage
- Generuje 4 pliki tekstowe w `./audit-output/`

### ❌ Czego skill NIE robi
- NIE czyta zawartości plików konfiguracyjnych (`cat ~/.ssh/config`, `cat ~/.env` — **zakazane**)
- NIE skanuje folderów `~/.ssh`, `~/.aws`, `~/.gnupg`, `~/.netrc`
- NIE zapisuje haseł, kluczy API, tokenów, sekretów
- NIE wysyła nikomu Twoich plików ani raportu (**Ty** wysyłasz je mailem)
- NIE dotyka Twoich plików projektowych ani dokumentów
- NIE modyfikuje żadnych systemowych ustawień

### Double-check przed wysłaniem

Skill na końcu sam wykonuje grep sprawdzający czy żaden plik outputu nie zawiera słów `password`, `api_key`, `secret`, `token`. Jeśli coś wyskoczy — skill natychmiast pokaże Ci to i usunie przed zapisem finalnym.

Dodatkowo możesz zrobić własny grep:

```bash
grep -iE "password|api[_-]?key|secret|token|bearer" ~/audit-10h/audit-output/*.json ~/audit-10h/audit-output/*.md
```

Jeśli cokolwiek wyskoczy — **nie wysyłaj**, skontaktuj się z Mateuszem.

## Co się dzieje po wysłaniu

1. Mateusz dostaje Twoje pliki mailem
2. Wkleja je do swojego analyzera (`analyzer-prompt v2`)
3. Analyzer generuje dwa raporty:
   - **Owner Mode** (dla Ciebie) — plain language, 60% o brakujących asystentach AI, 40% o lukach operacyjnych, z konkretnym "co zrobić w poniedziałek"
   - **Partner Mode** (wewnętrzny) — dla Mateusza jako wsad do rozmowy handlowej
4. W ciągu 48h dostajesz Owner Mode mailem zwrotnym
5. Jeśli któryś wniosek Cię zainteresuje — rozmawiacie z Mateuszem o konkretnym wdrożeniu

## Problemy / wsparcie

**Skill nie startuje po `uruchom audit-skill`:**
- Sprawdź czy rozpakowałeś do `~/.claude/skills/audit-skill/` (nie `~/.claude/skills/SKILL.md`)
- Sprawdź czy `SKILL.md` ma frontmatter YAML (zaczyna się od `---`)
- Zrestartuj Claude Code

**Skill przerwał w połowie:**
- Napisz Claude'owi "kontynuuj audit-skill od kroku X"
- Jeśli nie pamięta — uruchom od nowa, to nie kasuje wcześniej wygenerowanych plików

**Skan lokalny zwrócił pustą listę aplikacji:**
- OK, to nie problem — skill zapyta Cię o narzędzia manualnie
- `metadata.scan_coverage` ustawi się na `partial`

**Jestem na Windows i skan się wyłożył:**
- Skill automatycznie wykrywa Windows i używa PowerShell. Jeśli PowerShell zwraca błędy — skill przejdzie do pytań manualnych
- Upewnij się że uruchamiasz Claude Code z terminala z dostępem do PowerShell (cmd, PowerShell, Windows Terminal)

**Nie wiem którego narzędzia używam ile razy:**
- Podaj szacunek ("codziennie" / "kilka razy w tygodniu" / "raz na miesiąc")
- Skill tłumaczy to na `usage_level` automatycznie

**Mam wątpliwości czy wysłać plik:**
- Otwórz `tech_stack_human.md` i przejrzyj — jeśli coś Cię niepokoi, powiedz Claude'owi "usuń X z outputu"
- Skill usunie i zregeneruje

**Coś innego:**
Napisz do Mateusza: **hello@system10h.com** z tematem "Audit Skill — pytanie".

---

*System 10H Audit Skill v1.0 — wersja MVP. Pierwsze smoke testy: kwiecień 2026.*
