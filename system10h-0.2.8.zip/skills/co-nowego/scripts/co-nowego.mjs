#!/usr/bin/env node
// co-nowego.mjs — CO SIĘ ZMIENIŁO W TWOJEJ PACZCE, liczone z dwóch odczytów z dysku.
//
// PO CO: notatki do wersji prowadzimy od 24.08, ale do 31.08 nie miały ŻADNEGO kanału dowozu —
//   nie jechały w paczce, więc klient dostawał sam numer wersji. Ten skrypt jest wykonawczą
//   częścią procedury `co-nowego`: model nie porównuje numerów „z głowy", tylko czyta plik
//   i manifest, a wersje porównuje kod.
//
// TRÓJSTAN JEST OBOWIĄZKOWY (B-040 §D): „nie wiem, którą wersję masz" musi paść WPROST.
//   Zgadnięcie wersji zainstalowanej byłoby gorsze niż jej brak — klient zobaczyłby listę
//   „nowości", które ma u siebie od tygodnia, i przestałby ufać całej rubryce.
//
// ⛔ CZEGO TEN SKRYPT NIE ROBI: nie instaluje, nie aktualizuje, nie wysyła niczego z komputera
//   właściciela. Jedyne wyjście na zewnątrz to `--sprawdz-katalog` — zapytanie GET o publiczny
//   plik katalogu, uruchamiane wyłącznie wtedy, gdy ktoś je wpisze.

import { readFileSync, existsSync, realpathSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const KATALOG_ONLINE = 'https://raw.githubusercontent.com/MattSocoolski/system10h-narzedzia/main/.claude-plugin/marketplace.json';
const NAZWA_PLUGINU = 'system10h';

// ─── ODCZYTY ─────────────────────────────────────────────────────────────────

/** Katalog samego skilla — punkt odniesienia dla wszystkich pozostałych ścieżek. */
function katalogSkilla(flagi) {
  if (flagi.skill) return resolve(flagi.skill);
  return resolve(dirname(fileURLToPath(import.meta.url)), '..');
}

/**
 * Wersja ZAINSTALOWANA = ta z manifestu pluginu, który leży nad katalogiem skilla.
 * Szukamy w górę, bo układ różni się między instalacją z katalogu narzędzi
 * (`<plugin>/skills/co-nowego/`) a rozłożoną paczką (`<paczka>/.claude/skills/co-nowego/`).
 * W tym drugim układzie manifestu NIE MA i to jest prawidłowy wynik: `null` → „nie wiem”.
 */
export function wersjaZainstalowana(odKatalogu, poziomow = 5) {
  let dir = odKatalogu;
  for (let i = 0; i < poziomow; i++) {
    const kandydat = join(dir, '.claude-plugin', 'plugin.json');
    if (existsSync(kandydat)) {
      try {
        const j = JSON.parse(readFileSync(kandydat, 'utf8'));
        if (j.version) return { wersja: j.version, skad: kandydat };
      } catch {
        return { wersja: null, skad: kandydat, powod: 'manifest jest nieczytelny (uszkodzony JSON)' };
      }
    }
    const wyzej = dirname(dir);
    if (wyzej === dir) break;
    dir = wyzej;
  }
  return { wersja: null, skad: null, powod: 'nie znalazłem manifestu paczki nad katalogiem procedury' };
}

// ─── NOTATKI ─────────────────────────────────────────────────────────────────

/** Nagłówek wpisu: „## 🆕 wersja 0.2.7 (30.08.2026)” — emoji jest opcjonalne. */
const NAGLOWEK = /^##\s*(?:\S+\s+)?wersja\s+(\d+(?:\.\d+)*)\s*(?:\(([^)]*)\))?\s*$/;

/** @returns {{naglowek:string, wersja:string, data:string|null, tresc:string}[]} */
export function rozbijNaWpisy(tekst) {
  const linie = tekst.split('\n');
  const wpisy = [];
  let biezacy = null;
  for (const l of linie) {
    const m = l.match(NAGLOWEK);
    if (m) {
      if (biezacy) wpisy.push(biezacy);
      biezacy = { naglowek: l.trim(), wersja: m[1], data: m[2] || null, linie: [] };
      continue;
    }
    if (biezacy) biezacy.linie.push(l);
  }
  if (biezacy) wpisy.push(biezacy);
  return wpisy.map((w) => ({
    naglowek: w.naglowek,
    wersja: w.wersja,
    data: w.data,
    tresc: w.linie.join('\n').replace(/^\s*---\s*$/gm, '').trim(),
  }));
}

/** Porównanie numerów wersji człon po członie. Zwraca -1 / 0 / 1. */
export function porownaj(a, b) {
  const A = a.split('.').map(Number);
  const B = b.split('.').map(Number);
  for (let i = 0; i < Math.max(A.length, B.length); i++) {
    const x = A[i] ?? 0;
    const y = B[i] ?? 0;
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
}

// ─── KATALOG ONLINE (jedyne wyjście na zewnątrz, tylko na żądanie) ───────────

async function zapytajKatalog(url = KATALOG_ONLINE, ms = 6000) {
  const przerywacz = new AbortController();
  const budzik = setTimeout(() => przerywacz.abort(), ms);
  try {
    const odp = await fetch(url, { signal: przerywacz.signal });
    if (!odp.ok) return { stan: 'PROBLEM', powod: `katalog odpowiedział kodem ${odp.status}` };
    const j = JSON.parse(await odp.text());
    const wpis = (j.plugins || []).find((p) => p.name === NAZWA_PLUGINU);
    if (!wpis?.version) return { stan: 'PROBLEM', powod: 'katalog odpowiedział, ale nie ma w nim wpisu z numerem wersji' };
    return { stan: 'OK', wersja: wpis.version };
  } catch (e) {
    return { stan: 'PROBLEM', powod: `nie udało się zapytać katalogu (${e.name === 'AbortError' ? 'przekroczony czas oczekiwania' : e.message})` };
  } finally {
    clearTimeout(budzik);
  }
}

// ─── WYPIS ───────────────────────────────────────────────────────────────────

const mow = (s = '') => console.log(s);

function parsuj(argv) {
  const f = {};
  for (const a of argv.slice(2)) {
    const m = a.match(/^--([^=]+)(?:=(.*))?$/);
    if (m) f[m[1]] = m[2] ?? true;
  }
  return f;
}

export async function main(argv = process.argv) {
  const flagi = parsuj(argv);
  if (flagi.pomoc) {
    mow('Użycie: node co-nowego.mjs [--notatki=<plik>] [--wersja=<numer>] [--skill=<katalog>] [--sprawdz-katalog] [--url=<adres katalogu>]');
    return 0;
  }

  const skill = katalogSkilla(flagi);
  const plikNotatek = flagi.notatki ? resolve(flagi.notatki) : join(skill, 'references', 'NOTATKI-DO-WERSJI.md');

  // ── (1) Wersja zainstalowana — albo uczciwe „nie wiem”. Idzie PIERWSZA, bo jest
  //        odpowiedzią na pytanie klienta nawet wtedy, gdy notatek u niego nie ma.
  const zain = flagi.wersja && flagi.wersja !== true
    ? { wersja: String(flagi.wersja), skad: 'podana przy wywołaniu' }
    : wersjaZainstalowana(skill);

  mow('');
  if (zain.wersja) {
    mow(`📦 Masz u siebie wersję **${zain.wersja}**.`);
    mow(`   (odczytane z: ${zain.skad})`);
  } else {
    mow('🟡 **Nie wiem, którą wersję masz zainstalowaną** — i nie zgaduję.');
    mow(`   Powód: ${zain.powod}.`);
    mow('   Tak wygląda instalacja bez katalogu narzędzi — to nie jest usterka, tylko inny układ.');
  }

  // ── (2) Katalog online — wyłącznie na żądanie.
  mow('');
  if (flagi['sprawdz-katalog']) {
    // `--url` istnieje po to, żeby dało się sprawdzić ZACHOWANIE NA BŁĘDZIE bez zrywania sieci
    // (L-573: „OK” coś znaczy dopiero wtedy, gdy ten sam tor umie zwrócić PROBLEM).
    const k = await zapytajKatalog(typeof flagi.url === 'string' ? flagi.url : KATALOG_ONLINE);
    if (k.stan === 'OK') {
      if (!zain.wersja) mow(`🌐 W katalogu stoi dziś wersja **${k.wersja}**. Czy jest nowsza od Twojej — nie umiem powiedzieć, bo nie znam Twojej.`);
      else if (porownaj(k.wersja, zain.wersja) > 0) mow(`🌐 W katalogu jest **nowsza wersja: ${k.wersja}** (Ty masz ${zain.wersja}).`);
      else if (porownaj(k.wersja, zain.wersja) === 0) mow(`🌐 W katalogu stoi ta sama wersja co u Ciebie (${k.wersja}) — nie ma czego aktualizować.`);
      else mow(`🌐 W katalogu stoi wersja ${k.wersja}, czyli STARSZA niż Twoja (${zain.wersja}). To nietypowe — daj nam znać.`);
    } else {
      mow(`🟡 NIE SPRAWDZIŁEM, czy w katalogu jest nowsza wersja: ${k.powod}.`);
      mow('   To nie znaczy „nie ma nowszej" — znaczy, że nie wiem.');
    }
  } else {
    mow('🟡 Czy w katalogu stoi coś nowszego — NIE SPRAWDZAŁEM (to osobne pytanie, wychodzące do internetu).');
  }

  // ── (3) Notatki. Bez nich nie ma o czym mówić — i mówimy to wprost.
  mow('');
  if (!existsSync(plikNotatek)) {
    mow('🟡 NIE MAM U SIEBIE OPISU ZMIAN.');
    mow(`   Szukałem tutaj: ${plikNotatek}`);
    mow('   To nie znaczy, że nic się nie zmieniło — znaczy, że ta instalacja przyjechała bez opisu zmian.');
    mow('   Napisz do nas, a prześlemy opis zmian do Twojej wersji.');
    return 1;
  }
  const wpisy = rozbijNaWpisy(readFileSync(plikNotatek, 'utf8'));
  if (!wpisy.length) {
    // Zero dopasowań to ALARM, nie zieleń (B-040 §D) — plik jest, ale nie umiem go odczytać.
    mow('🟡 PLIK Z OPISEM ZMIAN JEST, ALE NIE ROZPOZNAŁEM W NIM ANI JEDNEGO WPISU WERSJI.');
    mow(`   Plik: ${plikNotatek}`);
    mow('   Nie zgaduję jego treści. Pokaż ten plik człowiekowi albo napisz do nas.');
    return 1;
  }
  const najnowszaWNotatkach = wpisy.map((w) => w.wersja).sort(porownaj).at(-1);

  // ── (4) Wpisy.
  const doPokazania = zain.wersja ? wpisy.filter((w) => porownaj(w.wersja, zain.wersja) > 0) : wpisy;
  mow('─'.repeat(74));
  if (zain.wersja && !doPokazania.length) {
    const wlasny = wpisy.find((w) => porownaj(w.wersja, zain.wersja) === 0);
    mow(`✅ Od wersji ${zain.wersja} nie doszło nic nowego. Masz najnowszą, o której wiem (opis kończy się na ${najnowszaWNotatkach}).`);
    mow('');
    mow(wlasny
      ? `Wpis o Twojej wersji:\n\n### ${wlasny.naglowek.replace(/^#+\s*/, '')}\n\n${wlasny.tresc}`
      : `🟡 W opisie zmian nie ma wpisu o wersji ${zain.wersja} — nie wiem, co przyszło z nią samą.`);
    return 0;
  }
  mow(zain.wersja
    ? `📖 CO SIĘ ZMIENIŁO OD TWOJEJ WERSJI — ${doPokazania.length} ${doPokazania.length === 1 ? 'wpis' : 'wpisy'}, od najnowszego:`
    : `📖 CAŁY OPIS ZMIAN — ${doPokazania.length} wpisów, od najnowszego. Pokazuję wszystkie, bo nie wiem, którą wersję masz:`);
  mow('─'.repeat(74));
  for (const w of doPokazania) {
    mow('');
    mow(`### ${w.naglowek.replace(/^#+\s*/, '')}`);
    mow('');
    mow(w.tresc || '(wpis bez treści — tak jest w opisie zmian; nie dopisuję niczego od siebie)');
  }
  return 0;
}

/**
 * Czy uruchomiono ten plik BEZPOŚREDNIO — porównanie po `realpath`, nie po napisie.
 * Zmierzone 31.08 na rozłożonej paczce: staging leży w `/var/folders/…`, a `/var` na macOS
 * jest dowiązaniem do `/private/var`. Porównanie samych napisów zwracało `false`, więc skrypt
 * kończył się **kodem 0 i pustym wypisem** — cisza nieodróżnialna od sukcesu (L-567).
 * Kanon tej sztuczki mieszka w `automatyzacje/uruchomiono-bezposrednio.mjs`, ale ten plik
 * jedzie do klienta bez `automatyzacje/`, więc niesie ją u siebie.
 */
function uruchomionoBezposrednio() {
  try {
    return realpathSync(resolve(process.argv[1] || '')) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

if (uruchomionoBezposrednio()) {
  main().then((k) => process.exit(k));
}
