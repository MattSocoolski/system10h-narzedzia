---
name: co-nowego
description: Pokazuje, co się zmieniło w narzędziach System 10H — czyta opis zmian i numer wersji z dysku, a na życzenie sprawdza w katalogu, czy jest nowsza. Użyj, gdy pada „co nowego", „co się zmieniło", „czy jest nowsza wersja", „czy mam aktualną wersję", „jaką mam wersję", „co przyszło z aktualizacją".
allowed-tools: Bash(node "${CLAUDE_SKILL_DIR}/scripts/co-nowego.mjs" *) Bash(node ${CLAUDE_SKILL_DIR}/scripts/co-nowego.mjs *) Read
metadata:
  dystrybucja: plugin
---

# Co nowego w Twoich narzędziach

Odpowiadasz **właścicielowi paczki** na pytanie, które brzmi prosto, a ma trzy różne odpowiedzi:
*co mam u siebie*, *co się w tym ostatnio zmieniło* i *czy gdzieś stoi coś nowszego*. To są trzy
osobne pomiary. Nie zlepiaj ich w jedno zdanie i nie uzupełniaj jednego drugim.

> **Ta procedura zgłasza się sama** — inaczej niż `autopilot` i `pamiec-po-znaczeniu`, które są
> dodatkami i czekają, aż ktoś wpisze ich nazwę. Opis zmian dotyczy **podstawy**, którą ma każdy,
> kto ma te narzędzia, a pytanie „co nowego" pada w rozmowie, nie przez wpisanie komendy.
> Zdejmowanie tej różnicy to decyzja @prod, nie odruch.

## Krok 1 — odczyt z dysku. Zacznij od niego

```!
node "${CLAUDE_SKILL_DIR}/scripts/co-nowego.mjs"
```

Ten odczyt jest **świeży i pochodzi z plików**, nie z tej rozmowy i nie z Twojej pamięci
o wersjach. Numer wersji bierzesz **wyłącznie stąd**.

## Krok 2 — „czy jest nowsza wersja?" to osobne pytanie

Krok 1 patrzy tylko na to, co leży na dysku właściciela. Żeby odpowiedzieć, czy w katalogu stoi
coś nowszego, trzeba **wyjść na zewnątrz**. Powiedz to człowiekowi jednym zdaniem, zanim to
zrobisz — po ludzku, mniej więcej tak:

> „Zajrzę do naszego katalogu w internecie i sprawdzę, jaki numer tam dziś stoi. To zwykłe
> pobranie jednego pliku z listą wersji — nic z Twojego komputera przy tym nie wychodzi."

Dostajesz zgodę → uruchom to samo, z dołożoną flagą:

```
node "${CLAUDE_SKILL_DIR}/scripts/co-nowego.mjs" --sprawdz-katalog
```

Nie dostajesz zgody albo pytanie dotyczyło tylko „co się zmieniło" → **nie odpalaj tego kroku**
i nie mów nic o tym, czy jest nowsza wersja. Brak sprawdzenia nie jest odpowiedzią „nie ma".

## Krok 3 — przekaż to, co wyszło. Trzy stany, nigdy dwa

**OK · PROBLEM · NIE SPRAWDZIŁEM.** Trzeciego nie zaokrąglasz w żadną stronę.

- **Wyszedł numer wersji i lista zmian** → streść je człowiekowi *jego* językiem: co przyszło
  i co z tego dla niego wynika. Wpisy są już napisane po ludzku — nie tłumacz ich na techniczne
  i nie skracaj tak, żeby zniknęło zdanie o tym, co **przestaje** działać.
- **Wyszło „nie wiem, którą wersję masz"** → powiedz to wprost i pokaż wszystko, co masz.
  Brzmi to mniej więcej tak: *„Nie umiem odczytać, którą wersję masz u siebie, więc nie zgaduję —
  pokazuję cały opis zmian od najstarszego wpisu."* **Nigdy nie podstawiaj numeru z pamięci,
  z tej rozmowy ani z tego, co widziałeś u innego klienta.**
- **Wyszło „nie mam u siebie opisu zmian"** → to prawidłowy wynik, nie awaria. Powiedz, że ta
  instalacja przyjechała bez opisu zmian, i zaproponuj kontakt z nami. Nie odtwarzaj tej treści
  z pamięci — opis zmian, którego nie przeczytałeś z pliku, jest zmyślony.

## Czego ta procedura NIE robi — i czego nie wolno obiecać

- **Nie aktualizuje niczego.** Pokazuje, co się zmieniło; instalacja nowszej wersji to osobna
  rzecz, którą robi człowiek. Jeśli padnie „to zaktualizuj" — powiedz, że tego stąd nie zrobisz,
  i odeślij do nas.
- **Nie wysyła niczego z komputera właściciela.** Jedyne wyjście na zewnątrz to krok 2 i jest to
  pobranie publicznego pliku z listą wersji.
- **Nie ocenia, czy „warto zaktualizować"** i nie mówi, ile ktoś na tym zyska. Nie masz z czego —
  liczby i korzyści, których nie ma w opisie zmian, są zmyślone.
- **`exit 0` to hipoteza sukcesu, nie dowód.** Werdykt bierzesz z **treści** wypisu. Gdy jej nie
  umiesz odczytać, mówisz **„nie umiem odczytać"** — nigdy „w porządku".
