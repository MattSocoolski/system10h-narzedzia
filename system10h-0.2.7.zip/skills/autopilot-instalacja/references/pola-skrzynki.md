<!-- PLIK GENEROWANY — nie edytuj ręcznie.
     Źródło: scripts/kroki-etap2.mjs · odśwież: node scripts/stan-instalacji.mjs kroki --markdown
     Parytet pilnuje: automatyzacje/tests/autopilot-instalacja-kroki.test.mjs -->

# Krok 2.7 — komplet pól wpisu skrzynki

Wpis idzie do `automatyzacje/skrzynki.json`, lista `skrzynki`. To **plik danych, nie kod** —
i to jest celowe: aktualizacja paczki nadpisuje pliki kodu, więc dopóki wpis siedział wewnątrz
`autopilot-config.mjs`, pierwsza aktualizacja kasowała go po cichu (poprawione 18.08).
Ten plik nie przyjeżdża w paczce — powstaje dopiero tutaj i jest własnością klienta.

To jest miejsce, w którym instalacja psuje się najciszej: **pominięte pole nie krzyczy, tylko
wyłącza funkcję bez słowa.** Dlatego przy każdym braku mówimy SKUTEK, nie „brakuje pola".

Ścieżki zapisujesz z `~` (np. `"~/.config/klient/creds.json"`) — rozwija je wczytywacz.
Wzorce `noiseFrom` to zwykły tekst bez ukośników (np. `"no-?reply"`).

| Pole | Wymagane | Po co | Gdy pominiesz |
|---|---|---|---|
| `id` | **tak** | tożsamość skrzynki w rejestrze | demon nie wstanie |
| `host` | **tak** | serwer IMAP | demon nie wstanie |
| `port` | **tak** | port IMAP (993) | demon nie wstanie |
| `identity` | **tak** | adres, na który przychodzi poczta | demon nie wstanie |
| `credsPath` | **tak** | ścieżka do poświadczeń NA JEJ DYSKU | brak logowania — demon nie ma czym się przedstawić |
| `profilPath` | **tak** | jej `dna.md` dla jednego ładowacza kontekstu | drafty bez wiedzy o jej firmie i brak `braki.md` — pętla pytań nie ma gdzie pisać |
| `ghostStylePath` | **tak** | jej styl (może wskazywać wprost `dna.md` — sekcja S5 wycinana sama) | System pisze NASZYM stylem, nie jej |
| `displayName` | **tak** | kto podpisuje odpowiedź | jej odpowiedzi podpisze „Mateusz" |
| `tenantId` | **tak** | polityka pokrycia (`draft-sanity`) | bezpiecznik pokrycia nieaktywny — draft bez korpusu faktów przechodzi |
| `leadsDir` | **tak** | katalog kart kontaktów | pilnowanie terminów pilnuje pustki |
| `telegram` | nie | alerty na JEJ konto ({ botToken, chatId }) | alerty idą do nas, nie do niej |
| `petlaStylu` | nie | pętla powrotu stylu — TYLKO pilot | brak pętli propozycji stylu (to jest dopuszczalny stan domyślny) |

## Weryfikacja kroku

Po wpisie sprawdzasz **przez uruchomienie**, nie przez odczyt pliku: konfiguracja ma się
wczytać, a liczba skrzynek wzrosnąć o jeden.

Uruchamiasz to **komendą `sprawdz` z bloku „Sprawdź u źródła" w `SKILL.md`** — z
`--krok=2.7` i `--skrzynka=<id>`. Gotowej ścieżki nie ma tu celowo: skill bywa
zainstalowany jako wtyczka, w zupełnie innym drzewie niż projekt, i wtedy każda
ścieżka wpisana tu na sztywno wskazuje w pustkę. Katalog skilla podstawia platforma.
