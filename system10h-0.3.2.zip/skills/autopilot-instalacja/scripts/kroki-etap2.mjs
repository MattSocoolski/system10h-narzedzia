// kroki-etap2.mjs — DANE Etapu 2 instalacji Autopilota. Jedyne źródło prawdy dla skilla.
//
// PO CO ISTNIEJE JAKO KOD, A NIE JAKO TABELA W MARKDOWNIE (spec §3a.3):
//   „wznawiaj, aż przejdzie" bez macierzy idempotencji zdubluje wpis skrzynki i wyśle
//   klientce trzy testowe maile. Macierz musi być DANYMI, które maszyna czyta — nie prozą,
//   którą model interpretuje. Dlatego `references/kroki-etap2.md` jest RENDEROWANY stąd
//   (`stan-instalacji.mjs kroki --markdown`), a test parytetu pęka, gdy kopia zwietrzeje
//   (L-618: „N kopii pliku" — ustal relację każdej PRZED edycją).
//
// ŹRÓDŁO KROKÓW: `materialy/system10h/2026-08-08_procedura-instalacji_etap-1-i-2.md` §4.
//   Przy rozjeździe wygrywa procedura (@coo jest jej właścicielem), a ten plik idzie
//   do poprawki — nie odwrotnie.
//
// Zero zależności poza wbudowanymi — plik jedzie do paczki klienta.
// Dotknięte prompty (B-021): @cto (owner budowy) · @coo (owner kroków). Review: 2026-08-25.

// ── Trójstan: KANON, nie własna kopia (B-040 §D) ─────────────────────────────
//
// `automatyzacje/trojstan.mjs` jest jedynym źródłem trzech stanów i jedzie w paczce
// klienta razem z resztą silnika. Własne `const STAN = {...}` byłoby 13. ręczną kopią
// w trzeciej pisowni, a licznik sond meldowałby wtedy „0 · 0 · 0" nad wypisaną pozycją
// (case 28.07). Dlatego kanon jest importowany, nie przepisywany — i to zostaje.
//
// ⛔ CZEGO NIE WOLNO ZROBIĆ I DLACZEGO (usterka zmierzona 30.08.2026):
//   Do 30.08 kandydaci byli DWAJ i obaj byli ścieżkami WZGLĘDNYMI — `../../../../` dla
//   rozłożonej paczki i `../../../../../../../` dla naszego repo. To znaczy, że plik był
//   odnajdywany po ODLEGŁOŚCI W DRZEWIE, czyli po własności, która przy dystrybucji
//   wtyczką po prostu nie istnieje. I to nie jest nasza obserwacja ani czyjaś anegdota,
//   tylko UDOKUMENTOWANE zachowanie platformy (`code.claude.com/docs/en/plugins-reference`):
//     „Claude Code copies marketplace plugins to the user's local plugin cache
//      (`~/.claude/plugins/cache`) rather than using them in place […] each installed
//      version is a separate directory in the cache, grouped by marketplace and plugin
//      and named for the resolved version".
//   Czyli procedura Z ZAŁOŻENIA ląduje w cudzym drzewie, a projekt klienta stoi gdzie
//   indziej — te dwa drzewa NIE MAJĄ WSPÓLNEGO KORZENIA i żadna liczba `..` tam nie
//   dojdzie. Nie doszła: pierwszy człowiek z zewnątrz, który zainstalował nas wtyczką
//   (30.08), zatrzymał się tu na czwartym kroku instalacji, mając kanon na dysku,
//   w katalogu, którego adres sam podał programowi w `--katalog`.
//
// CO JEST WŁAŚCIWĄ WŁASNOŚCIĄ: katalog projektu, który program już zna. Pytamy o niego
// trzy razy, od najbardziej jawnego do najbardziej domyślnego, i dopiero potem wracamy
// do dwóch starych ścieżek — te zostają wyłącznie jako zgodność wsteczna dla wywołania
// bez `--katalog` i spoza katalogu projektu.
//
// SKĄD ADRES PRZYCHODZI W NORMALNYM PRZEBIEGU (prymityw platformy, nie nasz wynalazek):
//   `SKILL.md` woła to narzędzie z `--katalog="${CLAUDE_PROJECT_DIR}"`, a platforma
//   podstawia tę zmienną w treści skilla i w regułach `allowed-tools`
//   (`code.claude.com/docs/en/skills.md`). Do procesu trafia więc gotowa ścieżka
//   w argumencie — dlatego kandydat pierwszy jest tym, który realnie pracuje.
//
// Dotknięte prompty (B-021): @cto (owner). Review: 2026-09-06.

import { homedir } from 'node:os';
import { isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

/**
 * Rozwija `~` i robi ścieżkę bezwzględną. Świadomie NIE importujemy `rozwin()` ze
 * `stan-instalacji.mjs`: to on importuje ten plik, więc import w drugą stronę zamknąłby
 * cykl na module z `await` na najwyższym poziomie.
 */
function rozwinKatalog(s) {
  if (!s) return null;
  const p = s.startsWith('~/') ? join(homedir(), s.slice(2)) : s;
  return isAbsolute(p) ? p : resolve(p);
}

/** `--katalog=X` albo `--katalog X` — czytane wprost z argv, bo dzieje się to przed parserem. */
function katalogZArgv(argv = process.argv) {
  const zRownaniem = argv.find((a) => a.startsWith('--katalog='));
  if (zRownaniem) return zRownaniem.slice('--katalog='.length);
  const i = argv.indexOf('--katalog');
  return i !== -1 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : null;
}

/**
 * Kandydaci w kolejności od najpewniejszego. Każdy niesie NAZWĘ źródła, żeby komunikat
 * błędu mówił człowiekowi, skąd program wziął ten adres — samo „nie znalazłem" nie mówi,
 * czego szukać.
 */
export function kandydaciKanonu({
  argv = process.argv,
  env = process.env,
  cwd = process.cwd(),
  metaUrl = import.meta.url,
} = {}) {
  const zKatalogu = (kat, skad) => (kat ? { skad, sciezka: join(rozwinKatalog(kat), 'automatyzacje', 'trojstan.mjs') } : null);
  // `fileURLToPath`, nie `.pathname`: na Windows `.pathname` daje `/C:/…`, czyli ścieżkę,
  // której system plików nie zna.
  const wzgledna = (rel, skad) => ({ skad, sciezka: fileURLToPath(new URL(rel, metaUrl)) });

  return [
    // [1] TEN pracuje w normalnym przebiegu — SKILL.md wstawia tu rozwinięte
    //     `${CLAUDE_PROJECT_DIR}`. Udokumentowane: docs/en/skills.md §string substitutions.
    zKatalogu(katalogZArgv(argv), 'katalog podany w --katalog'),
    // [2] ⚠️ NIEUDOKUMENTOWANE DLA TEGO KONTEKSTU, świadomie zostawione jako tania siatka.
    //     `plugins-reference` mówi, że te zmienne są eksportowane do procesów HOOKÓW oraz
    //     do podprocesów serwerów MCP i LSP — o podprocesach narzędzia Bash nie mówi nic.
    //     Więc: jeśli platforma je tam ustawi, skorzystamy; jeśli nie — kandydat po prostu
    //     odpada. NIE opieramy na nim działania i nie wolno go opisywać jako mechanizmu.
    zKatalogu(env.CLAUDE_PROJECT_DIR, 'katalog projektu sesji (CLAUDE_PROJECT_DIR)'),
    // [3] Katalog roboczy. Udokumentowane, że komenda leci w bieżącym katalogu sesji —
    //     i że ten katalog PRZESUWA SIĘ po `cd` (docs/en/skills.md §Working directory),
    //     dlatego jest trzeci, a nie pierwszy.
    zKatalogu(cwd, 'katalog, z którego uruchomiono komendę'),
    wzgledna('../../../../automatyzacje/trojstan.mjs', 'rozłożona paczka klienta (zgodność wsteczna)'),
    wzgledna('../../../../../../../automatyzacje/trojstan.mjs', 'nasze repo (zgodność wsteczna)'),
  ].filter(Boolean);
}

async function wczytajTrojstan() {
  const bledy = [];
  for (const { skad, sciezka } of kandydaciKanonu()) {
    try {
      // `pathToFileURL`, nie goła ścieżka. Dokumentacja Node (nodejs.org/api/esm.html):
      // ESM przyjmuje wyłącznie schematy `file:`, `node:` i `data:`, a „it is recommended
      // to use url.pathToFileURL when importing a path". Goła ścieżka bezwzględna
      // (zwłaszcza `C:\…`) nie jest URL-em i leci błędem — a część klientów jest na Windows.
      return await import(pathToFileURL(sciezka).href);
    } catch (e) {
      bledy.push(`${sciezka}\n      (${skad}) — ${String(e.message || e).split('\n')[0]}`);
    }
  }
  // Cichy fallback na własne literały byłby dokładnie tym, czego zakazuje B-040 — więc
  // zamiast po cichu udawać, że wiemy, przewracamy się głośno. Komunikat mówi po ludzku,
  // co jest nie tak: nie „zła ścieżka", tylko „to nie jest katalog Systemu".
  throw new Error(
    'Nie znalazłem kanonu trójstanu (automatyzacje/trojstan.mjs).\n' +
      'Ta procedura pracuje NA KATALOGU SYSTEMU — tym, w którym leżą `automatyzacje/` i `blizniak/`.\n' +
      'Uruchom ją z tego katalogu albo wskaż go wprost: --katalog=<ścieżka do katalogu Systemu>.\n' +
      `Sprawdziłem po kolei:\n  • ${bledy.join('\n  • ')}`,
  );
}

export const { STAN } = await wczytajTrojstan();

/**
 * Rodzaje weryfikacji u źródła przy wznowieniu (spec §3a.2). `powtorz` znaczy: nie ma
 * osobnej sondy, bo tańszym i pewniejszym dowodem jest ponowne wykonanie kroku.
 */
export const WERYFIKACJA = Object.freeze({
  BRAK: 'brak',
  POWTORZ: 'powtorz',
  PLIK_POSWIADCZEN: 'plik-poswiadczen',
  WPIS_SKRZYNKI: 'wpis-skrzynki',
  AUTOSTART_STATUS: 'autostart-status',
  SPINACZ_SRODOWISKA: 'spinacz-srodowiska',
  BOOT_IMPORTY: 'boot-importy',
  PRZYPOMNIENIA: 'przypomnienia',
});

export const KROKI = [
  {
    nr: '2.1',
    nazwa: 'Test serwera bez hasła',
    kto: '@cto',
    czas: '~1 min',
    komenda: 'node automatyzacje/imap-capability-check.mjs <host-jej-serwera>',
    cel: 'Czy serwer umie IDLE i jakie ma metody logowania — zanim padnie hasło.',
    bramka:
      'Czytaj TREŚĆ wyniku, nie kod wyjścia. Brak IDLE → powiedz wprost, że obietnica latencji ' +
      'jest wtedy inna (odpytywanie co kilka minut zamiast reakcji od razu).',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.POWTORZ,
    powtarzalny: 'tak',
    przyWznowieniu: 'Powtórz — kosztuje sekundy i daje świeży odczyt serwera.',
  },
  {
    nr: '2.2',
    nazwa: 'Audyt poświadczeń',
    kto: '@cto',
    czas: '0,1 s maszyna + ~15 min ręcznie',
    komenda: 'node automatyzacje/audyt-poswiadczen.mjs',
    cel: 'Czy jej hasło już do nas nie trafiło odruchowo — PRZED instalacją, nie po.',
    bramka:
      'Pozycje oznaczone jako „do przejścia ręcznie" (poczta / komunikatory / kopie zapasowe) ' +
      'NIE SĄ ZIELENIĄ. Wypisz je człowiekowi jako listę do przejścia, nie zwijaj do „czysto".',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.POWTORZ,
    powtarzalny: 'tak',
    przyWznowieniu: 'Powtórz; pozycje „ręcznie" nadal nie są zielenią.',
  },
  {
    nr: '2.3',
    nazwa: 'Paczka z HEAD z jawnym wariantem Autopilota',
    kto: '@cto',
    czas: '0,4 s',
    komenda:
      'node automatyzacje/zbuduj-paczke-klienta.mjs --blizniak=<katalog> --wariant=email-autopilot',
    cel: 'Wersja i suma kontrolna lądują w manifeście — dowód, co dokładnie pojechało.',
    bramka:
      'Bez `--wariant=email-autopilot` Autopilot NIE jedzie (umowa §8 ust. 3: klientka ma o nim ' +
      'usłyszeć, więc dostawa jest jawna). Dowodem dostawy jest `blizniak/INSTRUKCJA_AUTOPILOT.md` ' +
      '+ sekcja Autopilota w spinaczu, nie obecność pliku `.mjs`. Brak warstwy integralności ' +
      '(wersja + sumy w manifeście) → STOP. Klient JUŻ zainstalowany → nie buduj od nowa, ' +
      'idź drogą B z §10.3 procedury (`aktualizuj-paczke.mjs`).',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.POWTORZ,
    powtarzalny: 'tak',
    przyWznowieniu: 'Sprawdź wersję i sumy w manifeście zamiast budować paczkę od nowa.',
  },
  {
    nr: '2.4',
    nazwa: 'Rozmowa o haśle',
    kto: 'user + klientka',
    czas: '👤 10 min',
    komenda: null,
    cel: 'Ona ma rozumieć klasę ryzyka PRZED wpisaniem hasła, nie po (umowa §8 ust. 4).',
    mowisz: [
      'co hasło daje Systemowi: czytanie jej skrzynki i zapis wersji roboczych — nic nie wychodzi samo,',
      'jak to cofnąć: zmiana hasła w panelu hostingu odcina dostęp w tej samej minucie,',
      'dlaczego nie ma tu „hasła aplikacji": cyber_Folks nie wystawia osobnych haseł dla programów,',
      'gdzie hasło leży: na JEJ dysku, w jej katalogu domowym — u nas go nie ma i nie będzie.',
    ],
    bramka: 'Rozmowa prowadzi człowiek. Skill wypisuje, o czym trzeba powiedzieć — i tyle.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'nie',
    weryfikacja: WERYFIKACJA.BRAK,
    powtarzalny: 'tak',
    przyWznowieniu:
      'Nie da się sprawdzić u źródła, czy rozmowa się odbyła — skill UFA ZAPISOWI i mówi wprost, że ufa.',
  },
  {
    nr: '2.5',
    nazwa: 'Klientka wpisuje hasło',
    kto: 'klientka',
    czas: '👤 ~10 min (przebieg maszynowy 5,7 s)',
    komenda: 'node automatyzacje/setup-poczta.mjs',
    cel: 'Hasło trafia na jej dysk, z jej klawiatury — ekran nic nie wyświetla.',
    bramka:
      'ZATRZYMANIE TWARDE. Oddaj klawiaturę i czekaj na potwierdzenie CZŁOWIEKA. ' +
      'Jeśli prosisz o hasło — to pomyłka po Twojej stronie. Hasło nie pada w rozmowie, ' +
      'nie jest zapisywane, nie jest powtarzane. Padło mimo wszystko → powiedz to wprost ' +
      'i doradź zmianę.',
    zatrzymanieTwarde: true,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.PLIK_POSWIADCZEN,
    powtarzalny: 'tak',
    przyWznowieniu:
      'Sprawdź, czy plik poświadczeń ISTNIEJE — nie pytaj ponownie o hasło. ' +
      'Sprawdzamy fakt na dysku, nie to, czy o coś pytaliśmy.',
  },
  {
    nr: '2.6',
    nazwa: 'Test połączenia',
    kto: 'klientka',
    czas: '~1 min',
    komenda: null,
    cel: 'Wizard sam mówi: „Połączenie OK" / „hasło odrzucone" / „nie znaleziono serwera".',
    bramka: 'Czerwone = STOP DNIA. Nie idziemy dalej, nie próbujemy obejść.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.POWTORZ,
    powtarzalny: 'tak',
    przyWznowieniu: 'Powtórz — to bramka, ma być świeża.',
  },
  {
    nr: '2.7',
    nazwa: 'Wpis skrzynki do konfiguracji',
    kto: '@cto',
    czas: '<0,1 s',
    // ⚠️ ZMIENIONE 18.08: wpis idzie do PLIKU DANYCH `automatyzacje/skrzynki.json`, a nie
    // do kodu. Do 18.08 edytowało się tablicę `MAILBOXES` wewnątrz `autopilot-config.mjs` —
    // czyli plik KODU, który `aktualizuj-paczke.mjs` nadpisuje. Pierwsza aktualizacja u klienta
    // kasowała wpis po cichu i autopilot przestawał działać bez jednego komunikatu.
    komenda: 'utworzenie pliku danych: automatyzacje/skrzynki.json → lista `skrzynki`',
    cel: 'Komplet pól — bo pominięte pole nie krzyczy, tylko wyłącza funkcję bez słowa.',
    bramka:
      'Niekompletny wpis NIE PRZECHODZI. Przy każdym brakującym polu nazwij SKUTEK ' +
      '(patrz `references/pola-skrzynki.md`). Po wpisie weryfikuj PRZEZ URUCHOMIENIE: ' +
      'konfiguracja ma się wczytać, a liczba skrzynek wzrosnąć o jeden. ' +
      'Plik NIE przyjeżdża w paczce — u klienta powstaje dopiero tutaj, a aktualizacja ' +
      'nie ma prawa go nadpisać (kontrakt PLIKI_KLIENTA).',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.WPIS_SKRZYNKI,
    powtarzalny: 'nie',
    przyWznowieniu:
      'NAJPIERW sprawdź, czy wpis JEST. Jest → nie dodawaj drugiego. Nie istnieje narzędzie ' +
      'dopisujące wpis idempotentnie, więc powtórzenie kroku dokłada drugi wpis tej samej ' +
      'skrzynki, a demon podnosi do niej dwa połączenia IDLE.',
  },
  {
    nr: '2.8',
    nazwa: 'Autostart',
    kto: '@cto',
    czas: '<0,1 s',
    komenda: 'node automatyzacje/autostart-demona.mjs zainstaluj --katalog=<katalog-paczki>',
    cel: 'Asystent wstaje po włączeniu komputera i wraca po padzie.',
    bramka:
      'macOS: dowiedzione na żywym launchd 08.08 (zabity proces wraca po ~30 s). ' +
      'WINDOWS: NIEPRZEĆWICZONE — oznacz tak wprost, nie pisz „gotowe".',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.AUTOSTART_STATUS,
    powtarzalny: 'tak',
    przyWznowieniu: 'Sprawdź `autostart-demona.mjs status` zamiast instalować od nowa.',
  },
  {
    nr: '2.9',
    nazwa: 'Sonda \\Seen na jej serwerze',
    kto: '@cto',
    czas: '0,1 s',
    komenda:
      'node automatyzacje/sonda-peek-seen.mjs --host=<host> --creds=<credsPath> --identity=<adres>',
    cel: 'Czy nasze czytanie NIE oznacza jej poczty jako przeczytanej.',
    bramka:
      'ZATRZYMANIE BRAMKI: `exit 2` (\\Seen wskakuje) ALBO `exit 3` („NIE SPRAWDZIŁEM") → ' +
      'DEMON NIE STARTUJE TEGO DNIA. „Nie sprawdziłem" nie jest zielenią — powiedz to po ludzku ' +
      'i podaj, co odblokowuje sprawdzenie.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.POWTORZ,
    powtarzalny: 'tak',
    przyWznowieniu: 'Powtórz — to bramka, ma być świeża.',
  },
  {
    nr: '2.10',
    nazwa: 'Kontrola pozytywna: testowa wiadomość → szkic w Drafts',
    kto: 'user + klientka',
    czas: '👤 ~5 min',
    komenda: null,
    cel: 'Odbiór techniczny to ŻYWY DRAFT w jej Drafts, nie komunikat „proces działa".',
    bramka: 'Brak szkicu → odbiór nieudany, choćby wszystko inne świeciło na zielono.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'czesciowo',
    weryfikacja: WERYFIKACJA.BRAK,
    powtarzalny: 'pytaj',
    przyWznowieniu:
      'ZAPYTAJ CZŁOWIEKA, czy powtarzać — powtórzenie znaczy kolejny testowy mail do klientki.',
  },
  {
    nr: '2.11',
    nazwa: 'Pokazanie `braki.md` i `propozycje-stylu.md`',
    kto: 'user',
    czas: '👤 2 min',
    komenda: null,
    cel: 'To są dwa pliki, którymi System sam się do niej odzywa.',
    mowisz: [
      '`braki.md` — pytania, na które System nie znalazł odpowiedzi w jej profilu firmy,',
      '`propozycje-stylu.md` — poprawki, które powtórzyła trzy razy, więc System proponuje je na stałe,',
      'oba leżą obok jej `dna.md`; bez zaglądania tam obie pętle piszą do szuflady.',
    ],
    bramka: 'Z checklisty C — pominięcie zostawia dwie pętle bez odbiorcy.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'nie',
    weryfikacja: WERYFIKACJA.BRAK,
    powtarzalny: 'tak',
    przyWznowieniu: 'Nie da się sprawdzić u źródła — skill UFA ZAPISOWI i mówi wprost, że ufa.',
  },
  {
    nr: '2.12',
    nazwa: 'Ona zmienia hasło',
    kto: 'klientka',
    czas: '👤 ~5 min',
    komenda: 'panel hostingu + node automatyzacje/setup-poczta.mjs (nowe hasło)',
    cel: 'Czynność ODBIORU (umowa §8 ust. 6), nie zalecenie na później.',
    bramka:
      'ZATRZYMANIE TWARDE. Bez naszego udziału i bez naszej obecności przy klawiaturze. ' +
      'Skill czeka na potwierdzenie człowieka.',
    zatrzymanieTwarde: true,
    weryfikowalny: 'nie',
    weryfikacja: WERYFIKACJA.BRAK,
    powtarzalny: 'pytaj',
    przyWznowieniu:
      'Nie wiemy, czy zmieniła — ZAPYTAJ. Nigdy nie każ z automatu: powtórzenie tego kroku ' +
      'jest dla niej uciążliwe i wygląda jak nasza pomyłka.',
  },
  {
    nr: '2.12a',
    nazwa: 'Środowisko: jeden katalog',
    kto: '@cto',
    czas: '<1 min',
    komenda: null,
    cel:
      'W katalogu Systemu (tym z `blizniak/` i `automatyzacje/` obok siebie) musi leżeć ' +
      '`CLAUDE.md`; `claude` uruchamia się STAMTĄD, nie z `blizniak/`.',
    bramka:
      'Brak `CLAUDE.md` w tym katalogu = paczka sprzed 17.08 → zbuduj i zainstaluj ponownie ' +
      'albo zaktualizuj drogą §10.3. Rozjazd wariantu (Autopilot obiecany, sekcji w spinaczu ' +
      'nie ma) → STOP: to klasa „cicha dostawa albo funkcja przemilczana".',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.SPINACZ_SRODOWISKA,
    powtarzalny: 'tak',
    przyWznowieniu: 'Powtórz — sprawdzenie jest darmowe.',
  },
  {
    nr: '2.12b',
    nazwa: 'Bramka bootu: czy asystent wstaje Z PROFILEM',
    kto: '@cto',
    czas: '<1 min',
    komenda: null,
    cel:
      'Pliki profilu mają być W KONTEKŚCIE sesji, nie tylko na dysku. 2.12a mówi, że plik LEŻY — ' +
      'to dwie różne rzeczy i awaria z 18.08 przeszła dokładnie przez tę różnicę.',
    bramka:
      'Sonda czyta łańcuch importów `@` z dysku. Po niej ZAWSZE potwierdź w sesji: wpisz ' +
      '`/context` i przeczytaj listę **Memory files** — muszą tam być wszystkie pliki z łańcucha. ' +
      'Któregoś nie ma → STOP, nie zaczynaj sesji szkoleniowej: asystent odpowiada płynnie i nie ' +
      'zna klienta, więc po rozmowie tego NIE poznasz. Suma kontrolna paczki zgadza się także ' +
      'wtedy, gdy import nie trafia w nic.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.BOOT_IMPORTY,
    powtarzalny: 'tak',
    przyWznowieniu: 'Powtórz — sprawdzenie jest darmowe, a odpowiada na jedyne pytanie, które psuje cały dzień.',
  },
  {
    nr: '2.13',
    nazwa: 'Data Instalacji + przypomnienia +14/+30',
    kto: 'user',
    czas: '<0,1 s',
    // ⚠️ `--skrzynka` jest OBOWIĄZKOWA (`dziennik-pracy.mjs:174` — bez niej narzędzie odmawia
    //    z komunikatem użycia). Zestawienie zawsze dotyczy JEDNEJ skrzynki; „policz wszystko"
    //    nie istnieje od 08.08. Ta linia była tu raz błędna: pominąłem flagę, bo sonda grepem
    //    padła z błędem składni, a ja odczytałem jej błąd jako „brak dopasowań" (klasa L-612 —
    //    komunikat narzędzia to nie jest wynik pomiaru). Sprawdzone uruchomieniem 18.08.
    komenda: 'node automatyzacje/dziennik-pracy.mjs --start=<data-instalacji> --skrzynka=<id>',
    cel:
      'Data Instalacji = dzień PÓŹNIEJSZEGO z Uruchomień. Umowa §2 ust. 1 lit. h każe złożyć ' +
      'zestawienie po 14 i 30 dniach — bez przypomnień nikt go nie złoży.',
    bramka:
      'Rejestr przypomnień jest PO NASZEJ STRONIE, nie na komputerze klientki. Na jej maszynie ' +
      'ten krok kończy się werdyktem „NIE SPRAWDZIŁEM" z nazwaniem, gdzie sprawdzić.',
    zatrzymanieTwarde: false,
    weryfikowalny: 'tak',
    weryfikacja: WERYFIKACJA.PRZYPOMNIENIA,
    powtarzalny: 'nie',
    przyWznowieniu:
      'Sprawdź, czy przypomnienia JUŻ stoją — powtórzenie kroku dubluje je i zamienia ' +
      'jeden ping w dwa.',
  },
];

/**
 * Pola wpisu skrzynki (krok 2.7). Kolumna „gdy pominiesz" jest tu po to, żeby skill mówił
 * SKUTEK, a nie „brakuje pola" — cicha degradacja jest groźna właśnie tym, że nie krzyczy.
 * `wymagane: true` = brak pola zatrzymuje krok 2.7.
 */
export const POLA_SKRZYNKI = [
  { pole: 'id', wymagane: true, poCo: 'tożsamość skrzynki w rejestrze', gdyBrak: 'demon nie wstanie' },
  { pole: 'host', wymagane: true, poCo: 'serwer IMAP', gdyBrak: 'demon nie wstanie' },
  { pole: 'port', wymagane: true, poCo: 'port IMAP (993)', gdyBrak: 'demon nie wstanie' },
  { pole: 'identity', wymagane: true, poCo: 'adres, na który przychodzi poczta', gdyBrak: 'demon nie wstanie' },
  {
    pole: 'credsPath',
    wymagane: true,
    poCo: 'ścieżka do poświadczeń NA JEJ DYSKU',
    gdyBrak: 'brak logowania — demon nie ma czym się przedstawić',
  },
  {
    pole: 'profilPath',
    wymagane: true,
    poCo: 'jej `dna.md` dla jednego ładowacza kontekstu',
    gdyBrak: 'drafty bez wiedzy o jej firmie i brak `braki.md` — pętla pytań nie ma gdzie pisać',
  },
  {
    pole: 'ghostStylePath',
    wymagane: true,
    poCo: 'jej styl (może wskazywać wprost `dna.md` — sekcja S5 wycinana sama)',
    gdyBrak: 'System pisze NASZYM stylem, nie jej',
  },
  {
    pole: 'displayName',
    wymagane: true,
    poCo: 'kto podpisuje odpowiedź',
    gdyBrak: 'jej odpowiedzi podpisze „Mateusz"',
  },
  {
    pole: 'tenantId',
    wymagane: true,
    poCo: 'polityka pokrycia (`draft-sanity`)',
    gdyBrak: 'bezpiecznik pokrycia nieaktywny — draft bez korpusu faktów przechodzi',
  },
  {
    pole: 'leadsDir',
    wymagane: true,
    poCo: 'katalog kart kontaktów — klient bez kart wskazuje `blizniak/encje` (może być PUSTY: sygnał S2 po prostu nic nie dopasuje, aż karty powstaną)',
    gdyBrak: 'pilnowanie terminów pilnuje pustki',
  },
  {
    pole: 'policy',
    wymagane: false,
    poCo: 'które sygnały działają i co uruchamiają: `{ signals, autodraftOn, alertOn }` (S1 = odpowiedź na nasz mail, S2 = nadawca z kart, S3 = klasyfikacja treści przez model)',
    gdyBrak:
      'wczytywacz wstawia domyślkę ALERT-ONLY (S1+S2, zero autodraftu) i mówi to na stderr — ' +
      'dla skrzynki głównej/mieszanej (bank, rodzina) to właściwy start; S3 i autodraft włącza ' +
      'świadomie właściciel. ⚠️ W paczce ≤0.2.7 domyślki NIE było — brak pola wywracał ' +
      'obsługę każdego maila („Cannot read properties of undefined")',
  },
  {
    pole: 'telegram',
    wymagane: false,
    poCo: 'powiadomienia na komunikator właściciela skrzynki ({ botToken, chatId }) — najszybsza droga do człowieka, ale JEDNA Z KILKU',
    // POPRAWIONE 31.08.2026 (zgłoszenie #3 Jonatana). Poprzednia treść brzmiała „alerty idą do
    // nas, nie do niej" i była napisana z NASZEJ perspektywy: u nas w środowisku stoi
    // `TELEGRAM_BOT_TOKEN`, więc rzeczywiście szły. Na komputerze klienta tego tokena nie ma
    // i alerty nie szły NIGDZIE — a do 31.08 ścieżka alertu nie łapała wyjątku, więc brak bota
    // nie tyle wyciszał powiadomienia, co wywracał obsługę każdego maila S1/S2.
    // Zdanie w dokumentacji obiecywało fallback, którego u klienta nie było.
    gdyBrak: 'powiadomienia nie przychodzą, ale system pracuje normalnie: każdy alert ląduje w `alerty.md` w folderze asystenta (wymaga ustawionego `profilPath`) i w dzienniku pracy. Pomijasz świadomie, gdy właściciel nie chce stawiać bota',
  },
  {
    pole: 'petlaStylu',
    wymagane: false,
    poCo: 'pętla powrotu stylu — TYLKO pilot',
    gdyBrak: 'brak pętli propozycji stylu (to jest dopuszczalny stan domyślny)',
  },
];

// Nagłówek NIESIE KOMENDĘ, która odtwarza TEN plik — a nie „mniej więcej tę komendę".
// Do 31.08 obie kopie dostawały jedno zdanie bez `--pola`, więc instrukcja odświeżenia
// wpisana w `pola-skrzynki.md` nadpisywała go tabelą KROKÓW. Zmierzone na sobie tego dnia:
// @coo poszedł za nagłówkiem i skasował zawartość pliku, który właśnie poprawiał.
// Instrukcja, która niszczy plik, w którym stoi, jest gorsza niż brak instrukcji —
// bo brakowi nikt nie ufa (L-679: naprawa jednej rzeczy psująca drugą).
export const naglowekRenderu = (komenda) =>
  '<!-- PLIK GENEROWANY — nie edytuj ręcznie.\n' +
  `     Źródło: scripts/kroki-etap2.mjs · odśwież: ${komenda}\n` +
  '     Parytet pilnuje: automatyzacje/tests/autopilot-instalacja-kroki.test.mjs -->\n';

export const NAGLOWEK_RENDERU = naglowekRenderu('node scripts/stan-instalacji.mjs kroki --markdown');

const trojstanEtykieta = (w) => (w === 'tak' ? 'tak' : w === 'nie' ? '**nie**' : 'częściowo');
const powtorzEtykieta = (p) => (p === 'tak' ? 'tak' : p === 'nie' ? '⛔ **NIE**' : '❓ pytaj');

export function renderKrokiMarkdown(kroki = KROKI) {
  const wiersze = kroki
    .map(
      (k) =>
        `| ${k.nr} | ${k.nazwa} | ${k.kto} | ${trojstanEtykieta(k.weryfikowalny)} | ` +
        `${powtorzEtykieta(k.powtarzalny)} | ${k.przyWznowieniu.replace(/\s+/g, ' ')} |`,
    )
    .join('\n');

  const szczegoly = kroki
    .map((k) => {
      const linie = [
        `### ${k.nr} — ${k.nazwa}`,
        '',
        `- **Kto:** ${k.kto} · **czas:** ${k.czas}`,
        `- **Po co:** ${k.cel}`,
      ];
      if (k.komenda) linie.push(`- **Komenda:** \`${k.komenda}\``);
      if (k.mowisz) {
        linie.push('- **Powiedz / pokaż:**');
        for (const m of k.mowisz) linie.push(`  - ${m}`);
      }
      linie.push(`- **Bramka:** ${k.bramka.replace(/\s+/g, ' ')}`);
      if (k.zatrzymanieTwarde) linie.push('- 🛑 **ZATRZYMANIE TWARDE — czekasz na człowieka.**');
      linie.push(
        `- **Przy wznowieniu:** ${k.przyWznowieniu.replace(/\s+/g, ' ')} ` +
          `_(weryfikacja: \`${k.weryfikacja}\`)_`,
      );
      return linie.join('\n');
    })
    .join('\n\n');

  return `${NAGLOWEK_RENDERU}
# Etap 2 — ${kroki.length} kroków uruchomienia Autopilota

Źródło prawdy o krokach: \`materialy/system10h/2026-08-08_procedura-instalacji_etap-1-i-2.md\` §4.
Przy rozjeździe wygrywa procedura — ten plik idzie wtedy do poprawki, nie odwrotnie.

## Macierz wznawiania

„Wolno powtórzyć" nie jest wygodą, tylko bezpieczeństwem: bez tej kolumny wznawianie
zdubluje wpis skrzynki i wyśle klientce kolejne testowe maile.

| # | Krok | Kto | Weryfikowalny u źródła | Wolno powtórzyć | Zachowanie przy wznowieniu |
|---|---|---|---|---|---|
${wiersze}

## Kroki

${szczegoly}
`;
}

export function renderPolaMarkdown(pola = POLA_SKRZYNKI) {
  const wiersz = (p) =>
    `| \`${p.pole}\` | ${p.wymagane ? '**tak**' : 'nie'} | ${p.poCo} | ${p.gdyBrak} |`;

  return `${naglowekRenderu('node scripts/stan-instalacji.mjs kroki --markdown --pola')}
# Krok 2.7 — komplet pól wpisu skrzynki

Wpis idzie do \`automatyzacje/skrzynki.json\`, lista \`skrzynki\`. To **plik danych, nie kod** —
i to jest celowe: aktualizacja paczki nadpisuje pliki kodu, więc dopóki wpis siedział wewnątrz
\`autopilot-config.mjs\`, pierwsza aktualizacja kasowała go po cichu (poprawione 18.08).
Ten plik nie przyjeżdża w paczce — powstaje dopiero tutaj i jest własnością klienta.

To jest miejsce, w którym instalacja psuje się najciszej: **pominięte pole nie krzyczy, tylko
wyłącza funkcję bez słowa.** Dlatego przy każdym braku mówimy SKUTEK, nie „brakuje pola".

Ścieżki zapisujesz z \`~\` (np. \`"~/.config/klient/creds.json"\`) — rozwija je wczytywacz.
Wzorce \`noiseFrom\` to zwykły tekst bez ukośników (np. \`"no-?reply"\`).

| Pole | Wymagane | Po co | Gdy pominiesz |
|---|---|---|---|
${pola.map(wiersz).join('\n')}

## Weryfikacja kroku

Po wpisie sprawdzasz **przez uruchomienie**, nie przez odczyt pliku: konfiguracja ma się
wczytać, a liczba skrzynek wzrosnąć o jeden.

Uruchamiasz to **komendą \`sprawdz\` z bloku „Sprawdź u źródła" w \`SKILL.md\`** — z
\`--krok=2.7\` i \`--skrzynka=<id>\`. Gotowej ścieżki nie ma tu celowo: skill bywa
zainstalowany jako wtyczka, w zupełnie innym drzewie niż projekt, i wtedy każda
ścieżka wpisana tu na sztywno wskazuje w pustkę. Katalog skilla podstawia platforma.
`;
}

export const krokPoNumerze = (nr, kroki = KROKI) => kroki.find((k) => k.nr === nr) || null;
