---
name: wgraj-aktualizacje
description: Wgrywa do bliźniaka nowsze pliki systemowe, które przyszły z aktualizacją narzędzi — najpierw pokazuje plan, dopiero po zgodzie zapisuje, zawsze z kopią zapasową. Użyj, gdy pada „wgraj aktualizację", „zastosuj to, co przyszło", „podmień pliki na nowsze", „mam nowszą wersję, co teraz", „jak zaktualizować bliźniaka".
disable-model-invocation: true
allowed-tools: Bash(node "${CLAUDE_PROJECT_DIR}/automatyzacje/aktualizuj-paczke.mjs" *) Bash(node automatyzacje/aktualizuj-paczke.mjs *) Bash(ls "${CLAUDE_SKILL_DIR}/references/pakiet"/*) Read
metadata:
  dystrybucja: plugin
---

# Wgranie aktualizacji do bliźniaka

Ta procedura **zapisuje na dysku właściciela paczki**. Dlatego ma dwa bieg: najpierw pokazuje,
co by zrobiła, i dopiero na wyraźne „tak" cokolwiek dotyka. Nigdy nie odwracaj tej kolejności,
nawet gdy właściciel prosi o pośpiech — plan jest tani, a odtwarzanie nadpisanego pliku nie.

> **Czego ta procedura NIE robi:** nie ściąga niczego z sieci i nie decyduje, czy aktualizacja
> jest potrzebna. Odpowiada na jedno pytanie: *„przyszły nowsze pliki systemowe — jak je
> bezpiecznie położyć u mnie".* Pytanie „czy jest coś nowszego" ma własną procedurę: `co-nowego`.

## Skąd bierze się nowa treść

Pliki jadą **razem z tą procedurą**, w `${CLAUDE_SKILL_DIR}/references/pakiet/`. Układ katalogów
w środku jest taki sam jak w paczce, więc `references/pakiet/blizniak/RECON.md` trafia na
`blizniak/RECON.md`. To jest cały mechanizm mapowania — żadnego zgadywania po nazwach.

## Krok 1 — sprawdź, co w ogóle przyjechało

```!
ls "${CLAUDE_SKILL_DIR}/references/pakiet"/*
```

**Pusto albo błąd = STOP i powiedz to wprost.** Aktualizacja bez treści nie jest aktualizacją;
nie udawaj, że „nie było czego wgrywać" — to dwa różne stany i właściciel ma prawo je odróżnić.

## Krok 2 — plan, czyli przebieg bez zapisu

```!
node "${CLAUDE_PROJECT_DIR}/automatyzacje/aktualizuj-paczke.mjs" --paczka="${CLAUDE_PROJECT_DIR}" --zrodlo="${CLAUDE_SKILL_DIR}/references/pakiet"
```

Ten przebieg **niczego nie zapisuje**. Przeczytaj właścicielowi jego wynik, nie streszczaj go
własnymi słowami — narzędzie mówi o jego plikach precyzyjniej, niż Ty pamiętasz.

**Nie ma tego pliku (`aktualizuj-paczke.mjs`) w paczce?** Powiedz to i **zatrzymaj się**.
Nie kopiuj plików ręcznie ani `cp`, ani Write'em: to narzędzie zna listę plików właściciela
(`dna.md`, `stan.md`, `braki.md`, `propozycje-stylu.md`, encje) i **odmawia ich tknięcia**.
Ręczne kopiowanie tej wiedzy nie ma i po cichu skasuje to, co system kazał właścicielowi dopisać.

### Co znaczą trzy odpowiedzi, które możesz zobaczyć

| co widzisz | co to znaczy | co robisz |
|---|---|---|
| lista `↻ nadpisz` | są różnice, aktualizacja ma sens | idź do kroku 3 |
| pusta lista zmian | pliki systemowe są już takie same | powiedz „nic do wgrania" — to wynik, nie awaria |
| `EXIT 2` — sekcje spoza szablonu w `dna.md` | właściciel dopisał coś swojego | **STOP.** To scala człowiek, nie Ty |
| `EXIT 3` — plik właściciela w źródle | aktualizacja niesie coś, czego nieść nie powinna | **STOP.** Zgłoś to nam, nie obchodź |
| `EXIT 4` — to nie wygląda na paczkę | jesteś w złym katalogu | sprawdź, gdzie stoisz; nie zgaduj |

⚠️ Linia **`🔇 NIE SPRAWDZIŁEM zgodności źródła z commitem`** przy tym przebiegu jest **normalna
i nie jest zieleń**: źródłem jest procedura spoza naszego repozytorium, więc git nie ma o nim
zdania. Przeczytaj ją właścicielowi tak, jak brzmi — jako trzeci stan, nie jako „czysto".

## Krok 3 — zapytaj i dopiero wtedy zapisz

Powiedz, **ile plików** zostanie nadpisanych i **że każdy dostanie kopię** w `backup/`.
Poczekaj na odpowiedź człowieka. Cisza to nie zgoda.

```!
node "${CLAUDE_PROJECT_DIR}/automatyzacje/aktualizuj-paczke.mjs" --paczka="${CLAUDE_PROJECT_DIR}" --zrodlo="${CLAUDE_SKILL_DIR}/references/pakiet" --wykonaj
```

## Krok 4 — powiedz, gdzie leży odwrót

Wypisz właścicielowi **nazwy kopii**, które narzędzie wypisało (`backup/<nazwa>_<data_godzina>.md`).
Nie mów „na wszelki wypadek zrobiłem backup" — podaj nazwy, bo bez nich kopia jest bezużyteczna
dokładnie w chwili, w której będzie potrzebna.

Jeżeli aktualizacja dotknęła plików ról (`RECON.md`, `CSO.md`), dopowiedz jedno zdanie:
**nowa treść wchodzi w życie przy następnym uruchomieniu** — ta rozmowa czyta wersję sprzed zmiany.

---

**Owner:** @prod (treść paczki) / @cto (narzędzie i kanał). **Dotknięte prompty (B-021):**
@prod · @cto · @cso (wie, że droga naprawy u istniejącego klienta istnieje i jest reaktywna).
**Deadline review: 2026-09-08.**
