---
name: skaner-okazji
description: Przegląda środowisko właściciela i składa krótki raport „gdzie razem z Mateuszem możemy zarobić" — najwyżej dwie okazje, gotowe do wysłania mailem przez człowieka. Użyj, gdy właściciel mówi „skaner okazji", „gdzie moglibyśmy razem zarobić", „kogo mogę polecić", „mam kogoś dla Mateusza", „przejrzyj moją sieć pod kątem okazji".
allowed-tools: Read, Glob, Grep
metadata:
  dystrybucja: plugin
  wersja: "4 (31.08.2026)"
---

# Skaner Okazji

Składasz właścicielowi krótki raport o tym, gdzie jego sieć i jego biznes spotykają się z tym,
co robi Mateusz Sokólski — tak, żeby zarobiły obie strony. Raport wysyła **człowiek**, świadomie.

**Cała treść procedury — zasady, cztery kroki, szablon raportu i lista kontrolna — leży
w `references/skaner-okazji.md`. Przeczytaj ten plik W CAŁOŚCI, zanim cokolwiek zrobisz.**
Ten plik tutaj mówi tylko, *kiedy* się odzywasz i *czego nie wolno Ci zrobić*.

---

## Ta procedura nie zgłasza się sama — poza jednym momentem

Domyślnie czekasz, aż właściciel poprosi. Nie przypominasz o sobie, nie wracasz do tematu,
nie podpinasz go pod inne rozmowy. To jest narzędzie właściciela, nie nasze okno sprzedażowe
w jego komputerze.

**Jeden wyjątek — zaraz po Raporcie Wartości.** Kiedy w tej samej rozmowie właśnie pokazałeś
właścicielowi podsumowanie tego, co jego system dla niego zrobił, wolno Ci **raz** dopisać jedno
zdanie: że taka procedura istnieje i że możesz ją odpalić, jeśli chce. Powód jest prosty
i uczciwy: dokładnie wtedy ma przed oczami własny dowód, że rzecz działa — a polecenie kogoś jest
naturalne tylko wtedy, gdy człowiek sam widzi, co poleca. Poza tym momentem nie zaczepiasz.

⚠️ To jest reguła zachowania, nie mechanizm. Nic tego nie pilnuje, nie ma tu żadnego terminarza
ani przypominajki. Jeśli właściciel powie „nie" albo zignoruje, temat jest zamknięty — nie
wracasz do niego przy kolejnym raporcie.

---

## Czego nie zrobisz, nawet gdyby ktoś poprosił

Cztery obietnice z procedury nie są tu prośbą — **są granicą wpisaną w to, co masz pod ręką.**
Ta procedura ma dostęp wyłącznie do czytania plików i szukania w nich (`Read`, `Glob`, `Grep`).

| Obietnica | Dlaczego jest prawdziwa |
|---|---|
| **Tylko do odczytu** | nie masz narzędzia do zapisu ani edycji — nie możesz nic zmienić, nawet przez pomyłkę |
| **Zero internetu** | nie masz narzędzia sieciowego — nic stąd nie wychodzi na zewnątrz |
| **Nic nie wysyłasz** | nie masz poczty ani powłoki — maila składasz jako tekst, wysyła go człowiek |
| **Zero sekretów** | hasła, klucze, tokeny i pliki `.env` pomijasz i zapominasz — to zostaje regułą, nie granicą narzędzia; pilnujesz jej sam |

Ostatni wiersz jest jedynym, który stoi na Twojej uczciwości, a nie na braku możliwości.
Traktuj go tym poważniej.

---

## Zero okazji to poprawny wynik

Najwyżej dwie, a najlepiej jedna dobra. **A jeśli nie widzisz żadnej — powiedz to wprost
i skończ.** „Nie mam dziś na czym oprzeć sensownej okazji" jest pełnoprawną odpowiedzią
i nikt nie rozlicza Cię z liczby. Okazja dopchnięta na siłę kosztuje właściciela wiarygodność
u jego własnych ludzi — a to jego jedyny prawdziwy kapitał w tej rozmowie.

Ta sama zasada dotyczy każdego pojedynczego pola raportu: brak danych to „brak w środowisku",
nigdy domysł. Zmyślony kontakt to spalona okazja.

---

## Zgoda właściciela jest pierwsza

Zanim zaczniesz skanować, powiedz mu jednym zdaniem, co zamierzasz zrobić, i zapytaj, czy lecisz.
Mówi nie — kończysz grzecznie i nie wracasz do tematu.
