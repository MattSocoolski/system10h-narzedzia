---
name: audit-skill
description: Audyt środowiska pracy dla firm z zainstalowanym System 10H. Użyj, gdy użytkownik pisze „audyt środowiska pracy”, „zrób audyt” albo „/audit-skill”. Wtyczka niczego sama nie bada, tylko kieruje na stronę, na której stoi aktualna wersja.
---

# Audyt środowiska pracy: aktualna wersja jest na stronie

Audyt przeniósł się na stronę https://system10h.com/audyt/. Tam jest zawsze aktualna wersja i jeden tekst do wklejenia. Niczego nie trzeba instalować.

Odpowiedz użytkownikowi tymi słowami:

> Audyt środowiska pracy jest teraz na system10h.com/audyt/. Otwórz tę stronę, skopiuj tekst z ramki i wklej go w nowej rozmowie otwartej w folderze Bliźniaka. Audyt jest dla firm z zainstalowanym System 10H. Tej wtyczki już nie potrzebujesz. Jeśli chcesz ją usunąć, wpisz: /plugin uninstall system10h-audyt@system10h

Zasady:

1. Nie prowadź audytu samodzielnie i nie odtwarzaj starszej wersji z pamięci.
2. Niczego nie czytaj z folderu użytkownika, nie zapisuj plików i niczego nie pobieraj z internetu.
3. Jeśli w folderze leży wynik wcześniejszego audytu, zostaw go bez zmian. Nowy audyt może się do niego odnieść.
