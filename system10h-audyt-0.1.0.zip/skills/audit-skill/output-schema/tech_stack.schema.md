# `tech_stack.json` — Schema v1.5

Machine-readable output skilla `audit-skill`. Główny input dla `analyzer-prompt.md v2.6` (System 10H radar-audyt).

> **v1.5 (2026-09-07) — narzędzie agentowe klienta (audit-skill v1.5):** dwa nowe pola w `environment_scan`: **`map_files[]`** (którą mapę środowiska klient ma — `CLAUDE.md`, `AGENTS.md`, `GEMINI.md`, `.github/copilot-instructions.md`) i **`agent_harness`** (w jakim narzędziu klient faktycznie pracuje). **Powód:** do v1.4 klient pracujący w Codeksie albo Gemini CLI wyglądał w wyniku identycznie jak klient bez żadnej konfiguracji — `claude_md_found: false` i tyle. Jedno pole × N audytów odpowiada na pytanie, czy odejście klienta na inne narzędzie to wyjątek, czy trend. **Backwards-compat:** oba pola opcjonalne, `claude_md_found` zachowuje **dosłowne** znaczenie (czy istnieje `CLAUDE.md`); starszy analyzer pomija nowe pola. Analyzer v2.6 przestaje czytać `claude_md_found: false` jako „brak konfiguracji", gdy `map_files[]` jest niepuste.

> **v1.3 (2026-06-29) — scorecard fields (krok 2/3 Fazy 0, @cto build, metodyka @geo):** dwa nowe pola opcjonalne zasilające Scorecard Gotowości na AI (analyzer §2e): `business_context.website_url` (Oś4 Widoczność — liczy analyzer, NIE skill) + `exposure_mapper{repetitive_share,text_knowledge_share,delegable_share}` (Oś3 Ekspozycja, enum low/med/high). Backwards-compat: brak → analyzer oznacza osie `N/D`/`[NIE WERYFIKOWANE]`. BINDING `D-2026-06-29-AI-READINESS-INDEX`.
>
> **v1.3-dev (2026-04-26)** — P3 schema extension dla eliminacji mylącego "12/20 enforced = 60%" sygnału + uzasadnień flag. Trzy nowe pola, wszystkie opcjonalne (backwards-compat z analyzer v2.3):
> - `metadata.architectural_constraints[]` — lista B-XXX/L-XXX architektonicznie niemożliwych do hard-gate w current arch (wymaga cloud Tier C / multi-tenant). Eliminuje mylący sygnał enforcement %.
> - `tools[].hobby_reason` — string|null. Konkretne uzasadnienie dlaczego `hobby_flag: true` (np. "tylko gaming history >5 msc, brak biznesowego use case").
> - `tools[].zombie_reason` — string|null. Konkretne uzasadnienie dlaczego `usage_level: "zombie"` (np. "instalacja 6+ msc, zero ROI weryfikowane przez self-audit Q2").
>
> Status pól P3: opcjonalne, zgodne wstecz z analyzerem v2.3; potwierdzone na Windows (04.2026).
>
> **v1.2 (2026-04-22)** — hobby filter fields (issue #5): `tools[].hobby_flag`, `tools[].hobby_question`, `metadata.personal_tools_excluded[]`, `metadata.hobby_filter_applied`. Backwards-compatible: analyzer v2.1/v2.2/v2.3 ignoruje pola jeśli nieobecne.
>
> **v1.2 (2026-04-21)** — FlowHunt-inspired additions: `user_proposed_automation` (priority #1 dla analyzera), rozszerzone `custom_skills_found_{local,global}`, opcjonalne `mcp_json_file` (distinction managed vs local config). Backwards-compatible: analyzer v2.1 ignoruje nowe pola.

## Pełny szablon (copy-paste ready)

```json
{
  "client_id": "kowalski-firma-x",
  "generated_at": "2026-04-15T18:30:00Z",
  "skill_version": "v1.3-dev",

  "business_context": {
    "company_name": "Firma X Sp. z o.o.",
    "website_url": "[adres strony firmowej z KROK 6 lub null — analyzer liczy z niego oś Widoczność; skill NIE pobiera strony]",
    "industry": "[z odpowiedzi klienta — 1-2 zdania swoimi słowami]",
    "team_size": 0,
    "roles_breakdown": {
      "sales": 0,
      "marketing": 0,
      "delivery": 0,
      "admin": 0
    },
    "main_goal_12m": "[cytat klienta — dokładnie jego słowami]",
    "pain_points": [
      "[bolączka 1 — cytat klienta, nie parafraza]",
      "[bolączka 2]",
      "[bolączka 3]"
    ],
    "monthly_leads_inbound": null,
    "monthly_leads_outbound": null,
    "previous_ai_attempts": "[co próbowali i co się nie przyjęło, cytat]",
    "has_external_support": false,
    "external_support": [
      {
        "type": "VA|agencja|freelancer|biuro_księgowe|inne",
        "what": "[co robią — 1 zdanie cytat klienta]",
        "frequency_per_month": 0
      }
    ]
  },

  "tools": [
    {
      "name": "HubSpot",
      "category": "crm",
      "usage_level": "heavy",
      "users": ["team"],
      "frequency_per_week": 5,
      "integration_status": "standalone",
      "monthly_cost_pln_estimate": 800,
      "notes": "[konkretny kontekst — co dokładnie robi w nim klient, cytat jeśli możliwy]",
      "hobby_flag": false,
      "hobby_question": null,
      "hobby_reason": null,
      "zombie_reason": null
    }
  ],

  "integration_gaps": [],

  "underutilized": [
    {
      "tool": "Zapier",
      "current_usage": "2 zapy",
      "available_capacity": "plan 20 zapów",
      "monthly_waste_pln_estimate": null,
      "client_quote": "[cytat klienta jeśli wspomniał ten ból]"
    }
  ],

  "ai_usage": {
    "current_llms": ["ChatGPT Plus"],
    "use_cases": ["[do czego używa dziś — lista krótka]"],
    "api_keys_owned": [],
    "monthly_ai_budget_pln": 0
  },

  "user_proposed_automation": {
    "quote": "[verbatim cytat klienta z KROK 6 AI pytanie 3 — bez parafrazy, polskie znaki, pełne zdanie]",
    "client_did_not_specify": false,
    "probed_once": false,
    "source": "[opcjonalne — dla smoke-testów / syntetycznych audytów; w realnych audytach pomiń]",
    "meta_note_smoke_test": "[opcjonalne — tylko smoke test mode]"
  },

  "workflow_highlights": {
    "morning_ritual": "[jakie narzędzia otwiera rano jako pierwsze — 3-5 nazw]",
    "typical_sales_day": [
      "krok 1 — rano",
      "krok 2",
      "krok 3",
      "krok 4",
      "krok 5 — wieczorem"
    ],
    "biggest_time_sinks": [
      "[co powtarza się >5x tyg ręcznie — cytat]",
      "[drugi time sink]"
    ]
  },

  "exposure_mapper": {
    "repetitive_share": "low|med|high",
    "text_knowledge_share": "low|med|high",
    "delegable_share": "low|med|high"
  },

  "environment_scan": {
    "claude_md_found": true,
    "claude_md_summary": "[2-3 zdania: co zawiera mapa środowiska — struktura, ile sekcji, kluczowe elementy]",
    "map_files": [
      {
        "name": "CLAUDE.md",
        "path": "./CLAUDE.md",
        "reads_it": "claude-code"
      }
    ],
    "agent_harness": {
      "primary": "claude-code",
      "detected": ["claude-code"],
      "evidence": "[czym to stwierdzone — np. 'polecenie codex na PATH + AGENTS.md w cwd']",
      "confidence": "measured",
      "switched_from": null,
      "notes": null
    },
    "dane_files": [
      {
        "file": "dane/profil.md",
        "status": "filled",
        "sections_total": 12,
        "sections_filled": 10,
        "key_observations": "[1-2 zdania: co jest, co brakuje, jakość treści]"
      },
      {
        "file": "dane/oferta.md",
        "status": "partial",
        "sections_total": 8,
        "sections_filled": 5,
        "key_observations": "[1-2 zdania]"
      }
    ],
    "assistants_configured": ["Researcher", "Strateg Sprzedaży"],
    "mcp_integrations": ["gmail", "notion"],
    "mcp_json_file": {
      "status": "present",
      "note": "[opcjonalne v1.2 — jeśli .mcp.json istnieje ale pusty/{}, opisz jako 'empty' + uwaga że MCP działa przez managed connections. To NIE jest luka — distinction 'managed vs local config' jest sygnałem dojrzałości setupu.]"
    },
    "custom_skills_found": [],
    "custom_skills_found_local": [],
    "custom_skills_found_global": [],
    "hooks_configured": false,
    "hooks_files": [],
    "automations": {
      "local_scripts": [],
      "cloud_functions": [],
      "observability": ""
    },
    "bliznak_completeness_pct": 67,
    "gaps_detected": [
      "[luka 1 — np. 'Brak sekcji DNA: Ekosystem, Wzorce']",
      "[luka 2 — np. 'persona.md placeholder — nie wypełniona']",
      "[luka 3 — np. 'Gmail MCP w CLAUDE.md ale brak .mcp.json']"
    ]
  },

  "metadata": {
    "scan_coverage": "full",
    "anonymization_applied": false,
    "client_reviewed_before_send": false,
    "os_detected": "macOS|Linux|Windows",
    "skill_duration_minutes": 0,
    "hobby_filter_applied": true,
    "personal_tools_excluded": [
      "Spotify",
      "Steam",
      "Discord (osobisty — klient potwierdził w KROK 5)"
    ],
    "personal_tools_excluded_count": 0,
    "hobby_flag_confirmed_business_count": 0,
    "hobby_flag_confirmed_personal_count": 0,
    "partner_language_applied": true,
    "solo_founder_branch": "solo_pure|solo_plus_outsourcing|team",
    "architectural_constraints": [
      {
        "id": "B-XXX-or-L-XXX",
        "label": "[krótka nazwa, np. 'Quality Scorecard cross-tenant']",
        "reason": "[1-2 zdania: dlaczego architektonicznie niemożliwe do hard-gate w current arch — np. 'wymaga storage S3/R2 + multi-tenant key. Dziś single-tenant by design']",
        "phase_unlock": "[kiedy odblokowane — np. 'W19+ post-Quality-Scorecard build' lub 'Tier C cloud (W40+)' lub 'master-plan §10']"
      }
    ]
  }
}
```

## Reguły wypełniania (dla Claude'a wykonującego skill)

### `client_id`
- Format: `[nazwisko-firma]` lub `klient-a` jeśli anonimizacja
- **Zapytaj klienta wprost** — nie wymyślaj sam

### `business_context.industry`
- **Cytat klienta, 1-2 zdania** — nie kategoria typu "SaaS" albo "consulting"
- Przykład dobry: "Robimy audyty bezpieczeństwa IT dla firm księgowych 10-50 osób"
- Przykład zły: "IT services"

### `business_context.pain_points`
- **Dokładnie 3 pozycje** z odpowiedzi na pytanie 4 KROKU 3
- **Cytaty, nie parafraza**
- Jeśli klient wymienił więcej niż 3 — wybierz te 3 które wypowiedział jako pierwsze

### `tools[]`
- Połączenie wyników skanu (KROK 4) + dopytek (KROK 5)
- Dla narzędzi zidentyfikowanych w skanie ale nie wspomnianych przez klienta w KROK 5 — ustaw `usage_level: "zombie"` i `users: []`
- `category` — użyj jednej z: `crm`, `email`, `calendar`, `project-management`, `knowledge-management`, `communication`, `marketing-automation`, `analytics`, `accounting`, `design`, `dev-tools`, `ai-llm`, `automation`, `social-media`, `content`, `hr`, `ats`, `other`
- `usage_level` enum: `heavy` (codzienne, godziny dziennie), `medium` (kilka razy w tygodniu), `light` (incydentalnie), `zombie` (ma, nie używa)
- `integration_status` enum: `standalone` (nie spięte z niczym), `integrated` (działa z czymś innym w stacku), `api-available-unused` (klient ma plan z API ale nie używa), `broken` (miało być zintegrowane, nie działa)
- `monthly_cost_pln_estimate` — szacunek, nie musi być dokładny. `null` jeśli klient nie wie.
- `notes` — **krótki kontekst od klienta**, idealnie cytat. Max 1-2 zdania.

### `integration_gaps[]`
- **ZAWSZE pozostaw jako pustą tablicę `[]`** w skillu.
- Wypełnia to analyzer Mateusza, nie skill.
- Skill dostarcza surowe dane, analyzer generuje wnioski.

### `underutilized[]`
- Tylko narzędzia o których klient wprost powiedział że ma w subskrypcji ale nie używa (KROK 5 pytanie 4)
- Nie wymyślaj sam
- Jeśli klient nie potrafi oszacować kosztu — `monthly_waste_pln_estimate: null`

### `ai_usage`
- **Krytyczne pole dla analyzer'a** (60% findings w Owner Mode opiera się o AI usage)
- Wypełnij na podstawie odpowiedzi KROK 6 pytania AI
- Jeśli klient nie używa AI w ogóle — zapisz `current_llms: []`, `monthly_ai_budget_pln: 0`, `use_cases: ["nic aktualnie"]`
- Jeśli klient ma API keys — wymień providerów jako stringi (`["OpenAI", "Anthropic"]`), nie kopiuj kluczy

### `workflow_highlights.typical_sales_day`
- **Min. 5 kroków** chronologicznie
- Zachowaj kolejność podaną przez klienta
- Nie restrukturyzuj na "proces sprzedaży" — zapisz tak jak klient to opowiedział

### `user_proposed_automation` (NOWE v1.2 — PRIORITY #1 dla analyzera)

**Źródło:** KROK 6 AI pytanie 3 — "Gdybyś mógł dziś pstryknąć palcami i zautomatyzować JEDNĄ rzecz w swojej firmie — co by to było?"

- `quote` — **verbatim cytat klienta**, bez parafrazy. Polskie znaki diakrytyczne. Pełne zdanie. Jeśli klient nie potrafi odpowiedzieć nawet po jednym dopytaniu → `""` + `client_did_not_specify: true`.
- `client_did_not_specify` — boolean. `true` tylko gdy klient dwa razy nie potrafił wskazać bólu.
- `probed_once` — boolean. `true` jeśli musiałeś dopytać raz ("najbardziej męczące zadanie z ostatniego tygodnia").
- `source` — opcjonalne. Użyj TYLKO dla smoke-testów (syntetycznych audytów self-audit). W realnych audytach pomiń.
- `meta_note_smoke_test` — opcjonalne. Tylko smoke test mode.

**Jak analyzer v2.2 to używa:** `quote` jawnie trafia jako rola #1 w sekcji "Asystenci AI których Ci brakuje" (Owner Mode), nawet jeśli obiektywnie większy impact ma inna rola. `client_did_not_specify: true` → analyzer pomija priority #1 + flag w Partner Mode.

**BLOKADA:** Jeśli to pole jest puste (nie null, nie ""), analyzer v2.2 zgłasza "audit-skill < v1.2, audyt ograniczony". Schema v1.2 wymaga obecności obiektu (nawet z `quote: ""` + `client_did_not_specify: true`).

---

### `business_context.website_url` (NOWE v1.3 — scorecard Oś4)

- string (URL) lub `null`. Adres strony firmowej z KROK 6 (pytanie o stronę).
- **Skill NIE pobiera tej strony** — reguła bezpieczeństwa #5 (zero requestów HTTP w skillu). Oś „Widoczność dla AI" liczy analyzer/@geo po stronie Mateusza (ma prawo do HTTP), per `geo.md`.
- `null` jeśli klient nie ma strony → analyzer ustawia oś Widoczność = `N/D` (nie kara — dla solo-handlowca on-page bywa niskim priorytetem).

### `exposure_mapper` (NOWE v1.3 — scorecard Oś3, rama Anthropic)

Obiekt z 3 pól, każde enum `"low" | "med" | "high"`. Z 3 pytań Ekspozycji w KROK 6 (Twoja ocena z odpowiedzi klienta, NIE liczba).

- `repetitive_share` — ile pracy powtarzalnej (research/maile/oferty/raporty) vs jednorazowa/ekspercka/relacyjna. Dużo powtarzalnej → `high`.
- `text_knowledge_share` — ile operowania na tekście/wiedzy vs praca poza ekranem (spotkania/telefon/fizyczna).
- `delegable_share` — jaką część dałoby się oddać asystentowi-człowiekowi bez utraty jakości.
- **To self-report z wywiadu — zero fetcha, zero skanu.** Analyzer mapuje: `HIGHS≥2 → E3` (szeroka ekspozycja, wysoka pilność) / `LOWS≥2 → E1` (wąska — anti-overinvest) / inaczej `E2`.
- **Backwards-compat:** brak obiektu (audyt < v1.3) → analyzer oznacza oś Ekspozycja = `[NIE WERYFIKOWANE]`, NIE zgaduje bandu (L-074). Jeśli klient nie odpowiedział na pytania — pomiń obiekt (NIE wpisuj zmyślonych wartości).

### `environment_scan` (NOWA SEKCJA v1.1 — KLUCZOWA)

**To jest najważniejsza sekcja audytu.** Wypełnij z wyników KROKU 4 Fazy A (skan środowiska Bliźniaka).

- `claude_md_found` — boolean. `true` **wyłącznie** jeśli w cwd klienta istnieje `CLAUDE.md` / `claude.md`. ⛔ Nie ustawiaj `true` dlatego, że znalazłeś `AGENTS.md` — od v1.5 to jest osobne pole (`map_files[]`) i osobna informacja o kliencie.
- `claude_md_summary` — 2-3 zdania opisujące co zawiera znaleziona mapa środowiska: ile sekcji, jakie agenty, jakie integracje wymienione, jaka struktura folderów.
- **`map_files[]` (NOWE v1.5)** — tablica obiektów, jeden na KAŻDĄ znalezioną mapę środowiska. Pusta `[]`, gdy nie ma żadnej.
  - `name` — nazwa pliku: `"CLAUDE.md"` · `"AGENTS.md"` · `"GEMINI.md"` · `".github/copilot-instructions.md"`
  - `path` — ścieżka względna od cwd
  - `reads_it` — które narzędzie tę mapę czyta (`"claude-code"` · `"codex, copilot, cursor, aider (format otwarty)"` · `"gemini-cli"` · `"copilot"`)
  - **Kilka map naraz to nie błąd** — klient, który trzyma `CLAUDE.md` i `AGENTS.md`, najczęściej używa dwóch narzędzi albo właśnie się przenosi. Zapisz wszystkie.
- **`agent_harness` (NOWE v1.5)** — obiekt: w jakim narzędziu agentowym klient faktycznie pracuje. **To jest to pole, dla którego powstała wersja 1.5.**
  - `primary` — enum: `"claude-code"` · `"codex"` · `"gemini-cli"` · `"copilot-cli"` · `"cursor"` · `"aider"` · `"other"` · `"unknown"`. Gdy wykryto więcej niż jedno — **nie zgaduj**, zapytaj klienta (KROK 6 pytanie 1a).
  - `detected[]` — wszystkie wykryte narzędzia (te same wartości enum). Pusta `[]`, gdy skan nic nie znalazł.
  - `evidence` — string, po ludzku: czym to stwierdzone. Np. `"polecenie codex na PATH + AGENTS.md w cwd"` albo `"klient powiedział; skan nie wykrył nic na PATH"`.
  - `confidence` — enum: `"measured"` (widziałeś polecenie albo mapę) · `"self_reported"` (tylko słowa klienta) · `"unknown"` (ani jedno, ani drugie). ⛔ `measured` bez realnego trafienia w skanie to fałszywy pomiar.
  - `switched_from` — string|null. Wypełnij, **gdy klient sam powie**, że się przeniósł (np. `"claude-code"`, gdy dziś pracuje w Codeksie). Nie wnioskuj tego ze śladów na dysku — stary katalog `.claude/` nie dowodzi przeprowadzki.
  - `notes` — string|null. Słowa klienta o tym, dlaczego pracuje tam, gdzie pracuje. Bez ocen i bez namawiania na powrót.
- `dane_files[]` — tablica obiektów, JEDEN OBIEKT PER PLIK .md odczytany w Fazie A. Dla każdego:
  - `file` — ścieżka względna (np. `"dane/profil.md"`)
  - `status` — enum: `"filled"` (>70% sekcji), `"partial"` (30-70%), `"empty"` (<30%), `"placeholder"` (szablonowe treści), `"missing"` (wymieniony w CLAUDE.md ale nie istnieje)
  - `sections_total` — ile nagłówków ## i ###
  - `sections_filled` — ile z nich ma realną treść
  - `key_observations` — 1-2 zdania: co kluczowego jest w pliku, co brakuje, jakość treści
- `assistants_configured` — tablica stringów: nazwy asystentów AI wykrytych w CLAUDE.md i plikach konfiguracyjnych. Przykład: `["Researcher", "Strateg Sprzedaży"]`. Pusta tablica `[]` jeśli brak.
- `mcp_integrations` — tablica stringów: nazwy MCP serwerów z .mcp.json. **TYLKO nazwy** (np. `"gmail"`, `"notion"`), NIGDY klucze/tokeny. Pusta tablica jeśli brak .mcp.json.
- `custom_skills_found` — tablica stringów: nazwy skills z `.claude/skills/` (legacy v1.1). Pusta jeśli brak.
- `custom_skills_found_local` (v1.2) — tablica stringów: skills z LOKALNEGO `.claude/skills/` (project-level, cwd klienta). Zwykle puste dla nowych użytkowników Claude Code.
- `custom_skills_found_global` (v1.2) — tablica stringów: skills z GLOBAL `~/.claude/skills/` (user-level). Zwykle zawiera skills zainstalowane przez `skills add` lub ręcznie. Tu widać dojrzałość CLI usera.
- `hooks_configured` — boolean: czy są hooks skonfigurowane (`.claude/hooks/` lub `settings.json` PreToolUse/PostToolUse).
- `hooks_files` (v1.2) — tablica stringów: ścieżki plików hook jeśli widoczne (np. `".claude/hooks/gmail-guard.js"`). Pomaga analyzerowi ocenić enforcement level.
- `automations` (v1.2) — obiekt:
  - `local_scripts` — tablica: nazwy skryptów lokalnych (np. `automatyzacje/*.js`)
  - `cloud_functions` — tablica: AWS Lambda / Cloudflare Worker / GCP Functions
  - `observability` — string: opis monitoring stack (dashboardy, alarmy, logi)
- `bliznak_completeness_pct` — integer 0-100. Oblicz wg formuły z SKILL.md KROK 4 A5.
- `gaps_detected` — tablica stringów: lista wykrytych luk. Każdy string = 1 konkretna luka. Min. 1 element (zawsze jest coś do poprawienia). Przykład: `["Brak sekcji DNA: Ekosystem, Wzorce", "persona.md placeholder", "Gmail MCP w CLAUDE.md ale brak .mcp.json"]`.

**REGUŁA:** Jeśli `environment_scan` jest pusta lub ma `dane_files: []` mimo że klient MA pliki .md — WRÓĆ do KROKU 4 Fazy A i przeczytaj pliki. Pusta sekcja = audyt bezwartościowy.

### `metadata.os_detected`
- `macOS` / `Linux` / `Windows` — wykryty w KROK 4.0 (`uname -s`)
- Wpływa na zestaw komend skanujących (macOS: brew/ls, Linux: apt/ls, Windows: PowerShell/Registry)

### `metadata.scan_coverage`
- `full` — wszystkie komendy KROK 4 zwróciły dane
- `partial` — część komend zwróciła puste odpowiedzi (fresh machine, PowerShell niedostępny, uprawnienia)

### `metadata.client_reviewed_before_send`
- **Zawsze `false`** w momencie generowania
- Klient sam oznaczy `true` po przejrzeniu pliku (opcjonalnie)

### `tools[].hobby_flag` (v1.2 issue #5)
- boolean. `true` jeśli narzędzie jest na liście DUAL-USE (Slack, Discord, WhatsApp, Figma, Notion, YouTube, itp. — patrz SKILL.md KROK 4 B7) i wymaga potwierdzenia biznes vs prywatne z klientem w KROK 5 pytanie 5.
- `false` domyślnie dla narzędzi oczywiście biznesowych (HubSpot, Pipedrive, Gmail biznesowy).
- Po KROK 5 potwierdzeniu: business → pozostaw narzędzie w `tools[]` z `hobby_flag: false`. Personal → usuń z `tools[]`, przenieś nazwę do `metadata.personal_tools_excluded[]`.
- **BLOKADA:** Nie zapisuj `tech_stack.json` z narzędziami `hobby_flag: true` bez rozstrzygnięcia — klient musi potwierdzić.

### `tools[].hobby_question` (v1.2 issue #5)
- string lub `null`. Konkretne pytanie do klienta: "Czy Discord używasz biznesowo czy prywatnie?".
- Ustawiane przez FILTR HOBBY w KROK 4 B7, usuwane po odpowiedzi klienta w KROK 5.
- Jeśli `hobby_flag: false` → `hobby_question: null`.

### `metadata.hobby_filter_applied` (v1.2 issue #5)
- boolean. Zawsze `true` jeśli skill v1.2 zastosował filtr (obowiązkowo od v1.2).
- Analyzer v2.3 używa tego flagu do walidacji — jeśli `false` lub brak → Partner Mode flag "skill stary, lista narzędzi może zawierać hobby".

### `metadata.personal_tools_excluded[]` (v1.2 issue #5)
- tablica stringów: nazwy narzędzi odrzuconych przez BLACKLIST (KROK 4 B7) LUB potwierdzonych jako prywatne w KROK 5.
- Format: `"Spotify"`, `"Steam"`, `"Discord (osobisty — klient potwierdził 2026-04-22)"`.
- Nie zawiera haseł/kluczy — tylko nazwy. Dla transparency (klient widzi co odrzuciliśmy).
- `metadata.personal_tools_excluded_count` = długość tablicy.

### `metadata.hobby_flag_confirmed_business_count` / `hobby_flag_confirmed_personal_count` (v1.2 issue #5)
- integer. Ile narzędzi z `hobby_flag: true` klient potwierdził jako business (zostają w `tools[]`) vs personal (przeniesione do excluded).
- Suma = liczba flagów postawionych w B7.

### `metadata.partner_language_applied` (v1.2 issue #4)
- boolean. Zawsze `true` jeśli `tech_stack_human.md` wygenerowany wg "Reguły Języka Partnerskiego" (SKILL.md KROK 7b).
- Analyzer v2.3 odczytuje ten flag jako sygnał że klient widział raport z językiem partnerskim PRZED Owner Mode. Analyzer kontynuuje tym samym tonem.

### `tools[].hobby_reason` (v1.3-dev — P3)

- string lub `null`. **Konkretne uzasadnienie** dlaczego `hobby_flag: true` ustawione lub po KROK 5 confirmed personal.
- Format: krótkie zdanie z konkretem (np. `"tylko gaming history >5 msc, brak biznesowego use case w skanie cwd"`, `"klient potwierdził: Discord = znajomi, nie team"`).
- **Domyślnie `null`** dla narzędzi `hobby_flag: false` (jasno biznesowe).
- **Cel:** eliminacja false-positives Ollama-style (Owner Mode flagował `zombie_flag` bez głębszego grep `automatyzacje/`). Analyzer v2.4+ używa `hobby_reason` do conditional reframe — jeśli reason brzmi defensywnie ("nie wiadomo czy używa") → Partner Mode flag "skill nie głęboko zweryfikował, dopytaj klienta".
- Backwards-compat: schemy v1.0/v1.1/v1.2 → analyzer v2.3 traktuje brak pola jako `null`.

### `tools[].zombie_reason` (v1.3-dev — P3)

- string lub `null`. **Konkretne uzasadnienie** dlaczego `usage_level: "zombie"` ustawione.
- Format: krótkie zdanie z konkretem (np. `"instalacja 6+ msc, zero ROI weryfikowane przez self-audit Q2 (Ollama case 2026-04-26)"`, `"plan opłacony 2024-09, login_history pusty od 5 msc"`).
- **Domyślnie `null`** dla narzędzi `usage_level != "zombie"`.
- **Cel:** flag "zombie" sam w sobie = sygnał, ale brak uzasadnienia → false-positive risk dla narzędzi które klient używa rzadko ale celowo (np. backup tool, raz/kwartał compliance check). Analyzer v2.4+ wymaga `zombie_reason` żeby rekomendować unparking lub deinstall.
- Backwards-compat: schemy v1.0/v1.1/v1.2 → analyzer v2.3 traktuje brak pola jako `null`.

### `metadata.architectural_constraints[]` (v1.3-dev — P3)

**Najważniejsze pole P3.** Eliminuje mylący sygnał "12/20 enforced = 60%" — dodaje machine-readable wskazanie że N z 20 hard-gates jest **architektonicznie niemożliwych do hard-gate w current arch**.

- Tablica obiektów. Każdy obiekt:
  - `id` — string. Identyfikator hard-gate / lekcji (np. `"B-011"`, `"L-076"`, `"B-016"`).
  - `label` — string. Krótka nazwa konstrainu (np. `"Quality Scorecard cross-tenant"`, `"Pattern-detector pre-W22"`, `"Multi-tenant skill registry"`).
  - `reason` — string. **1-2 zdania** dlaczego architektonicznie niemożliwe — referencja do master-plan/decision (np. `"wymaga storage S3/R2 + multi-tenant key. Dziś single-tenant by design (master-plan §10.5)"`).
  - `phase_unlock` — string. Kiedy odblokowane:
    - `"W19+ post-X-build"` — odblokowane po sprincie wewnętrznym
    - `"Tier C cloud (W40+)"` — wymaga cloud upgrade
    - `"post-Windows-PASS (W18)"` — wymaga zewnętrznego eventu
    - `"master-plan §X"` — referencja do hubu strategicznego

- **Cel scoring update:** analyzer v2.4+ liczy:
  - `enforcement_pct = (enforced / (enforced + soft + architectural)) * 100`
  - **Z architectural_constraints:** `enforced + soft + architectural = total`. Bez `architectural_constraints` (schemy v1.2-): `enforced + soft = total`, raport pokazuje "60% enforced" myląco.
  - Nowy sygnał Owner Mode: `"12/20 hard-gate (60%) + 5/20 architectural blockers (25%) + 3/20 soft (15%). Realny enforcement potencjał: 85% post-Tier-C / 75% post-Quality-Scorecard."`

- Backwards-compat: schemy v1.0/v1.1/v1.2 → analyzer v2.3 traktuje brak pola jako pusta tablica (raport bez sekcji architectural blockers).

- **BLOKADA nowa (v1.3-dev):** Jeśli skill pokazuje `enforcement_pct < 80%` — KROK 7c walidacja: ile z różnicy 100% - enforcement_pct% to architectural blockers? Skill MUSI policzyć i wpisać w `architectural_constraints[]`. Jeśli zostawia puste → flag w `tech_stack_human.md` "ten skill nie zwalidował architectural constraints — analyzer może niedoszacować enforcement".

### `metadata.solo_founder_branch` (v1.2 issue #6)

Wartość wyznaczana w KROK 3 pytanie 2 + 2a:

- `"solo_pure"` — team_size == 1 AND has_external_support == false
- `"solo_plus_outsourcing"` — team_size == 1 AND has_external_support == true (≥1 element w external_support[])
- `"team"` — team_size ≥ 2 (domyślnie)

**Konsekwencja downstream:** analyzer-prompt v2.4 używa tego flagu do conditional tone branch (sekcja "Ton rekomendacji" w Owner Mode). Dla `solo_pure` i `solo_plus_outsourcing` — reframe "delegacja → automatyzacja", "team → narzędzia". Dla `team` — default ton (delegacja OK, structure OK).

**Backwards compatibility:** Stare audyty (v1.0/v1.1) bez pola `metadata.solo_founder_branch` → analyzer traktuje jako `"team"` (default fallback). Stare audyty bez `business_context.has_external_support` → traktuj jako `false`.

## Walidacja przed zapisem

Claude musi sprawdzić przed `Write tool`:

- [ ] JSON jest syntaktycznie poprawny (użyj mental parse)
- [ ] `client_id` jest ustawione (nie pusty string)
- [ ] `environment_scan` jest wypełnione (claude_md_found, dane_files z min. 1 wpisem, bliznak_completeness_pct, gaps_detected)
- [ ] **[v1.5]** `environment_scan.agent_harness` istnieje i ma wypełnione `primary`, `detected[]`, `evidence`, `confidence` (`confidence: "measured"` tylko przy realnym trafieniu w skanie)
- [ ] **[v1.5]** `environment_scan.map_files[]` istnieje (`[]` gdy brak map) i wymienia KAŻDĄ mapę znalezioną w kroku A1
- [ ] **[v1.5]** Jeśli `map_files[]` niepuste, a `claude_md_found: false` → `gaps_detected[]` **NIE** zawiera „brak CLAUDE.md". Klient w innym narzędziu nie ma luki, tylko inne narzędzie.
- [ ] `tools[]` ma min. 3 elementy
- [ ] `business_context.pain_points` ma dokładnie 3 elementy
- [ ] `ai_usage` jest wypełnione (nawet zerami)
- [ ] `workflow_highlights.typical_sales_day` ma min. 5 kroków
- [ ] `metadata.scan_coverage` jest `full` lub `partial`
- [ ] Żadne pole nie zawiera haseł, kluczy API, tokenów (grep security check)
- [ ] **[v1.2 #5]** `metadata.hobby_filter_applied: true` (obowiązkowo od v1.2)
- [ ] **[v1.2 #5]** Żadne narzędzie w `tools[]` nie ma `hobby_flag: true` bez potwierdzenia z klientem (klient musi odpowiedzieć w KROK 5 pytanie 5)
- [ ] **[v1.2 #5]** `tools[]` nie zawiera oczywistych hobby (Spotify, Steam, gry, Netflix, Tinder, czysto entertainment) — filtr BLACKLIST zadziałał
- [ ] **[v1.2 #4]** `metadata.partner_language_applied: true` (jeśli `tech_stack_human.md` był generowany — obowiązkowo od v1.2)
- [ ] **[v1.2 #6]** `metadata.solo_founder_branch` jest jednym z: `"solo_pure"`, `"solo_plus_outsourcing"`, `"team"` (NIE `null`, NIE brak pola)
- [ ] **[v1.2 #6]** Jeśli `team_size == 1` → `metadata.solo_founder_branch` to `"solo_pure"` lub `"solo_plus_outsourcing"` (NIGDY `"team"`)
- [ ] **[v1.2 #6]** Jeśli `has_external_support == true` → `external_support[]` ma min. 1 element z wypełnionym `type` i `what`
- [ ] **[v1.3-dev P3]** Każde narzędzie z `hobby_flag: true` MA wypełniony `hobby_reason` (string, nie `null`). Reason brzmi konkretnie (>10 znaków, >2 słowa).
- [ ] **[v1.3-dev P3]** Każde narzędzie z `usage_level: "zombie"` MA wypełniony `zombie_reason` (string, nie `null`). Reason brzmi konkretnie + ma referencję czasową ("X msc temu", "od daty Y") lub kontekstową ("self-audit Q2", "decyzja D-XXXX").
- [ ] **[v1.3-dev P3]** Jeśli `enforcement_pct < 80%` → `metadata.architectural_constraints[]` MA min. 1 element. Każdy element ma wypełnione `id`, `label`, `reason`, `phase_unlock` (cztery pola string, nie pusty).
- [ ] **[v1.3-dev P3]** `metadata.architectural_constraints[]` zachowuje JSON validity nawet gdy puste (`[]` zamiast `null`).

Jeśli walidacja NIE przejdzie — wróć do odpowiedniego kroku skilla i uzupełnij dane.
